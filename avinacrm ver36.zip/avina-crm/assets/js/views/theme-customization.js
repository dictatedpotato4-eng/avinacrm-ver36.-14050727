import { apiGet, apiPost, apiRequest } from '../api-client.js';
import { escapeHtml, loadingHtml, errorHtml } from '../ui.js';

export async function renderThemeCustomization(container) {
  let activeTab = 'theme';
  let settings = null;
  let newProduct = '';
  let newService = '';

  const colors = [
    { name: 'نیلی (Indigo)', value: '#6366f1' },
    { name: 'آبی فیروزه‌ای (Teal)', value: '#14b8a6' },
    { name: 'سبز زمردی (Emerald)', value: '#10b981' },
    { name: 'صورتی ملایم (Rose)', value: '#f43f5e' },
    { name: 'کهربایی (Amber)', value: '#f59e0b' },
    { name: 'بنفش (Violet)', value: '#8b5cf6' },
  ];

  async function load() {
    container.innerHTML = loadingHtml();
    try {
      settings = await apiGet('/settings');
      draw();
    } catch (err) {
      container.innerHTML = errorHtml(err.message);
    }
  }

  function draw() {
    const storedTheme = JSON.parse(localStorage.getItem('avina_crm_theme_settings') || '{}');

    const tabButtons = [
      { id: 'theme', label: '🎨 پوسته و افکت‌ها' },
      { id: 'templates', label: '✉️ الگوهای پیام' },
      { id: 'products', label: '📦 محصولات و خدمات' },
      { id: 'kanban', label: '📋 بورد کانبان و کی‌پد' },
      { id: 'ai', label: '🤖 دستیار هوشمند' }
    ].map(t => `
      <button type="button" class="avina-crm-btn tab-btn ${activeTab === t.id ? 'active' : ''}" data-tab="${t.id}" style="padding:0.5rem 1rem; font-size:0.8rem; background:${activeTab === t.id ? 'var(--avina-primary)' : 'rgba(255,255,255,0.04)'}; border-color:${activeTab === t.id ? 'var(--avina-primary)' : 'rgba(255,255,255,0.1)'};">
        ${t.label}
      </button>
    `).join('');

    container.innerHTML = `
      <div class="avina-crm-glass" style="padding:1.5rem; max-width:800px; margin: 0 auto; direction:rtl; text-align:right;">
        <h2 style="margin-top:0; font-size:1.25rem; font-weight:800; color:#fff; border-bottom:1px solid rgba(255,255,255,0.08); padding-bottom:0.5rem; margin-bottom:1.25rem;">
          ⚙️ پنل تنظیمات پیشرفته سیستم
        </h2>

        <!-- Tabs Navigation -->
        <div style="display:flex; gap:0.5rem; margin-bottom:1.5rem; flex-wrap:wrap;">
          ${tabButtons}
        </div>

        <!-- Tab Contents Wrapper -->
        <div id="tab-content-container">
          ${renderTabContent(storedTheme)}
        </div>
      </div>
    `;

    // Bind tab clicks
    container.querySelectorAll('.tab-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        activeTab = btn.dataset.tab;
        draw();
      });
    });

    // Bind form events depending on active tab
    bindTabEvents(storedTheme);
  }

  function renderTabContent(storedTheme) {
    if (activeTab === 'theme') {
      const colorOptions = colors.map(c => `
        <label style="display:flex; align-items:center; gap:0.5rem; cursor:pointer; background:rgba(255,255,255,0.03); padding:0.55rem; border-radius:8px; border:1px solid rgba(255,255,255,0.06); font-size:0.8rem; color:#fff;">
          <input type="radio" name="primaryColor" value="${c.value}" ${storedTheme.primaryColor === c.value || (!storedTheme.primaryColor && c.value === '#6366f1') ? 'checked' : ''} />
          <span style="display:inline-block; width:14px; height:14px; border-radius:50%; background:${c.value};"></span>
          <span>${escapeHtml(c.name)}</span>
        </label>
      `).join('');

      return `
        <form id="theme-settings-form" style="display:flex; flex-direction:column; gap:1.25rem;">
          <div>
            <label style="display:block; font-weight:bold; margin-bottom:0.6rem; font-size:0.85rem; color:#fff;">رنگ اصلی دکمه‌ها و سایه‌های نوری (Primary Neon)</label>
            <div style="display:grid; grid-template-columns:repeat(auto-fill, minmax(160px, 1fr)); gap:0.75rem;">
              ${colorOptions}
            </div>
          </div>

          <div>
            <label style="display:block; font-weight:bold; margin-bottom:0.5rem; font-size:0.85rem; color:#fff;">پوسته پس‌زمینه داشبورد</label>
            <select id="bg-type" style="width:100%; padding:0.55rem; border-radius:8px; background:rgba(0,0,0,0.3); color:#fff; border:1px solid rgba(255,255,255,0.12); font-family:inherit;">
              <option value="solid" ${storedTheme.bgType === 'solid' || !storedTheme.bgType ? 'selected' : ''}>پیش‌فرض (نئونی تاریک)</option>
              <option value="image" ${storedTheme.bgType === 'image' ? 'selected' : ''}>پس‌زمینه تصویر دلخواه</option>
              <option value="video" ${storedTheme.bgType === 'video' ? 'selected' : ''}>پس‌زمینه ویدیو متحرک</option>
            </select>
          </div>

          <div id="bg-image-wrapper" style="display:${storedTheme.bgType === 'image' ? 'block' : 'none'};">
            <label style="display:block; font-weight:bold; margin-bottom:0.35rem; font-size:0.8rem; color:#fff;">آدرس اینترنتی تصویر پس‌زمینه (URL)</label>
            <input type="text" id="bg-image-url" value="${escapeHtml(storedTheme.bgImageUrl || '')}" placeholder="https://example.com/image.jpg" style="width:100%; padding:0.5rem; border-radius:8px; background:rgba(255,255,255,0.05); color:#fff; border:1px solid rgba(255,255,255,0.1); direction:ltr;" />
          </div>

          <div id="bg-video-wrapper" style="display:${storedTheme.bgType === 'video' ? 'block' : 'none'};">
            <label style="display:block; font-weight:bold; margin-bottom:0.35rem; font-size:0.8rem; color:#fff;">آدرس اینترنتی فایل ویدیو پس‌زمینه (URL)</label>
            <input type="text" id="bg-video-url" value="${escapeHtml(storedTheme.bgVideoUrl || '')}" placeholder="https://example.com/video.mp4" style="width:100%; padding:0.5rem; border-radius:8px; background:rgba(255,255,255,0.05); color:#fff; border:1px solid rgba(255,255,255,0.1); direction:ltr;" />
          </div>

          <div style="display:flex; align-items:center; gap:0.5rem; color:#fff; font-size:0.82rem;">
            <input type="checkbox" id="hide-bubbles" ${storedTheme.hideBubbles ? 'checked' : ''} style="width:16px; height:16px; cursor:pointer;" />
            <label for="hide-bubbles" style="cursor:pointer;">پنهان کردن افکت حباب‌های معلق در فضا</label>
          </div>

          <button type="submit" class="avina-crm-btn" style="align-self:flex-start; padding:0.5rem 1.5rem; font-weight:bold; margin-top:0.5rem;">ذخیره تنظیمات تم</button>
        </form>
      `;
    }

    if (activeTab === 'templates') {
      const t = settings.message_templates;
      return `
        <form id="msg-templates-form" style="display:flex; flex-direction:column; gap:1.25rem;">
          <h4 style="margin:0; color:#fff; font-size:0.85rem;">ویرایش متن پیش‌فرض دکمه‌های پیام سریع</h4>
          <p style="font-size:0.72rem; color:var(--avina-text-muted); margin:0;">شما می‌توانید از برچسب <strong>[date]</strong> در هر متن استفاده کنید تا تاریخ روز به صورت خودکار جایگزین شود.</p>
          
          <div style="display:flex; flex-direction:column; gap:0.75rem;">
            <label style="color:#fff; font-size:0.8rem;">قالب ۱ (پیام آدرس دفتر)</label>
            <textarea id="tpl-1" rows="2" style="width:100%; padding:0.5rem; border-radius:8px; background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.12); color:#fff; font-family:inherit;">${escapeHtml(t.template_1 || '')}</textarea>
            
            <label style="color:#fff; font-size:0.8rem;">قالب ۲ (پیام پیگیری حضور)</label>
            <textarea id="tpl-2" rows="2" style="width:100%; padding:0.5rem; border-radius:8px; background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.12); color:#fff; font-family:inherit;">${escapeHtml(t.template_2 || '')}</textarea>

            <label style="color:#fff; font-size:0.8rem;">قالب ۳ (پیام تبریک خرید موفق)</label>
            <textarea id="tpl-3" rows="2" style="width:100%; padding:0.5rem; border-radius:8px; background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.12); color:#fff; font-family:inherit;">${escapeHtml(t.template_3 || '')}</textarea>

            <label style="color:#fff; font-size:0.8rem;">قالب ۴ (پیام در انتظار حضور)</label>
            <textarea id="tpl-4" rows="2" style="width:100%; padding:0.5rem; border-radius:8px; background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.12); color:#fff; font-family:inherit;">${escapeHtml(t.template_4 || '')}</textarea>

            <label style="color:#fff; font-size:0.8rem;">قالب ۵ (پیام معرفی دیگر محصولات)</label>
            <textarea id="tpl-5" rows="2" style="width:100%; padding:0.5rem; border-radius:8px; background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.12); color:#fff; font-family:inherit;">${escapeHtml(t.template_5 || '')}</textarea>
          </div>

          <button type="submit" class="avina-crm-btn" style="align-self:flex-start; padding:0.5rem 1.5rem; font-weight:bold;">ذخیره الگوها</button>
        </form>
      `;
    }

    if (activeTab === 'products') {
      const prodRows = settings.products.map(p => `
        <div style="display:flex; justify-content:space-between; align-items:center; background:rgba(255,255,255,0.02); padding:0.5rem 0.75rem; border-radius:8px; border:1px solid rgba(255,255,255,0.05);">
          <span style="color:#fff; font-size:0.82rem;">${escapeHtml(p.name)}</span>
          <button class="avina-crm-btn secondary delete-prod-btn" data-id="${p.id}" style="padding:0.25rem 0.5rem; font-size:0.7rem; background:rgba(255,68,68,0.1); border-color:rgba(255,68,68,0.2); color:#fca5a5;">حذف</button>
        </div>
      `).join('');

      const servRows = settings.services.map(s => `
        <div style="display:flex; justify-content:space-between; align-items:center; background:rgba(255,255,255,0.02); padding:0.5rem 0.75rem; border-radius:8px; border:1px solid rgba(255,255,255,0.05);">
          <span style="color:#fff; font-size:0.82rem;">${escapeHtml(s.name)}</span>
          <button class="avina-crm-btn secondary delete-serv-btn" data-id="${s.id}" style="padding:0.25rem 0.5rem; font-size:0.7rem; background:rgba(255,68,68,0.1); border-color:rgba(255,68,68,0.2); color:#fca5a5;">حذف</button>
        </div>
      `).join('');

      return `
        <div style="display:grid; grid-template-columns:1fr 1fr; gap:1.5rem;">
          <!-- Products -->
          <div style="display:flex; flex-direction:column; gap:1rem;">
            <h4 style="margin:0; color:#fff; font-size:0.88rem; border-bottom:1px solid rgba(255,255,255,0.06); padding-bottom:0.4rem;">📦 مدیریت کاتالوگ محصولات</h4>
            
            <div style="display:flex; gap:0.4rem;">
              <input type="text" id="new-prod-name" placeholder="نام محصول جدید" style="flex:1; padding:0.45rem; background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.12); color:#fff; border-radius:8px; font-size:0.8rem;" />
              <button class="avina-crm-btn" id="add-prod-btn" style="font-size:0.75rem;">افزودن</button>
            </div>

            <div style="display:flex; flex-direction:column; gap:0.4rem; max-height:220px; overflow-y:auto;">
              ${prodRows || '<div style="color:rgba(255,255,255,0.25); font-size:0.75rem; text-align:center; padding:1rem;">محصولی ثبت نشده است.</div>'}
            </div>
          </div>

          <!-- Services -->
          <div style="display:flex; flex-direction:column; gap:1rem;">
            <h4 style="margin:0; color:#fff; font-size:0.88rem; border-bottom:1px solid rgba(255,255,255,0.06); padding-bottom:0.4rem;">🛠️ مدیریت کاتالوگ خدمات</h4>
            
            <div style="display:flex; gap:0.4rem;">
              <input type="text" id="new-serv-name" placeholder="نام خدمت جدید" style="flex:1; padding:0.45rem; background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.12); color:#fff; border-radius:8px; font-size:0.8rem;" />
              <button class="avina-crm-btn" id="add-serv-btn" style="font-size:0.75rem;">افزودن</button>
            </div>

            <div style="display:flex; flex-direction:column; gap:0.4rem; max-height:220px; overflow-y:auto;">
              ${servRows || '<div style="color:rgba(255,255,255,0.25); font-size:0.75rem; text-align:center; padding:1rem;">خدمتی ثبت نشده است.</div>'}
            </div>
          </div>
        </div>
      `;
    }

    if (activeTab === 'kanban') {
      const kb = settings.kanban_settings;
      const kp = settings.keypad_settings;

      const keypadRows = Object.entries(kp.keys).map(([num, data]) => `
        <div style="display:grid; grid-template-columns:60px 140px 1fr; gap:0.5rem; align-items:center; background:rgba(255,255,255,0.02); padding:0.4rem; border-radius:8px;">
          <strong style="color:var(--avina-primary); font-size:0.95rem; text-align:center;">کلید ${num}</strong>
          <select class="kp-channel" data-num="${num}" style="padding:0.35rem; background:rgba(0,0,0,0.3); border:1px solid rgba(255,255,255,0.12); color:#fff; border-radius:6px; font-size:0.75rem; font-family:inherit;">
            <option value="sms" ${data.channel === 'sms' ? 'selected' : ''}>پیامک (SMS)</option>
            <option value="eitaa" ${data.channel === 'eitaa' ? 'selected' : ''}>ایتا</option>
            <option value="whatsapp" ${data.channel === 'whatsapp' ? 'selected' : ''}>واتساپ</option>
          </select>
          <input type="text" class="kp-tpl" data-num="${num}" value="${escapeHtml(data.template)}" placeholder="متن پیام ارسال شونده..." style="padding:0.35rem; background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.12); color:#fff; border-radius:6px; font-size:0.75rem;" />
        </div>
      `).join('');

      return `
        <form id="kanban-settings-form" style="display:flex; flex-direction:column; gap:1.25rem;">
          <h4 style="margin:0; color:#fff; font-size:0.88rem; border-bottom:1px solid rgba(255,255,255,0.06); padding-bottom:0.4rem;">📋 تنظیمات بورد کانبان</h4>
          
          <div style="display:flex; gap:1.5rem;">
            <label style="display:flex; align-items:center; gap:0.5rem; color:#fff; font-size:0.82rem; cursor:pointer;">
              <input type="checkbox" id="kb-enabled" ${kb.enabled ? 'checked' : ''} style="width:16px; height:16px;" />
              فعال‌سازی بورد کانبان در پیشخوان
            </label>
            <label style="display:flex; align-items:center; gap:0.5rem; color:#fff; font-size:0.82rem; cursor:pointer;">
              <input type="checkbox" id="kb-dash-visible" ${kb.dashboard_visible ? 'checked' : ''} style="width:16px; height:16px;" />
              نمایش پیش‌فرض کانبان در داشبورد اپراتور
            </label>
          </div>

          <h4 style="margin:1rem 0 0 0; color:#fff; font-size:0.88rem; border-bottom:1px solid rgba(255,255,255,0.06); padding-bottom:0.4rem;">📱 سناریوهای کلیدهای کی‌پد دستگاه ۰ تا ۹</h4>
          
          <div style="display:flex; align-items:center; gap:0.5rem; margin-bottom:0.5rem;">
            <label style="color:#fff; font-size:0.8rem;">زمان خنک شدن ارسال مجدد (بازه Cooldown به ثانیه)</label>
            <input type="number" id="kp-cooldown" value="${kp.cooldown_seconds}" min="10" style="width:100px; padding:0.4rem; background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.12); color:#fff; border-radius:6px; text-align:center;" />
          </div>

          <div style="display:flex; flex-direction:column; gap:0.4rem; max-height:300px; overflow-y:auto; padding-left:0.5rem;">
            ${keypadRows}
          </div>

          <button type="submit" class="avina-crm-btn" style="align-self:flex-start; padding:0.5rem 1.5rem; font-weight:bold; margin-top:0.5rem;">ذخیره تنظیمات کانبان و کی‌پد</button>
        </form>
      `;
    }

    if (activeTab === 'ai') {
      return `
        <form id="ai-settings-form" style="display:flex; flex-direction:column; gap:1.25rem;">
          <h4 style="margin:0; color:#fff; font-size:0.88rem; border-bottom:1px solid rgba(255,255,255,0.06); padding-bottom:0.4rem;">🤖 تنظیمات اتصال به هوش مصنوعی Google Gemini</h4>
          
          <div style="display:flex; flex-direction:column; gap:0.75rem;">
            <label style="color:#fff; font-size:0.8rem;">کلید Gemini API Key (رایگان)</label>
            <input type="password" id="ai-api-key" value="${escapeHtml(settings.gemini_api_key || '')}" placeholder="AIzaSy..." style="width:100%; padding:0.5rem; border-radius:8px; background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.12); color:#fff; direction:ltr;" />
            <p style="font-size:0.7rem; color:var(--avina-text-muted); margin:0;">شما می‌توانید کلید رایگان خود را مستقیماً از Google AI Studio دریافت کنید.</p>

            <label style="color:#fff; font-size:0.8rem;">دستورالعمل سیستم دستیار (System Instruction)</label>
            <textarea id="ai-instructions" rows="4" style="width:100%; padding:0.5rem; border-radius:8px; background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.12); color:#fff; font-family:inherit;">${escapeHtml(settings.gemini_instruction || '')}</textarea>
          </div>

          <button type="submit" class="avina-crm-btn" style="align-self:flex-start; padding:0.5rem 1.5rem; font-weight:bold; margin-top:0.5rem;">ذخیره مشخصات هوش مصنوعی</button>
        </form>
      `;
    }
  }

  function bindTabEvents(storedTheme) {
    if (activeTab === 'theme') {
      const bgTypeSelect = container.querySelector('#bg-type');
      const bgImageWrapper = container.querySelector('#bg-image-wrapper');
      const bgVideoWrapper = container.querySelector('#bg-video-wrapper');

      bgTypeSelect.addEventListener('change', () => {
        const val = bgTypeSelect.value;
        bgImageWrapper.style.display = val === 'image' ? 'block' : 'none';
        bgVideoWrapper.style.display = val === 'video' ? 'block' : 'none';
      });

      const form = container.querySelector('#theme-settings-form');
      form.addEventListener('submit', (e) => {
        e.preventDefault();
        const primaryColor = form.querySelector('input[name="primaryColor"]:checked').value;
        const bgType = bgTypeSelect.value;
        const bgImageUrl = form.querySelector('#bg-image-url').value.trim();
        const bgVideoUrl = form.querySelector('#bg-video-url').value.trim();
        const hideBubbles = form.querySelector('#hide-bubbles').checked;

        const newSettings = { primaryColor, bgType, bgImageUrl, bgVideoUrl, hideBubbles };
        localStorage.setItem('avina_crm_theme_settings', JSON.stringify(newSettings));

        // Apply theme globally
        applyUserThemeGlobal(newSettings);
        alert('تنظیمات تم با موفقیت اعمال شد.');
      });
    }

    if (activeTab === 'templates') {
      const form = container.querySelector('#msg-templates-form');
      form.addEventListener('submit', async (e) => {
        e.preventDefault();
        const message_templates = {
          template_1: form.querySelector('#tpl-1').value.trim(),
          template_2: form.querySelector('#tpl-2').value.trim(),
          template_3: form.querySelector('#tpl-3').value.trim(),
          template_4: form.querySelector('#tpl-4').value.trim(),
          template_5: form.querySelector('#tpl-5').value.trim()
        };

        try {
          await apiPost('/settings', { message_templates });
          alert('الگوهای پیامک با موفقیت ذخیره شدند.');
          load();
        } catch (err) {
          alert('خطا در ذخیره‌سازی: ' + err.message);
        }
      });
    }

    if (activeTab === 'products') {
      // Add Product
      container.querySelector('#add-prod-btn').addEventListener('click', async () => {
        const name = container.querySelector('#new-prod-name').value.trim();
        if (!name) return;
        try {
          await apiPost('/settings/products', { name });
          load();
        } catch (err) {
          alert(err.message);
        }
      });

      // Delete Product
      container.querySelectorAll('.delete-prod-btn').forEach(btn => {
        btn.addEventListener('click', async () => {
          if (!confirm('آیا این محصول حذف شود؟')) return;
          try {
            await apiRequest(`/settings/products/${btn.dataset.id}`, { method: 'DELETE' });
            load();
          } catch (err) {
            alert(err.message);
          }
        });
      });

      // Add Service
      container.querySelector('#add-serv-btn').addEventListener('click', async () => {
        const name = container.querySelector('#new-serv-name').value.trim();
        if (!name) return;
        try {
          await apiPost('/settings/services', { name });
          load();
        } catch (err) {
          alert(err.message);
        }
      });

      // Delete Service
      container.querySelectorAll('.delete-serv-btn').forEach(btn => {
        btn.addEventListener('click', async () => {
          if (!confirm('آیا این خدمت حذف شود؟')) return;
          try {
            await apiRequest(`/settings/services/${btn.dataset.id}`, { method: 'DELETE' });
            load();
          } catch (err) {
            alert(err.message);
          }
        });
      });
    }

    if (activeTab === 'kanban') {
      const form = container.querySelector('#kanban-settings-form');
      form.addEventListener('submit', async (e) => {
        e.preventDefault();
        
        // Assemble keypad object
        const keys = {};
        for (let i = 0; i <= 9; i++) {
          const channel = form.querySelector(`.kp-channel[data-num="${i}"]`).value;
          const template = form.querySelector(`.kp-tpl[data-num="${i}"]`).value.trim();
          keys[String(i)] = { channel, template };
        }

        const kanban_settings = {
          enabled: form.querySelector('#kb-enabled').checked,
          dashboard_visible: form.querySelector('#kb-dash-visible').checked,
          stages: settings.kanban_settings.stages // keep stages names/colors intact
        };

        const keypad_settings = {
          cooldown_seconds: Number(form.querySelector('#kp-cooldown').value),
          keys: keys
        };

        try {
          await apiPost('/settings', { kanban_settings, keypad_settings });
          alert('تنظیمات بورد و کی‌پد با موفقیت ذخیره شد.');
          load();
        } catch (err) {
          alert('خطا در ذخیره‌سازی: ' + err.message);
        }
      });
    }

    if (activeTab === 'ai') {
      const form = container.querySelector('#ai-settings-form');
      form.addEventListener('submit', async (e) => {
        e.preventDefault();
        const gemini_api_key = form.querySelector('#ai-api-key').value.trim();
        const gemini_instruction = form.querySelector('#ai-instructions').value.trim();

        try {
          await apiPost('/settings', { gemini_api_key, gemini_instruction });
          alert('کلید هوش مصنوعی جمینای با موفقیت ثبت گردید.');
          load();
        } catch (err) {
          alert('خطا در ثبت کلید: ' + err.message);
        }
      });
    }
  }

  function applyUserThemeGlobal(themeSettings) {
    const root = document.getElementById('avina-crm-root');
    if (!root) return;

    if (themeSettings.primaryColor) {
      document.documentElement.style.setProperty('--avina-primary', themeSettings.primaryColor);
    } else {
      document.documentElement.style.removeProperty('--avina-primary');
    }

    const existingVideo = document.getElementById('avina-crm-bg-video');
    if (existingVideo) existingVideo.remove();

    if (themeSettings.bgType === 'video' && themeSettings.bgVideoUrl) {
      const video = document.createElement('video');
      video.id = 'avina-crm-bg-video';
      video.src = themeSettings.bgVideoUrl;
      video.autoplay = true;
      video.loop = true;
      video.muted = true;
      video.playsInline = true;
      video.style.cssText = 'position:fixed;inset:0;width:100%;height:100%;object-fit:cover;z-index:-1;opacity:0.25;pointer-events:none;';
      document.body.appendChild(video);
      root.style.background = 'transparent';
      root.style.backgroundImage = 'none';
    } else if (themeSettings.bgType === 'image' && themeSettings.bgImageUrl) {
      root.style.backgroundImage = `linear-gradient(rgba(15, 23, 42, 0.82), rgba(2, 6, 23, 0.92)), url(${themeSettings.bgImageUrl})`;
      root.style.backgroundSize = 'cover';
      root.style.backgroundPosition = 'center';
      root.style.backgroundAttachment = 'fixed';
    } else {
      root.style.backgroundImage = '';
      root.style.background = 'radial-gradient(circle at 50% 50%, #0f172a 0%, #020617 100%)';
    }

    const bubbles = root.querySelector('.avina-crm-bg-bubbles');
    if (bubbles) {
      bubbles.style.display = themeSettings.hideBubbles ? 'none' : 'block';
    }
  }

  load();
}
