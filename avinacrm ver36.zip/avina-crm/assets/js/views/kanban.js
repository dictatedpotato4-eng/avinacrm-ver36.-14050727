import { apiGet, apiPost } from '../api-client.js';
import { escapeHtml, loadingHtml, errorHtml } from '../ui.js';

export async function renderKanban(container) {
  let pipelines = [];
  let activePipelineId = null;

  async function loadPipelines() {
    container.innerHTML = loadingHtml();
    try {
      pipelines = await apiGet('/pipelines');
      if (!pipelines.length) {
        container.innerHTML = '<div class="avina-crm-glass" style="padding:1.5rem;color:#fff;">هیچ پایپ‌لاینی ایجاد نشده است. ابتدا از بخش معاملات یک پایپ‌لاین بسازید.</div>';
        return;
      }
      activePipelineId = pipelines[0].id;
      loadBoard();
    } catch (err) {
      container.innerHTML = errorHtml(err.message);
    }
  }

  async function loadBoard() {
    const boardContainer = document.getElementById('avina-kanban-board-inner') || container;
    try {
      const columns = await apiGet(`/deals/board?pipeline_id=${activePipelineId}`);
      drawBoard(columns);
    } catch (err) {
      boardContainer.innerHTML = errorHtml(err.message);
    }
  }

  function drawBoard(columns) {
    const pipelineOptions = pipelines
      .map((p) => `<option value="${p.id}" ${p.id === activePipelineId ? 'selected' : ''}>${escapeHtml(p.name)}</option>`)
      .join('');

    const columnsHtml = columns
      .map(
        (col) => `
      <div class="avina-kanban-column" data-stage-id="${col.stage.id}">
        <div class="avina-kanban-column__header" style="border-top:3px solid ${escapeHtml(col.stage.color || 'var(--avina-primary)')}; padding-top: 0.5rem;">
          <strong style="color:#fff;font-size:0.9rem;">${escapeHtml(col.stage.name)}</strong>
          <span style="font-size:0.75rem;color:var(--avina-text-muted);margin-top:0.2rem;">${col.count} مورد — ${Number(col.total_value).toLocaleString('fa-IR')} ریال</span>
        </div>
        <div class="avina-kanban-column__body" data-drop-zone="${col.stage.id}">
          ${col.deals.map(cardHtml).join('')}
        </div>
      </div>`
      )
      .join('');

    container.innerHTML = `
      <div class="avina-kanban-board-wrapper" style="width:100%;display:flex;flex-direction:column;gap:1rem;">
        <div class="avina-crm-toolbar" style="display:flex;justify-content:space-between;align-items:center;margin-bottom:0.5rem;flex-wrap:wrap;gap:0.75rem;">
          <div style="display:flex;align-items:center;gap:0.5rem;">
            <label style="font-size:0.8rem;color:var(--avina-text-muted);">انتخاب فرآیند:</label>
            <select id="kb-pipeline" style="background:rgba(0,0,0,0.3);border:1px solid rgba(255,255,255,0.12);padding:0.45rem;color:#fff;border-radius:8px;font-family:inherit;font-size:0.85rem;">
              ${pipelineOptions}
            </select>
          </div>
          <button class="avina-crm-btn" id="kb-fullscreen-btn" style="padding:0.45rem 0.85rem;background:rgba(255,255,255,0.08);border:1px solid rgba(255,255,255,0.15);font-size:0.8rem;display:flex;align-items:center;gap:0.35rem;">🖥️ تمام‌صفحه کردن بورد</button>
        </div>
        <div id="avina-kanban-board-inner" class="avina-kanban-board">${columnsHtml}</div>
      </div>
    `;

    // Event listeners
    container.querySelector('#kb-pipeline').addEventListener('change', (e) => {
      activePipelineId = Number(e.target.value);
      loadBoard();
    });

    // Fullscreen support
    const wrapper = container.querySelector('.avina-kanban-board-wrapper');
    const fullscreenBtn = container.querySelector('#kb-fullscreen-btn');
    fullscreenBtn.addEventListener('click', () => {
      if (!document.fullscreenElement) {
        wrapper.requestFullscreen().then(() => {
          fullscreenBtn.textContent = '❌ خروج از تمام‌صفحه';
        }).catch((err) => {
          alert(`خطا در تمام‌صفحه کردن بورد: ${err.message}`);
        });
      } else {
        document.exitFullscreen();
        fullscreenBtn.textContent = '🖥️ تمام‌صفحه کردن بورد';
      }
    });

    // Handle exiting fullscreen via Esc key
    document.addEventListener('fullscreenchange', () => {
      if (!document.fullscreenElement) {
        fullscreenBtn.innerHTML = '🖥️ تمام‌صفحه کردن بورد';
      }
    });

    // Live color tag selection listeners
    container.querySelectorAll('.avina-card-color-tag').forEach(tag => {
      tag.addEventListener('click', (e) => {
        e.stopPropagation();
        const card = tag.closest('.avina-kanban-card');
        const dealId = card.dataset.dealId;
        const color = tag.dataset.color;
        const glow = tag.dataset.glow;
        
        localStorage.setItem(`avina_deal_color_${dealId}`, color);
        localStorage.setItem(`avina_deal_glow_${dealId}`, glow);
        
        card.style.setProperty('--card-color', color);
        card.style.setProperty('--card-color-glow', glow);
      });
    });

    wireDragAndDrop();
  }

  function cardHtml(deal) {
    const savedColor = localStorage.getItem(`avina_deal_color_${deal.id}`) || '#6366f1';
    const savedGlow = localStorage.getItem(`avina_deal_glow_${deal.id}`) || 'rgba(99, 102, 241, 0.12)';
    const assignee = deal.assignee_name || 'مدیر سیستم';
    const desc = deal.description || 'در انتظار پیگیری اول و هماهنگی جلسه دمو حضوری با مشتری';
    const phone = deal.contact_phone || '09120000000';

    return `
      <div class="avina-kanban-card avina-crm-glass" draggable="true" data-deal-id="${deal.id}" style="--card-color:${savedColor}; --card-color-glow:${savedGlow};">
        <strong style="display:block;font-size:0.88rem;margin-bottom:0.35rem;color:#fff;">${escapeHtml(deal.title)}</strong>
        <div style="font-size:0.78rem;color:var(--avina-text-muted);margin-bottom:0.5rem;display:flex;justify-content:space-between;">
          <span>ارزش: ${Number(deal.value || 0).toLocaleString('fa-IR')} ریال</span>
          <span style="color:var(--card-color);font-weight:600;">★</span>
        </div>
        <div style="font-size:0.73rem;color:rgba(255,255,255,0.7);margin-bottom:0.6rem;background:rgba(255,255,255,0.02);padding:0.35rem;border-radius:6px;border-right:3px solid var(--card-color);line-height:1.45;">
          ${escapeHtml(desc)}
        </div>
        <div style="display:flex;justify-content:space-between;align-items:center;margin-top:0.75rem;">
          <span style="font-size:0.68rem;color:var(--avina-text-muted);">مسئول: ${escapeHtml(assignee)}</span>
          <div style="display:flex;align-items:center;gap:0.45rem;">
            <a href="tel:${phone}" title="تماس سریع" style="text-decoration:none;font-size:0.85rem;">📞</a>
            <a href="https://wa.me/${phone.replace(/^0/, '98')}" target="_blank" rel="noopener" title="پیام واتساپ" style="text-decoration:none;font-size:0.85rem;">🟢</a>
            <a href="https://eitaa.com" target="_blank" rel="noopener" title="کانال ایتا" style="text-decoration:none;font-size:0.85rem;">🔵</a>
          </div>
        </div>
        <div class="avina-card-color-tags">
          <div class="avina-card-color-tag" data-color="#ef4444" data-glow="rgba(239, 68, 68, 0.25)" style="background:#ef4444;" title="اولویت فوری"></div>
          <div class="avina-card-color-tag" data-color="#eab308" data-glow="rgba(234, 179, 8, 0.25)" style="background:#eab308;" title="اولویت بالا"></div>
          <div class="avina-card-color-tag" data-color="#3b82f6" data-glow="rgba(59, 130, 246, 0.25)" style="background:#3b82f6;" title="اولویت عادی"></div>
          <div class="avina-card-color-tag" data-color="#10b981" data-glow="rgba(16, 185, 129, 0.25)" style="background:#10b981;" title="موفق"></div>
          <div class="avina-card-color-tag" data-color="#ec4899" data-glow="rgba(236, 72, 153, 0.25)" style="background:#ec4899;" title="علاقه‌مند"></div>
        </div>
      </div>
    `;
  }

  function wireDragAndDrop() {
    let draggedDealId = null;

    container.querySelectorAll('.avina-kanban-card').forEach((card) => {
      card.addEventListener('dragstart', () => {
        draggedDealId = card.dataset.dealId;
        card.classList.add('is-dragging');
      });
      card.addEventListener('dragend', () => card.classList.remove('is-dragging'));
    });

    container.querySelectorAll('[data-drop-zone]').forEach((zone) => {
      zone.addEventListener('dragover', (e) => {
        e.preventDefault();
        zone.classList.add('is-drop-target');
      });
      zone.addEventListener('dragleave', () => zone.classList.remove('is-drop-target'));
      zone.addEventListener('drop', async (e) => {
        e.preventDefault();
        zone.classList.remove('is-drop-target');
        const targetStageId = Number(zone.dataset.dropZone);

        if (!draggedDealId) return;

        try {
          await apiPost(`/deals/${draggedDealId}/stage`, { stage_id: targetStageId });
          loadBoard();
        } catch (err) {
          alert(err.message);
          loadBoard();
        }
      });
    });
  }

  loadPipelines();
}
