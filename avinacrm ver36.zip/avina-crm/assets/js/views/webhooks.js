import { apiGet, apiPost, apiRequest } from '../api-client.js';
import { escapeHtml, formatDateTime, loadingHtml, emptyHtml, errorHtml } from '../ui.js';
import { openFormModal } from '../modal.js';

const EVENT_LABELS = {
  'deal.stage_changed': 'تغییر مرحله معامله',
  'deal.won': 'برد معامله',
  'deal.lost': 'باخت معامله',
  'invoice.paid': 'پرداخت فاکتور',
  'ticket.created': 'ایجاد درخواست',
};

export async function renderWebhooks(container) {
  let availableEvents = [];

  async function load() {
    container.innerHTML = loadingHtml();
    try {
      const result = await apiGet('/webhooks');
      availableEvents = result.available_events;
      draw(result.items);
    } catch (err) {
      container.innerHTML = errorHtml(err.message);
    }
  }

  function draw(items) {
    container.innerHTML = `
      <div class="avina-crm-toolbar">
        <button class="avina-crm-btn" id="wh-new">وب‌هوک جدید</button>
      </div>
      <div class="avina-crm-glass" style="padding:1rem;">
        ${items.length ? items.map(card).join('') : emptyHtml('وب‌هوکی ثبت نشده است.')}
      </div>
      <div id="wh-logs"></div>
    `;

    container.querySelector('#wh-new').addEventListener('click', openCreate);

    container.querySelectorAll('[data-toggle]').forEach((btn) => {
      btn.addEventListener('click', async () => {
        try {
          await apiRequest(`/webhooks/${btn.dataset.toggle}`, { method: 'PATCH', body: { is_active: btn.dataset.nextState === '1' } });
          load();
        } catch (err) {
          alert(err.message);
        }
      });
    });

    container.querySelectorAll('[data-delete]').forEach((btn) => {
      btn.addEventListener('click', async () => {
        if (!confirm('این وب‌هوک حذف شود؟')) return;
        try {
          await apiRequest(`/webhooks/${btn.dataset.delete}`, { method: 'DELETE' });
          load();
        } catch (err) {
          alert(err.message);
        }
      });
    });

    container.querySelectorAll('[data-logs]').forEach((btn) => {
      btn.addEventListener('click', () => showLogs(btn.dataset.logs));
    });
  }

  function card(wh) {
    const events = wh.event_types.map((e) => EVENT_LABELS[e] || e).join('، ');
    return `
      <div style="margin-bottom:1rem;padding-bottom:1rem;border-bottom:1px solid var(--avina-border);">
        <strong>${escapeHtml(wh.name)}</strong>
        <span class="avina-crm-status avina-crm-status--${wh.is_active ? 'done' : 'cancelled'}">${wh.is_active ? 'فعال' : 'غیرفعال'}</span>
        <div class="avina-crm-muted">${escapeHtml(wh.target_url)}</div>
        <div class="avina-crm-muted">رویدادها: ${escapeHtml(events)}</div>
        <div style="display:flex;gap:.4rem;margin-top:.4rem;">
          <button class="avina-crm-btn secondary" data-toggle="${wh.id}" data-next-state="${wh.is_active ? '0' : '1'}">${wh.is_active ? 'غیرفعال‌سازی' : 'فعال‌سازی'}</button>
          <button class="avina-crm-btn secondary" data-logs="${wh.id}">تاریخچه ارسال</button>
          <button class="avina-crm-btn secondary" data-delete="${wh.id}">حذف</button>
        </div>
      </div>
    `;
  }

  async function showLogs(id) {
    const box = container.querySelector('#wh-logs');
    box.innerHTML = loadingHtml();
    try {
      const logs = await apiGet(`/webhooks/${id}/logs`);
      box.innerHTML = `
        <div class="avina-crm-glass" style="padding:1rem;margin-top:1rem;">
          <h4>تاریخچه ارسال</h4>
          ${logs.length ? logs.map((l) => `<div class="avina-crm-muted">${formatDateTime(l.created_at)} — ${escapeHtml(l.event_type)} — ${l.success ? 'موفق' : 'ناموفق'} (${l.response_status ?? '—'})</div>`).join('') : emptyHtml('ارسالی ثبت نشده است.')}
        </div>
      `;
    } catch (err) {
      box.innerHTML = errorHtml(err.message);
    }
  }

  function openCreate() {
    const options = availableEvents.map((e) => ({ value: e, label: EVENT_LABELS[e] || e }));

    openFormModal({
      title: 'وب‌هوک جدید',
      fields: [
        { name: 'name', label: 'نام', required: true },
        { name: 'target_url', label: 'آدرس مقصد (https://...)', required: true },
        {
          name: 'event_types',
          label: 'رویداد (برای انتخاب چند مورد، بعداً می‌توانید وب‌هوک دیگری بسازید)',
          type: 'select',
          options,
        },
      ],
      onSubmit: async (values) => {
        const result = await apiPost('/webhooks', { ...values, event_types: [values.event_types] });
        alert('کلید مخفی وب‌هوک (فقط یک‌بار نمایش داده می‌شود):\n\n' + result.secret);
        load();
      },
    });
  }

  load();
}
