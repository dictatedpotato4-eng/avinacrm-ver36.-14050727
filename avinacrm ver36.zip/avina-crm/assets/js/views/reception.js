import { apiGet, apiPost, apiRequest } from '../api-client.js';
import { escapeHtml, statusBadge, loadingHtml, emptyHtml, errorHtml } from '../ui.js';
import { openFormModal } from '../modal.js';

const STATUS_LABELS = {
  pending: 'در انتظار بررسی',
  inspecting: 'در حال عیب‌یابی',
  repaired: 'تعمیر شده',
  delivered: 'تحویل شده',
  cancelled: 'لغو پذیرش',
};

export async function renderReception(container) {
  let search = '';
  let status = '';
  let items = [];

  async function load() {
    container.innerHTML = loadingHtml();
    try {
      const query = new URLSearchParams();
      if (search) query.set('search', search);
      if (status) query.set('status', status);

      const res = await apiGet('/reception?' + query.toString());
      items = res || [];

      draw();
    } catch (err) {
      container.innerHTML = errorHtml(err.message);
    }
  }

  function draw() {
    const statusOptions = Object.entries(STATUS_LABELS)
      .map(([v, l]) => `<option value="${v}" ${status === v ? 'selected' : ''}>${escapeHtml(l)}</option>`)
      .join('');

    container.innerHTML = `
      <div class="avina-crm-toolbar" style="display:flex; gap:0.75rem; align-items:center; margin-bottom:1.5rem; flex-wrap:wrap;">
        <input type="search" id="rc-search" placeholder="جستجوی مشتری یا مدل کارتخوان" value="${escapeHtml(search)}" style="flex:1; min-width:200px; background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.12); padding:0.55rem; color:#fff; border-radius:10px;" />
        <select id="rc-status" style="background:rgba(0,0,0,0.3); border:1px solid rgba(255,255,255,0.12); padding:0.55rem; color:#fff; border-radius:10px; font-family:inherit;">
          <option value="">همه وضعیت‌ها</option>
          ${statusOptions}
        </select>
        <button class="avina-crm-btn" id="rc-refresh">🔄 به‌روزرسانی</button>
        <button class="avina-crm-btn" id="rc-new" style="background:var(--avina-primary); box-shadow:0 0 10px var(--avina-primary);">＋ ثبت پذیرش کارتخوان</button>
        <button class="avina-crm-btn secondary" id="rc-export" style="background:rgba(255,255,255,0.05); border-color:rgba(255,255,255,0.1);">📥 دانلود گزارش اکسل</button>
      </div>

      <div class="avina-crm-glass" style="padding:1rem; overflow-x:auto;">
        ${items.length ? renderTable() : emptyHtml('هیچ دستگاه کارتخوانی در انتظار تعمیر یا پذیرش نیست.')}
      </div>
    `;

    container.querySelector('#rc-search').addEventListener('input', (e) => {
      search = e.target.value;
      debounce(load, 400)();
    });
    container.querySelector('#rc-status').addEventListener('change', (e) => {
      status = e.target.value;
      load();
    });
    container.querySelector('#rc-refresh').addEventListener('click', load);
    container.querySelector('#rc-new').addEventListener('click', openCreate);
    container.querySelector('#rc-export').addEventListener('click', () => {
      window.open(`${window.AvinaCrmConfig.restUrl}/reception/export`, '_blank');
    });

    bindActions();
  }

  function renderTable() {
    const rows = items.map(c => `
      <tr data-id="${c.id}">
        <td style="padding:1rem 0.5rem; font-weight:700; color:#fff;">${escapeHtml(c.customer_name)}</td>
        <td style="font-size:0.85rem; font-weight:bold;">${escapeHtml(c.device_model)}</td>
        <td style="font-size:0.8rem; color:rgba(255,255,255,0.6);">${escapeHtml(c.intake_date)}</td>
        <td style="font-size:0.78rem; max-width:200px; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; color:rgba(255,255,255,0.8);" title="${escapeHtml(c.issue)}">
          ${escapeHtml(c.issue)}
        </td>
        <td style="font-size:0.75rem; color:rgba(255,255,255,0.5);">${escapeHtml(c.accessories || '—')}</td>
        <td>
          <span class="avina-crm-badge" style="background:${statusColor(c.status)}; color:#fff; font-size:0.7rem; padding:0.25rem 0.5rem; border-radius:6px;">
            ${STATUS_LABELS[c.status] || c.status}
          </span>
        </td>
        <td>
          <div style="display:flex; gap:0.4rem;">
            <button class="avina-crm-btn secondary rc-action-status" data-id="${c.id}">⚙️ وضعیت</button>
            <button class="avina-crm-btn secondary rc-action-kanban" data-id="${c.id}">📋 کار</button>
            <button class="avina-crm-btn secondary rc-action-edit" data-id="${c.id}">📝 ویرایش</button>
          </div>
        </td>
      </tr>
    `).join('');

    return `
      <table class="avina-crm-table" style="width:100%; border-collapse:collapse; text-align:right;">
        <thead>
          <tr style="border-bottom:1px solid rgba(255,255,255,0.08); font-size:0.78rem; color:var(--avina-text-muted);">
            <th style="padding:0.75rem 0.5rem;">نام مشتری</th>
            <th>مدل دستگاه</th>
            <th>تاریخ پذیرش</th>
            <th>شرح ایراد</th>
            <th>متعلقات همراه</th>
            <th>وضعیت</th>
            <th>عملیات فنی</th>
          </tr>
        </thead>
        <tbody>
          ${rows}
        </tbody>
      </table>
    `;
  }

  function statusColor(st) {
    if (st === 'pending') return 'rgba(234,179,8,0.15)'; // yellow
    if (st === 'inspecting') return 'rgba(59,130,246,0.15)'; // blue
    if (st === 'repaired') return 'rgba(16,185,129,0.15)'; // green
    if (st === 'delivered') return 'rgba(99,102,241,0.15)'; // purple
    return 'rgba(239,68,68,0.15)'; // red
  }

  function bindActions() {
    container.querySelectorAll('.rc-action-status').forEach(btn => {
      btn.addEventListener('click', () => openChangeStatus(Number(btn.dataset.id)));
    });

    container.querySelectorAll('.rc-action-kanban').forEach(btn => {
      btn.addEventListener('click', () => openSendToKanban(Number(btn.dataset.id)));
    });

    container.querySelectorAll('.rc-action-edit').forEach(btn => {
      btn.addEventListener('click', () => openEdit(Number(btn.dataset.id)));
    });
  }

  function openChangeStatus(intakeId) {
    const item = items.find(i => i.id === intakeId);
    if (!item) return;

    openFormModal({
      title: '⚙️ تغییر وضعیت فنی دستگاه کارتخوان',
      fields: [
        { name: 'status', label: 'وضعیت جدید', type: 'select', options: Object.entries(STATUS_LABELS).map(([v, l]) => ({ value: v, label: l })), value: item.status }
      ],
      onSubmit: async (values) => {
        await apiPost(`/reception/${intakeId}/status`, { status: values.status });
        load();
      }
    });
  }

  function openSendToKanban(intakeId) {
    const item = items.find(i => i.id === intakeId);
    if (!item) return;

    openFormModal({
      title: `📋 انتقال پذیرش تعمیر کارتخوان به کانبان کارها`,
      fields: [
        { name: 'desc', label: 'شرح عیب‌یابی / وظیفه تعمیرکار', type: 'textarea', value: item.issue, required: true }
      ],
      onSubmit: async (values) => {
        // Create Kanban Task
        await apiPost('/contacts/1/kanban', { // Route via general helper
          operator_id: 1, // Default operator
          stage_id: 'lead',
          description: `[پذیرش دستگاه ${item.device_model} مشتری ${item.customer_name}]: ` + values.desc
        });
        alert('وظیفه با موفقیت در کانبان ثبت شد.');
        load();
      }
    });
  }

  function openEdit(intakeId) {
    const item = items.find(i => i.id === intakeId);
    if (!item) return;

    openFormModal({
      title: '📝 ویرایش مشخصات پذیرش دستگاه',
      fields: [
        { name: 'customer_name', label: 'نام مشتری', value: item.customer_name, required: true },
        { name: 'device_model', label: 'مدل دستگاه', value: item.device_model, required: true },
        { name: 'intake_date', label: 'تاریخ پذیرش', value: item.intake_date, required: true },
        { name: 'issue', label: 'شرح ایراد', type: 'textarea', value: item.issue, required: true },
        { name: 'accessories', label: 'متعلقات همراه', value: item.accessories || '' }
      ],
      onSubmit: async (values) => {
        await apiRequest(`/reception/${intakeId}`, { method: 'PATCH', body: values });
        load();
      }
    });
  }

  function openCreate() {
    openFormModal({
      title: '＋ ثبت پذیرش دستگاه کارتخوان جدید',
      fields: [
        { name: 'customer_name', label: 'نام مشتری', required: true },
        { name: 'device_model', label: 'مدل دستگاه کارتخوان', required: true },
        { name: 'intake_date', label: 'تاریخ پذیرش (شمسی YYYY-MM-DD)', value: current_date_input(), required: true },
        { name: 'issue', label: 'شرح ایراد و مشکل دستگاه', type: 'textarea', required: true },
        { name: 'accessories', label: 'متعلقات همراه (کیف، کابل شارژر...)', placeholder: 'مثال: کیف ضربه‌گیر به همراه شارژر اصلی' }
      ],
      onSubmit: async (values) => {
        await apiPost('/reception', values);
        load();
      }
    });
  }

  // Helpers
  function debounce(func, delay) {
    let timer;
    return function (...args) {
      clearTimeout(timer);
      timer = setTimeout(() => func.apply(this, args), delay);
    };
  }

  function current_date_input() {
    const today = new Date();
    const dd = String(today.getDate()).padStart(2, '0');
    const mm = String(today.getMonth() + 1).padStart(2, '0');
    const yyyy = today.getFullYear();
    return `${yyyy}-${mm}-${dd}`;
  }

  load();
}
