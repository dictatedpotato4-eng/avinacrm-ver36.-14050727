import { apiGet, apiPost } from '../api-client.js';
import { escapeHtml, statusBadge, formatDateTime, loadingHtml, emptyHtml, errorHtml } from '../ui.js';
import { openFormModal } from '../modal.js';

const STATUS_LABELS = { open: 'باز', in_progress: 'در حال بررسی', resolved: 'حل‌شده', closed: 'بسته‌شده' };
const PRIORITY_LABELS = { low: 'کم', normal: 'عادی', high: 'بالا', urgent: 'فوری' };

export async function renderTickets(container) {
  let openTicketId = null;

  async function load() {
    container.innerHTML = loadingHtml();
    try {
      const items = await apiGet('/tickets');
      draw(items);
    } catch (err) {
      container.innerHTML = errorHtml(err.message);
    }
  }

  function draw(items) {
    container.innerHTML = `
      <div class="avina-crm-toolbar">
        <button class="avina-crm-btn" id="tc-new">درخواست جدید</button>
      </div>
      <div class="avina-crm-glass" style="padding:1rem;">
        ${items.length ? table(items) : emptyHtml('درخواستی وجود ندارد.')}
      </div>
      <div id="tc-detail"></div>
    `;

    container.querySelector('#tc-new').addEventListener('click', openCreate);
    container.querySelectorAll('[data-open-ticket]').forEach((btn) => {
      btn.addEventListener('click', () => openThread(btn.dataset.openTicket));
    });
  }

  function table(items) {
    const rows = items
      .map(
        (t) => `
      <tr>
        <td><a href="#" data-open-ticket="${t.id}">${escapeHtml(t.subject)}</a></td>
        <td>${statusBadge(t.priority, PRIORITY_LABELS)}</td>
        <td>${statusBadge(t.status, STATUS_LABELS)}</td>
        <td>${formatDateTime(t.updated_at)}</td>
      </tr>`
      )
      .join('');

    return `<table class="avina-crm-table"><thead><tr><th>موضوع</th><th>اولویت</th><th>وضعیت</th><th>آخرین بروزرسانی</th></tr></thead><tbody>${rows}</tbody></table>`;
  }

  async function openThread(id) {
    openTicketId = id;
    const detail = container.querySelector('#tc-detail');
    detail.innerHTML = loadingHtml();

    try {
      const ticket = await apiGet(`/tickets/${id}`);
      drawThread(detail, ticket);
    } catch (err) {
      detail.innerHTML = errorHtml(err.message);
    }
  }

  function drawThread(detail, ticket) {
    const statusOptions = Object.entries(STATUS_LABELS)
      .map(([v, l]) => `<option value="${v}" ${ticket.status === v ? 'selected' : ''}>${escapeHtml(l)}</option>`)
      .join('');

    const replies = ticket.replies
      .map(
        (r) => `<div class="avina-crm-form-row" style="border-inline-start:2px solid var(--avina-border);padding-inline-start:.75rem;">
          <span class="avina-crm-muted">${formatDateTime(r.created_at)}</span>
          <span>${escapeHtml(r.body)}</span>
        </div>`
      )
      .join('');

    detail.innerHTML = `
      <div class="avina-crm-glass" style="padding:1.25rem;margin-top:1rem;">
        <h3>${escapeHtml(ticket.subject)}</h3>
        <p>${escapeHtml(ticket.body)}</p>
        <div class="avina-crm-toolbar">
          <select id="tc-status-select">${statusOptions}</select>
        </div>
        <h4>پاسخ‌ها</h4>
        ${replies || '<p class="avina-crm-muted">پاسخی ثبت نشده است.</p>'}
        <form id="tc-reply-form" class="avina-crm-form-row" style="margin-top:1rem;">
          <textarea id="tc-reply-body" rows="3" placeholder="پاسخ خود را بنویسید..." required></textarea>
          <button type="submit" class="avina-crm-btn" style="width:fit-content;">ارسال پاسخ</button>
        </form>
      </div>
    `;

    detail.querySelector('#tc-status-select').addEventListener('change', async (e) => {
      try {
        await apiPost(`/tickets/${ticket.id}/status`, { status: e.target.value });
        openThread(ticket.id);
      } catch (err) {
        alert(err.message);
      }
    });

    detail.querySelector('#tc-reply-form').addEventListener('submit', async (e) => {
      e.preventDefault();
      const body = detail.querySelector('#tc-reply-body').value;
      try {
        await apiPost(`/tickets/${ticket.id}/replies`, { body });
        openThread(ticket.id);
      } catch (err) {
        alert(err.message);
      }
    });
  }

  function openCreate() {
    openFormModal({
      title: 'درخواست جدید',
      fields: [
        { name: 'subject', label: 'موضوع', required: true },
        { name: 'body', label: 'متن درخواست', type: 'textarea', required: true },
        { name: 'priority', label: 'اولویت', type: 'select', options: Object.entries(PRIORITY_LABELS).map(([value, label]) => ({ value, label })) },
        { name: 'recipient_user_id', label: 'شناسه کاربری گیرنده (یا شناسه تیم را در فیلد بعد وارد کنید)' },
        { name: 'team_id', label: 'شناسه تیم (اختیاری)' },
      ],
      onSubmit: async (values) => {
        if (values.recipient_user_id) values.recipient_user_id = Number(values.recipient_user_id);
        else delete values.recipient_user_id;
        if (values.team_id) values.team_id = Number(values.team_id);
        else delete values.team_id;
        await apiPost('/tickets', values);
        load();
      },
    });
  }

  load();
}
