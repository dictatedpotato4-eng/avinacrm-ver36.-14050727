const routes = new Map();
let notFoundHandler = null;

export function registerRoute(path, handler) {
  routes.set(path, handler);
}

export function registerNotFound(handler) {
  notFoundHandler = handler;
}

export function currentPath() {
  return (window.location.hash || '#/dashboard').slice(1);
}

export function navigate(path) {
  window.location.hash = path;
}

export function startRouter(onChange) {
  const dispatch = () => {
    const path = currentPath();
    const handler = routes.get(path) || notFoundHandler;
    onChange(path);
    if (handler) {
      handler();
    }
  };

  window.addEventListener('hashchange', dispatch);
  dispatch();
}
