import { escapeHtml, initJalaliDatePicker } from './ui.js';

/**
 * @param {{
 *   title: string,
 *   fields: Array<{name:string,label:string,type?:string,options?:Array<{value:string,label:string}>,required?:boolean,placeholder?:string,step?:number}>,
 *   onSubmit: (values:Record<string,any>) => Promise<void>
 * }} config
 */
export function openFormModal(config) {
  const backdrop = document.createElement('div');
  backdrop.className = 'avina-crm-modal-backdrop';

  // Group fields by step
  const stepsMap = {};
  config.fields.forEach((field) => {
    const s = field.step || 1;
    if (!stepsMap[s]) {
      stepsMap[s] = [];
    }
    stepsMap[s].push(field);
  });

  const stepsList = Object.keys(stepsMap)
    .map(Number)
    .sort((a, b) => a - b);
  const totalSteps = stepsList.length;

  let currentStepIndex = 0;

  // Build HTML for each step
  const stepsHtml = stepsList
    .map((stepNum, idx) => {
      const fields = stepsMap[stepNum];
      const fieldsHtml = fields
        .map((field) => {
          const requiredAttr = field.required ? 'required' : '';
          const placeholderAttr = field.placeholder ? `placeholder="${escapeHtml(field.placeholder)}"` : '';

          if (field.type === 'checkbox') {
            return `
              <div class="avina-crm-form-row" style="display:flex;align-items:center;gap:0.5rem;margin-bottom:0.75rem;">
                <input id="avina-field-${field.name}" name="${field.name}" type="checkbox" value="1" />
                <label for="avina-field-${field.name}" style="margin:0;cursor:pointer;font-weight:600;">${escapeHtml(field.label)}</label>
              </div>`;
          }

          const label = `<label for="avina-field-${field.name}" style="display:block;font-weight:600;margin-bottom:0.25rem;">${escapeHtml(field.label)} ${field.required ? '<span style="color:red;">*</span>' : ''}</label>`;
          let input;

          if (field.type === 'textarea') {
            input = `<textarea id="avina-field-${field.name}" name="${field.name}" rows="3" ${requiredAttr} ${placeholderAttr} style="width:100%;padding:0.5rem;border:1px solid #cbd5e1;border-radius:4px;"></textarea>`;
          } else if (field.type === 'select') {
            const options = (field.options || [])
              .map((o) => `<option value="${escapeHtml(o.value)}">${escapeHtml(o.label)}</option>`)
              .join('');
            input = `<select id="avina-field-${field.name}" name="${field.name}" style="width:100%;padding:0.5rem;border:1px solid #cbd5e1;border-radius:4px;">${options}</select>`;
          } else if (field.type === 'file') {
            input = `<input id="avina-field-${field.name}" name="${field.name}" type="file" ${requiredAttr} style="width:100%;padding:0.25rem;" />`;
          } else if (field.type === 'date') {
            input = `<input id="avina-field-${field.name}" name="${field.name}" type="text" placeholder="مثال: ۱۴۰۵/۰۶/۰۵" ${requiredAttr} style="width:100%;padding:0.5rem;border:1px solid #cbd5e1;border-radius:4px;" />`;
          } else {
            input = `<input id="avina-field-${field.name}" name="${field.name}" type="${field.type || 'text'}" ${requiredAttr} ${placeholderAttr} style="width:100%;padding:0.5rem;border:1px solid #cbd5e1;border-radius:4px;" />`;
          }

          return `<div class="avina-crm-form-row" style="margin-bottom:0.75rem;">${label}${input}</div>`;
        })
        .join('');

      const activeStyle = idx === 0 ? '' : 'display:none;';
      return `
        <div class="avina-crm-step-container" data-step-index="${idx}" style="${activeStyle}">
          ${fieldsHtml}
        </div>
      `;
    })
    .join('');

  // Setup buttons
  const isMultiStep = totalSteps > 1;
  const submitText = isMultiStep ? 'ثبت نهایی' : 'ذخیره';
  const buttonsHtml = `
    <div style="display:flex;gap:.5rem;margin-top:1.5rem;justify-content:flex-start;width:100%;">
      ${isMultiStep ? `<button type="button" class="avina-crm-btn secondary" id="avina-modal-prev" style="display:none;">قبلی</button>` : ''}
      ${isMultiStep ? `<button type="button" class="avina-crm-btn" id="avina-modal-next">بعدی</button>` : ''}
      <button type="submit" class="avina-crm-btn" id="avina-modal-submit" style="${isMultiStep ? 'display:none;' : ''}">${submitText}</button>
      <button type="button" class="avina-crm-btn secondary" id="avina-modal-cancel">انصراف</button>
    </div>
  `;

  let progressHtml = '';
  if (isMultiStep) {
    progressHtml = `
      <div class="avina-crm-step-progress">
        ${stepsList.map((_, idx) => `<div class="avina-crm-step-progress-dot ${idx === 0 ? 'active' : ''}" data-dot-index="${idx}"></div>`).join('')}
      </div>
    `;
  }

  backdrop.innerHTML = `
    <div class="avina-crm-modal avina-crm-glass" role="dialog" aria-modal="true" aria-label="${escapeHtml(config.title)}" style="max-width:500px;width:95%;">
      <h2 style="margin-top:0;font-weight:700;border-bottom:1px solid rgba(255,255,255,0.08);padding-bottom:0.5rem;margin-bottom:1rem;">${escapeHtml(config.title)}</h2>
      ${progressHtml}
      <form id="avina-modal-form">
        <div id="avina-modal-steps-wrapper">
          ${stepsHtml}
        </div>
        <div class="avina-crm-error" id="avina-modal-error" style="color:red;font-weight:600;margin-top:0.5rem;" hidden></div>
        ${buttonsHtml}
      </form>
    </div>
  `;

  document.body.appendChild(backdrop);

  // Bind Jalali Datepicker to date inputs
  config.fields.forEach((field) => {
    if (field.type === 'date') {
      const inputElement = backdrop.querySelector(`[name="${field.name}"]`);
      if (inputElement) {
        initJalaliDatePicker(inputElement);
      }
    }
  });

  const close = () => backdrop.remove();

  backdrop.querySelector('#avina-modal-cancel').addEventListener('click', close);
  backdrop.addEventListener('click', (e) => {
    if (e.target === backdrop) close();
  });

  const form = backdrop.querySelector('#avina-modal-form');
  const errorBox = backdrop.querySelector('#avina-modal-error');
  const nextBtn = backdrop.querySelector('#avina-modal-next');
  const prevBtn = backdrop.querySelector('#avina-modal-prev');
  const submitBtn = backdrop.querySelector('#avina-modal-submit');
  const stepContainers = backdrop.querySelectorAll('.avina-crm-step-container');

  function updateStepsUI() {
    stepContainers.forEach((container, idx) => {
      container.style.display = idx === currentStepIndex ? 'block' : 'none';
    });

    const dots = backdrop.querySelectorAll('.avina-crm-step-progress-dot');
    dots.forEach((dot, idx) => {
      if (idx <= currentStepIndex) {
        dot.classList.add('active');
      } else {
        dot.classList.remove('active');
      }
    });

    if (isMultiStep) {
      prevBtn.style.display = currentStepIndex > 0 ? 'inline-block' : 'none';
      if (currentStepIndex === totalSteps - 1) {
        nextBtn.style.display = 'none';
        submitBtn.style.display = 'inline-block';
      } else {
        nextBtn.style.display = 'inline-block';
        submitBtn.style.display = 'none';
      }
    }
  }

  if (isMultiStep) {
    nextBtn.addEventListener('click', () => {
      // Validate inputs of current step container only
      const currentContainer = stepContainers[currentStepIndex];
      const inputs = currentContainer.querySelectorAll('input, select, textarea');
      let stepValid = true;
      for (const input of inputs) {
        if (!input.reportValidity()) {
          stepValid = false;
          break;
        }
      }
      if (stepValid && currentStepIndex < totalSteps - 1) {
        currentStepIndex++;
        updateStepsUI();
      }
    });

    prevBtn.addEventListener('click', () => {
      if (currentStepIndex > 0) {
        currentStepIndex--;
        updateStepsUI();
      }
    });
  }

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    errorBox.hidden = true;

    // Show loading state
    const originalSubmitText = submitBtn.textContent;
    submitBtn.textContent = 'در حال ذخیره...';
    submitBtn.disabled = true;

    const values = {};

    try {
      // Process and upload files if any
      for (const field of config.fields) {
        const inputElement = form.querySelector(`[name="${field.name}"]`);
        if (!inputElement) continue;

        if (field.type === 'checkbox') {
          values[field.name] = inputElement.checked ? '1' : '0';
        } else if (field.type === 'file') {
          if (inputElement.files && inputElement.files.length > 0) {
            // Upload to WordPress media library via REST API
            const file = inputElement.files[0];
            const formData = new FormData();
            formData.append('file', file);

            const wpNonce = window.wpApiSettings ? window.wpApiSettings.nonce : '';

            const uploadRes = await fetch('/wp-json/wp/v2/media', {
              method: 'POST',
              headers: {
                'X-WP-Nonce': wpNonce
              },
              body: formData
            });

            if (!uploadRes.ok) {
              const errData = await uploadRes.json();
              throw new Error(errData.message || 'خطا در آپلود فایل');
            }

            const media = await uploadRes.json();
            values[field.name] = media.source_url; // Set uploaded file URL as value
          } else {
            values[field.name] = '';
          }
        } else {
          values[field.name] = inputElement.value;
        }
      }

      await config.onSubmit(values);
      close();
    } catch (err) {
      errorBox.hidden = false;
      errorBox.textContent = err && err.message ? err.message : 'خطایی رخ داد.';
      submitBtn.textContent = originalSubmitText;
      submitBtn.disabled = false;
    }
  });
}

