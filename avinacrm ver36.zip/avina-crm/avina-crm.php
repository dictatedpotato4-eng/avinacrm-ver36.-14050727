<?php
/**
 * Plugin Name: Avina CRM
 * Plugin URI:  https://example.com/avina-crm
 * Description: آوینا CRM — سامانه مدیریت ارتباط با مشتری بومی برای وردپرس فارسی.
 * Version:     8.3.5
 * Requires at least: 6.0
 * Requires PHP: 8.1
 * Author:      Avina CRM Team
 * Text Domain: avina-crm
 * Domain Path: /languages
 *
 * IMPORTANT: this file itself must stay PHP-7.4-safe (no typed properties,
 * no constructor promotion, no union types, no match expressions) so that
 * it can run the version check below and print a clean admin notice on an
 * incompatible host, instead of a raw PHP fatal error. Every file it
 * requires beyond this point is allowed to use PHP 8.1 syntax freely,
 * because by the time we require() anything else we have already
 * confirmed PHP_VERSION_ID is high enough.
 */

if (!defined('ABSPATH')) {
    exit; // Direct access is never allowed.
}

define('AVINA_CRM_VERSION', '8.3.5');
define('AVINA_CRM_MIN_PHP', '8.1.0');
define('AVINA_CRM_FILE', __FILE__);
define('AVINA_CRM_DIR', plugin_dir_path(__FILE__));
define('AVINA_CRM_URL', plugin_dir_url(__FILE__));
define('AVINA_CRM_BASENAME', plugin_basename(__FILE__));

/**
 * Stage 1 decision #1: PHP 8.1+ is the hard minimum. We never attempt to
 * degrade behavior for older PHP; we refuse to run at all and say so
 * clearly in Persian, in wp-admin, without ever loading a PHP 8-only file.
 */
function avina_crm_php_version_ok()
{
    return version_compare(PHP_VERSION, AVINA_CRM_MIN_PHP, '>=');
}

function avina_crm_php_incompatible_notice()
{
    $message = sprintf(
        /* translators: 1: required PHP version, 2: current PHP version */
        esc_html__('افزونه آوینا CRM غیرفعال است زیرا این سایت از PHP %2$s استفاده می‌کند، در حالی که حداقل نسخه مورد نیاز PHP %1$s است. لطفاً نسخه PHP هاست خود را ارتقا دهید.', 'avina-crm'),
        AVINA_CRM_MIN_PHP,
        PHP_VERSION
    );
    echo '<div class="notice notice-error"><p>' . $message . '</p></div>';
}

if (!avina_crm_php_version_ok()) {
    add_action('admin_notices', 'avina_crm_php_incompatible_notice');

    // If somehow active on an incompatible host (e.g. host downgraded PHP
    // after activation), force-deactivate on the next admin load instead
    // of leaving a half-broken plugin active.
    add_action('admin_init', function () {
        if (is_plugin_active(AVINA_CRM_BASENAME)) {
            deactivate_plugins(AVINA_CRM_BASENAME);
        }
    });

    return;
}

require_once AVINA_CRM_DIR . 'includes/Kernel/Autoloader.php';
\AvinaCRM\Kernel\Autoloader::register();

/**
 * Activation: idempotent. Safe to run repeatedly (e.g. multisite network
 * activation, or a host that calls the hook twice) without ever
 * duplicating roles, capabilities, or table rows, and without ever
 * touching existing CRM data.
 */
register_activation_hook(__FILE__, function () {
    if (!avina_crm_php_version_ok()) {
        deactivate_plugins(AVINA_CRM_BASENAME);
        wp_die(
            esc_html(sprintf(
                'Avina CRM requires PHP %s or higher. This server is running PHP %s.',
                AVINA_CRM_MIN_PHP,
                PHP_VERSION
            )),
            'Avina CRM — Incompatible PHP',
            array('back_link' => true)
        );
    }

    \AvinaCRM\Kernel\Plugin::instance()->activate();
});

/**
 * Deactivation never deletes data. It only flushes rewrite rules and
 * clears transient/runtime state, per Stage 1 decision #5 and the
 * Stage 2 instruction "deactivation does not delete data".
 */
register_deactivation_hook(__FILE__, function () {
    \AvinaCRM\Kernel\Plugin::instance()->deactivate();
});

add_action('plugins_loaded', function () {
    if (!avina_crm_php_version_ok()) {
        return;
    }

    load_plugin_textdomain('avina-crm', false, dirname(AVINA_CRM_BASENAME) . '/languages');

    \AvinaCRM\Kernel\Plugin::instance()->init();
});

add_action('avina_crm_daily_sms_cron', function () {
    if (avina_crm_php_version_ok()) {
        $smsService = new \AvinaCRM\SMS\SmsService();
        $smsService->processScheduledSmsQueue();
    }
});

if (!wp_next_scheduled('avina_crm_daily_sms_cron')) {
    wp_schedule_event(time(), 'hourly', 'avina_crm_daily_sms_cron');
}
