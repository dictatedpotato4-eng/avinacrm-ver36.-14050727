<?php

declare(strict_types=1);

namespace AvinaCRM\Support;

/**
 * Locates (and, if missing, creates) the dedicated WordPress Page that
 * carries the [avina_crm_admin] shortcode — the fullscreen, theme-free
 * app shell rendered by TemplateController. This is the page every
 * wp-admin "open the CRM" button should link to, since wp-admin itself
 * loads a large amount of core CSS/JS that is not compatible with the
 * Tailwind runtime the app shell depends on.
 *
 * The resolved page ID is cached in the 'avina_crm_admin_page_id' option
 * so repeated calls (e.g. rendering the wp-admin menu on every request)
 * do not each run a database query.
 */
final class AdminPageLocator
{
    public const OPTION_PAGE_ID = 'avina_crm_admin_page_id';
    public const SHORTCODE = '[avina_crm_admin]';
    private const DEFAULT_TITLE = 'پنل مدیریت آوینا CRM';

    /**
     * Returns the public URL of the admin app-shell page, creating the
     * page first if none exists yet. Safe to call on every admin-page
     * render (cheap after the first call, thanks to the cached option).
     */
    public static function url(): ?string
    {
        $pageId = self::ensureAdminPageExists();

        if ($pageId === null) {
            return null;
        }

        $permalink = get_permalink($pageId);

        return $permalink !== false ? $permalink : null;
    }

    /**
     * Idempotent: returns the existing page's ID if one is already
     * known/found, otherwise creates it once. Never creates a duplicate.
     */
    public static function ensureAdminPageExists(): ?int
    {
        $cachedId = (int) get_option(self::OPTION_PAGE_ID, 0);

        if ($cachedId > 0 && get_post_status($cachedId) === 'publish') {
            return $cachedId;
        }

        global $wpdb;

        $foundId = $wpdb->get_var($wpdb->prepare(
            "SELECT ID FROM {$wpdb->posts} WHERE post_content LIKE %s AND post_status = 'publish' AND post_type = 'page' LIMIT 1",
            '%' . $wpdb->esc_like(self::SHORTCODE) . '%'
        ));

        if ($foundId) {
            update_option(self::OPTION_PAGE_ID, (int) $foundId);

            return (int) $foundId;
        }

        $newId = wp_insert_post([
            'post_title' => self::DEFAULT_TITLE,
            'post_content' => self::SHORTCODE,
            'post_status' => 'publish',
            'post_type' => 'page',
            'post_author' => 1,
        ], true);

        if (is_wp_error($newId) || !$newId) {
            return null;
        }

        update_option(self::OPTION_PAGE_ID, (int) $newId);

        return (int) $newId;
    }
}
