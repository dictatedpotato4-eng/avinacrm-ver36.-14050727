<?php

declare(strict_types=1);

namespace AvinaCRM\Support;

/**
 * Shared object-level scoping logic. Every Stage 3 module's Service class
 * calls into this instead of re-implementing "can this user see this
 * record" from scratch, so the authorization rule lives in one place and
 * cannot silently drift between modules.
 *
 * Rule (Stage 1 §6 / Stage 2 decision #5): a user with the module's
 * "manage all" capability (administrators, by default, since they hold
 * every capability) sees everything; anyone else sees only records they
 * own (owner_user_id / assignee_user_id / created_by_user_id, depending
 * on the table) or that belong to a team they are a member of. This is
 * always enforced as a SQL WHERE clause built from server-side session
 * state (get_current_user_id()), never as a client-supplied filter —
 * the frontend may also hide UI it knows the user cannot use, but that
 * is a convenience, not the authorization boundary.
 */
final class Scope
{
    public static function isAdmin(?int $userId = null): bool
    {
        $user = $userId ? get_userdata($userId) : wp_get_current_user();
        if (!$user || !$user->exists()) {
            return false;
        }
        if (in_array('administrator', (array) $user->roles, true) || is_super_admin($user->ID)) {
            return true;
        }
        return user_can($user, 'manage_options') || user_can($user, 'platform.admin_dashboard.view');
    }

    public static function hasModulePermission(string $module, ?int $userId = null): bool
    {
        if (self::isAdmin($userId)) {
            return true;
        }

        $userId = $userId ?: get_current_user_id();
        if ($userId <= 0) {
            return false;
        }

        $permissions = get_user_meta($userId, 'avina_crm_operator_permissions', true);
        if (!is_array($permissions)) {
            $permissions = ['dashboard', 'leads'];
        }

        return in_array($module, $permissions, true);
    }

    /**
     * @return array<int, int> team IDs the given user belongs to
     */
    public static function teamIdsForUser(int $userId): array
    {
        global $wpdb;

        $table = $wpdb->prefix . 'avina_team_members';

        $ids = $wpdb->get_col(
            $wpdb->prepare("SELECT team_id FROM {$table} WHERE user_id = %d", $userId)
        );

        return array_map('intval', $ids);
    }

    public static function isTeamMember(int $userId, int $teamId): bool
    {
        global $wpdb;

        $table = $wpdb->prefix . 'avina_team_members';

        $count = $wpdb->get_var(
            $wpdb->prepare(
                "SELECT COUNT(*) FROM {$table} WHERE user_id = %d AND team_id = %d",
                $userId,
                $teamId
            )
        );

        return (int) $count > 0;
    }

    /**
     * Builds a `WHERE (...)` fragment (without the leading WHERE keyword)
     * that restricts a query to records the current user may see, unless
     * they hold $manageAllCapability — in which case no restriction is
     * applied (empty string, meaning "no additional WHERE needed").
     *
     * @param array<int, string> $ownerColumns column names that count as
     *   "this user owns the record" (checked with OR between them)
     */
    public static function visibilityClause(
        string $manageAllCapability,
        array $ownerColumns,
        ?string $teamColumn = null
    ): string {
        if (current_user_can($manageAllCapability)) {
            return '';
        }

        $userId = get_current_user_id();
        $parts = [];

        foreach ($ownerColumns as $column) {
            $parts[] = self::prepareEquals($column, $userId);
        }

        if ($teamColumn !== null) {
            $teamIds = self::teamIdsForUser($userId);
            if (!empty($teamIds)) {
                $inList = implode(',', array_map('intval', $teamIds));
                $parts[] = "{$teamColumn} IN ({$inList})";
            }
        }

        if (empty($parts)) {
            // No ownership path at all and no team match: deny everything.
            return '1 = 0';
        }

        return '(' . implode(' OR ', $parts) . ')';
    }

    private static function prepareEquals(string $column, int $userId): string
    {
        global $wpdb;

        return $wpdb->prepare("{$column} = %d", $userId);
    }
}
