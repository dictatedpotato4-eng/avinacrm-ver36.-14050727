<?php

declare(strict_types=1);

namespace AvinaCRM\Contacts;

use AvinaCRM\Audit\AuditLogger;
use AvinaCRM\Support\Scope;
use WP_Error;

final class ContactService
{
    public const LIFECYCLE_STAGES = ['lead', 'in_progress', 'customer', 'cancelled'];

    private AuditLogger $audit;

    public function __construct(?AuditLogger $audit = null)
    {
        $this->audit = $audit ?? new AuditLogger();
    }

    /**
     * @param array{search?: string, lifecycle_stage?: string, team_id?: int, page?: int, per_page?: int, followup_range?: string} $filters
     * @return array{items: array<int, array<string, mixed>>, total: int}
     */
    public function list(array $filters): array
    {
        global $wpdb;
        $table = $wpdb->prefix . 'avina_contacts';

        $where = ['is_archived = 0'];

        $visibility = Scope::visibilityClause('contacts.contact.view', ['owner_user_id', 'created_by_user_id'], 'team_id');
        if ($visibility !== '') {
            $where[] = $visibility;
        }

        if (!empty($filters['search'])) {
            $search = '%' . $wpdb->esc_like(sanitize_text_field($filters['search'])) . '%';
            $where[] = $wpdb->prepare('(full_name LIKE %s OR phone LIKE %s OR email LIKE %s)', $search, $search, $search);
        }

        if (!empty($filters['lifecycle_stage']) && in_array($filters['lifecycle_stage'], self::LIFECYCLE_STAGES, true)) {
            $where[] = $wpdb->prepare('lifecycle_stage = %s', $filters['lifecycle_stage']);
        }

        if (!empty($filters['team_id'])) {
            $where[] = $wpdb->prepare('team_id = %d', (int) $filters['team_id']);
        }

        if (!empty($filters['followup_range'])) {
            $today = current_time('Y-m-d');
            if ($filters['followup_range'] === 'today') {
                $where[] = $wpdb->prepare('followup_date = %s', $today);
            } elseif ($filters['followup_range'] === 'tomorrow') {
                $tomorrow = date('Y-m-d', strtotime('+1 day', strtotime($today)));
                $where[] = $wpdb->prepare('followup_date = %s', $tomorrow);
            } elseif ($filters['followup_range'] === 'week') {
                $nextWeek = date('Y-m-d', strtotime('+7 days', strtotime($today)));
                $where[] = $wpdb->prepare('followup_date >= %s AND followup_date <= %s', $today, $nextWeek);
            } elseif ($filters['followup_range'] === 'month') {
                $nextMonth = date('Y-m-d', strtotime('+30 days', strtotime($today)));
                $where[] = $wpdb->prepare('followup_date >= %s AND followup_date <= %s', $today, $nextMonth);
            }
        }

        $whereSql = implode(' AND ', $where);

        $perPage = min(10000, max(1, (int) ($filters['per_page'] ?? 20)));
        $page = max(1, (int) ($filters['page'] ?? 1));
        $offset = ($page - 1) * $perPage;

        $total = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$table} WHERE {$whereSql}");

        $rows = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT * FROM {$table} WHERE {$whereSql} ORDER BY created_at DESC LIMIT %d OFFSET %d",
                $perPage,
                $offset
            ),
            ARRAY_A
        );

        return ['items' => array_map([$this, 'decorate'], $rows ?: []), 'total' => $total];
    }

    public function find(int $id): ?array
    {
        global $wpdb;
        $table = $wpdb->prefix . 'avina_contacts';

        $row = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table} WHERE id = %d AND is_archived = 0", $id), ARRAY_A);

        if ($row === null) {
            return null;
        }

        if (!$this->canView($row)) {
            return null;
        }

        return $this->decorate($row);
    }

    private function canView(array $row): bool
    {
        if (current_user_can('contacts.contact.view') && $this->isManager()) {
            return true;
        }

        $userId = get_current_user_id();

        if ((int) ($row['owner_user_id'] ?? 0) === $userId || (int) ($row['created_by_user_id'] ?? 0) === $userId) {
            return true;
        }

        if (!empty($row['team_id']) && Scope::isTeamMember($userId, (int) $row['team_id'])) {
            return true;
        }

        return false;
    }

    private function isManager(): bool
    {
        return Scope::isAdmin() || current_user_can('manage_options') || current_user_can('users-roles.user.view');
    }

    public function create(array $data, int $actorUserId)
    {
        $fullName = sanitize_text_field($data['full_name'] ?? '');

        if ($fullName === '') {
            return new WP_Error('avina_crm_invalid_contact', __('نام مخاطب الزامی است.', 'avina-crm'), ['status' => 400]);
        }

        $phone = sanitize_text_field($data['phone'] ?? '');
        if ($phone === '') {
            return new WP_Error('avina_crm_invalid_contact', __('موبایل مخاطب الزامی است.', 'avina-crm'), ['status' => 400]);
        }

        $lifecycleStage = $data['lifecycle_stage'] ?? 'lead';
        if (!in_array($lifecycleStage, self::LIFECYCLE_STAGES, true)) {
            $lifecycleStage = 'lead';
        }

        $teamId = !empty($data['team_id']) ? (int) $data['team_id'] : null;
        $ownerUserId = !empty($data['owner_user_id']) ? (int) $data['owner_user_id'] : $actorUserId;

        $coreKeys = [
            'full_name', 'phone', 'email', 'tags', 'lifecycle_stage', 'owner_user_id', 'team_id',
            'job', 'requirement_type', 'product_or_service', 'buying_probability', 'followup_date', 'call_count', 'last_call_result'
        ];
        $customFields = [];
        $configured = get_option('avina_crm_custom_fields', []);
        $contactConfig = $configured['contact'] ?? [];
        $allowedCustomKeys = array_column($contactConfig, 'id');

        foreach ($data as $key => $val) {
            if (!in_array($key, $coreKeys, true) && in_array($key, $allowedCustomKeys, true)) {
                $customFields[$key] = sanitize_text_field((string)$val);
            }
        }
        $customFieldsJson = !empty($customFields) ? wp_json_encode($customFields, JSON_UNESCAPED_UNICODE) : null;

        global $wpdb;
        $table = $wpdb->prefix . 'avina_contacts';

        $followupDate = !empty($data['followup_date']) ? sanitize_text_field($data['followup_date']) : null;
        $notes = sanitize_textarea_field($data['last_call_result'] ?? '');

        $wpdb->insert(
            $table,
            [
                'full_name' => $fullName,
                'phone' => $phone,
                'email' => sanitize_email($data['email'] ?? ''),
                'tags' => $this->normalizeTags($data['tags'] ?? ''),
                'lifecycle_stage' => $lifecycleStage,
                'owner_user_id' => $ownerUserId,
                'team_id' => $teamId,
                'is_archived' => 0,
                'created_by_user_id' => $actorUserId,
                'custom_fields' => $customFieldsJson,
                'job' => sanitize_text_field($data['job'] ?? ''),
                'requirement_type' => sanitize_key($data['requirement_type'] ?? 'purchase'),
                'product_or_service' => sanitize_text_field($data['product_or_service'] ?? ''),
                'buying_probability' => (int) ($data['buying_probability'] ?? 3),
                'followup_date' => $followupDate,
                'call_count' => $notes !== '' ? 1 : 0,
                'last_call_result' => $notes,
                'created_at' => current_time('mysql'),
                'updated_at' => current_time('mysql'),
            ],
            ['%s', '%s', '%s', '%s', '%s', '%d', '%d', '%d', '%d', '%s', '%s', '%s', '%s', '%d', '%s', '%d', '%s', '%s', '%s']
        );

        $id = (int) $wpdb->insert_id;

        // If initial followup note is present, add it to avina_contact_followups
        if ($notes !== '' && $id > 0) {
            $wpdb->insert(
                $wpdb->prefix . 'avina_contact_followups',
                [
                    'contact_id' => $id,
                    'followup_date' => $followupDate ?: current_time('Y-m-d'),
                    'notes' => $notes,
                    'result' => 'ثبت اولیه مخاطب',
                    'created_by_user_id' => $actorUserId,
                    'created_at' => current_time('mysql')
                ],
                ['%d', '%s', '%s', '%s', '%d', '%s']
            );
        }

        $this->audit->record($actorUserId, 'contacts.contact.create', 'contact', (string) $id, null, ['full_name' => $fullName]);

        // --- Automatic Operator Pattern Dispatches ---
        if ($id > 0 && !empty($phone)) {
            try {
                $creatorId = $ownerUserId ?: $actorUserId;
                $welcomePattern = (string) get_user_meta($creatorId, 'avina_crm_welcome_pattern_code', true);
                $followupPattern = (string) get_user_meta($creatorId, 'avina_crm_followup_pattern_code', true);

                $appData = get_option('avina_crm_app_data', []);
                $smsSettings = $appData['settings']['sms'] ?? [];
                $leadSettings = $appData['settings']['leadSettings'] ?? ($appData['leadSettings'] ?? []);

                // 1. Resolve Welcome Pattern Code (Meta -> Lead Settings -> Default)
                if (empty($welcomePattern)) {
                    $welcomePatternId = (string)($leadSettings['welcomeSms']['patternId'] ?? '');
                    if (!empty($welcomePatternId) && !empty($smsSettings['patterns']) && is_array($smsSettings['patterns'])) {
                        foreach ($smsSettings['patterns'] as $p) {
                            if (($p['id'] ?? '') === $welcomePatternId || ($p['code'] ?? '') === $welcomePatternId) {
                                $welcomePattern = (string)($p['code'] ?? '');
                                break;
                            }
                        }
                    }
                }
                if (empty($welcomePattern)) {
                    $welcomePattern = (string) ($smsSettings['defaultWelcomePattern'] ?? '');
                }

                // 2. Resolve Followup Pattern Code (Meta -> Lead Settings -> Default)
                if (empty($followupPattern)) {
                    $followupPatternId = (string)($leadSettings['followupSms']['patternId'] ?? '');
                    if (!empty($followupPatternId) && !empty($smsSettings['patterns']) && is_array($smsSettings['patterns'])) {
                        foreach ($smsSettings['patterns'] as $p) {
                            if (($p['id'] ?? '') === $followupPatternId || ($p['code'] ?? '') === $followupPatternId) {
                                $followupPattern = (string)($p['code'] ?? '');
                                break;
                            }
                        }
                    }
                }
                if (empty($followupPattern)) {
                    $followupPattern = (string) ($smsSettings['defaultFollowupPattern'] ?? '');
                }

                $apiKey = sanitize_text_field((string)($smsSettings['apiKey'] ?? ''));
                $sender = sanitize_text_field((string)($smsSettings['senderNumber'] ?? ''));
                $authMode = sanitize_text_field((string)($smsSettings['authMode'] ?? 'apikey'));
                $username = sanitize_text_field((string)($smsSettings['username'] ?? ''));
                $password = sanitize_text_field((string)($smsSettings['password'] ?? ''));

                $smsService = new \AvinaCRM\SMS\SmsService();

                $patternVars = [
                    'name'     => $fullName,
                    'customer' => $fullName,
                    'user'     => $fullName,
                    'code'     => (string)$id,
                    'id'       => (string)$id,
                    'phone'    => $phone,
                    'mobile'   => $phone,
                ];

                // Strict Destination: Only send to the contact's phone ($phone).
                // Never broadcast to admin (09138996197) or arbitrary recipients.
                // Pattern 1: Immediate Welcome SMS upon registration
                if (!empty($welcomePattern)) {
                    $smsService->sendIpPanelPatternSms(
                        $apiKey,
                        $sender,
                        $phone,
                        $welcomePattern,
                        $patternVars,
                        $creatorId,
                        $authMode,
                        $username,
                        $password
                    );
                }

                // Pattern 2: Scheduled 24h Followup SMS (strictly pattern-only to $phone)
                if (!empty($followupPattern)) {
                    $smsService->scheduleFollowupPatternSms(
                        $id,
                        $phone,
                        $followupPattern,
                        $patternVars,
                        $creatorId
                    );
                }
            } catch (\Throwable $e) {
                // Prevent SMS errors from failing contact creation
            }
        }

        return ['id' => $id];
    }

    public function delete(int $id, int $actorUserId)
    {
        $existing = $this->rawFind($id);

        if ($existing === null) {
            return new WP_Error('avina_crm_contact_not_found', __('مخاطب موردنظر یافت نشد.', 'avina-crm'), ['status' => 404]);
        }

        if (!$this->canView($existing) && !$this->isManager()) {
            return new WP_Error('avina_crm_forbidden', __('شما اجازه حذف این مخاطب را ندارید.', 'avina-crm'), ['status' => 403]);
        }

        global $wpdb;
        $table = $wpdb->prefix . 'avina_contacts';
        $deleted = $wpdb->delete($table, ['id' => $id], ['%d']);

        if (!$deleted) {
            return new WP_Error('avina_crm_delete_failed', __('حذف مخاطب با خطا مواجه شد.', 'avina-crm'), ['status' => 500]);
        }

        $wpdb->delete($wpdb->prefix . 'avina_contact_followups', ['contact_id' => $id], ['%d']);

        $this->audit->record($actorUserId, 'contacts.contact.delete', 'contact', (string) $id, null, ['full_name' => $existing['full_name'] ?? '']);

        return ['id' => $id, 'success' => true];
    }

    public function update(int $id, array $data, int $actorUserId)
    {
        $existing = $this->rawFind($id);

        if ($existing === null) {
            return new WP_Error('avina_crm_contact_not_found', __('مخاطب موردنظر یافت نشد.', 'avina-crm'), ['status' => 404]);
        }

        if (!$this->canView($existing)) {
            return new WP_Error('avina_crm_forbidden', __('شما اجازه ویرایش این مخاطب را ندارید.', 'avina-crm'), ['status' => 403]);
        }

        $fields = [];
        $formats = [];

        $updatableKeys = [
            'full_name' => '%s',
            'phone' => '%s',
            'email' => '%s',
            'tags' => '%s',
            'lifecycle_stage' => '%s',
            'owner_user_id' => '%d',
            'team_id' => '%d',
            'job' => '%s',
            'requirement_type' => '%s',
            'product_or_service' => '%s',
            'buying_probability' => '%d',
            'followup_date' => '%s',
            'call_count' => '%d',
            'last_call_result' => '%s'
        ];

        foreach ($updatableKeys as $key => $format) {
            if (isset($data[$key])) {
                if ($key === 'full_name') {
                    $name = sanitize_text_field($data['full_name']);
                    if ($name === '') {
                        return new WP_Error('avina_crm_invalid_contact', __('نام مخاطب نمی‌تواند خالی باشد.', 'avina-crm'), ['status' => 400]);
                    }
                    $fields['full_name'] = $name;
                } elseif ($key === 'phone') {
                    $fields['phone'] = sanitize_text_field($data['phone']);
                } elseif ($key === 'email') {
                    $fields['email'] = sanitize_email($data['email']);
                } elseif ($key === 'tags') {
                    $fields['tags'] = $this->normalizeTags($data['tags']);
                } elseif ($key === 'requirement_type') {
                    $fields['requirement_type'] = sanitize_key($data['requirement_type']);
                } elseif ($key === 'product_or_service') {
                    $fields['product_or_service'] = sanitize_text_field($data['product_or_service']);
                } elseif ($key === 'job') {
                    $fields['job'] = sanitize_text_field($data['job']);
                } elseif ($key === 'buying_probability') {
                    $fields['buying_probability'] = (int) $data['buying_probability'];
                } elseif ($key === 'followup_date') {
                    $fields['followup_date'] = !empty($data['followup_date']) ? sanitize_text_field($data['followup_date']) : null;
                } else {
                    $fields[$key] = $data[$key];
                }
                $formats[] = $format;
            }
        }

        // Custom fields updates
        $configured = get_option('avina_crm_custom_fields', []);
        $contactConfig = $configured['contact'] ?? [];
        $allowedCustomKeys = array_column($contactConfig, 'id');
        $customUpdates = [];
        foreach ($data as $key => $val) {
            if (in_array($key, $allowedCustomKeys, true)) {
                $customUpdates[$key] = sanitize_text_field((string)$val);
            }
        }

        if (!empty($customUpdates)) {
            $existingCustomJson = $existing['custom_fields'] ?? '';
            $existingCustom = [];
            if ($existingCustomJson !== '') {
                $existingCustom = json_decode($existingCustomJson, true);
                if (!is_array($existingCustom)) {
                    $existingCustom = [];
                }
            }
            $mergedCustom = array_merge($existingCustom, $customUpdates);
            $fields['custom_fields'] = wp_json_encode($mergedCustom, JSON_UNESCAPED_UNICODE);
            $formats[] = '%s';
        }

        if (empty($fields)) {
            return true;
        }

        $fields['updated_at'] = current_time('mysql');
        $formats[] = '%s';

        global $wpdb;
        $table = $wpdb->prefix . 'avina_contacts';

        $wpdb->update($table, $fields, ['id' => $id], $formats, ['%d']);

        $this->audit->record($actorUserId, 'contacts.contact.update', 'contact', (string) $id, $existing, $fields);

        return true;
    }

    public function archive(int $id, int $actorUserId)
    {
        $existing = $this->rawFind($id);

        if ($existing === null) {
            return new WP_Error('avina_crm_contact_not_found', __('مخاطب موردنظر یافت نشد.', 'avina-crm'), ['status' => 404]);
        }

        global $wpdb;
        $table = $wpdb->prefix . 'avina_contacts';

        $wpdb->update($table, ['is_archived' => 1, 'updated_at' => current_time('mysql')], ['id' => $id], ['%d', '%s'], ['%d']);

        $this->audit->record($actorUserId, 'contacts.contact.archive', 'contact', (string) $id, $existing, ['is_archived' => 1]);

        return true;
    }

    public function convertToCustomer(int $contactId, int $actorUserId, string $purchasedProducts = '', string $notes = '')
    {
        if (!current_user_can('customers.customer.convert')) {
            return new WP_Error('avina_crm_forbidden', __('شما اجازه تبدیل مخاطب به مشتری را ندارید.', 'avina-crm'), ['status' => 403]);
        }

        $contact = $this->rawFind($contactId);

        if ($contact === null) {
            return new WP_Error('avina_crm_contact_not_found', __('مخاطب موردنظر یافت نشد.', 'avina-crm'), ['status' => 404]);
        }

        global $wpdb;
        $customersTable = $wpdb->prefix . 'avina_customers';
        $eventsTable = $wpdb->prefix . 'avina_contact_conversion_events';

        $wpdb->insert(
            $customersTable,
            [
                'contact_id' => $contactId,
                'full_name' => $contact['full_name'],
                'phone' => $contact['phone'],
                'email' => $contact['email'],
                'status' => 'active',
                'owner_user_id' => $contact['owner_user_id'],
                'team_id' => $contact['team_id'],
                'is_archived' => 0,
                'created_by_user_id' => $actorUserId,
                'conversion_date' => current_time('Y-m-d'),
                'purchased_products' => sanitize_text_field($purchasedProducts),
                'notes' => sanitize_textarea_field($notes),
                'purchase_count' => 1,
                'created_at' => current_time('mysql'),
                'updated_at' => current_time('mysql'),
            ],
            ['%d', '%s', '%s', '%s', '%s', '%d', '%d', '%d', '%d', '%s', '%s', '%s', '%d', '%s', '%s']
        );

        $customerId = (int) $wpdb->insert_id;

        // Update contact lifecycle stage
        $wpdb->update(
            $wpdb->prefix . 'avina_contacts',
            ['lifecycle_stage' => 'customer', 'updated_at' => current_time('mysql')],
            ['id' => $contactId],
            ['%s', '%s'],
            ['%d']
        );

        $this->audit->record(
            $actorUserId,
            'contacts.contact.convert',
            'contact',
            (string) $contactId,
            null,
            ['customer_id' => $customerId, 'purchased_products' => $purchasedProducts]
        );

        return ['customer_id' => $customerId];
    }

    public function getFollowups(int $contactId): array
    {
        global $wpdb;
        $table = $wpdb->prefix . 'avina_contact_followups';
        
        $results = $wpdb->get_results(
            $wpdb->prepare("SELECT * FROM {$table} WHERE contact_id = %d ORDER BY created_at DESC", $contactId),
            ARRAY_A
        );
        
        return $results ?: [];
    }

    public function addFollowup(int $contactId, string $date, string $notes, string $result, int $actorUserId)
    {
        global $wpdb;
        $followupsTable = $wpdb->prefix . 'avina_contact_followups';
        $contactsTable = $wpdb->prefix . 'avina_contacts';

        $wpdb->insert(
            $followupsTable,
            [
                'contact_id' => $contactId,
                'followup_date' => sanitize_text_field($date),
                'notes' => sanitize_textarea_field($notes),
                'result' => sanitize_text_field($result),
                'created_by_user_id' => $actorUserId,
                'created_at' => current_time('mysql')
            ],
            ['%d', '%s', '%s', '%s', '%d', '%s']
        );

        $contact = $this->rawFind($contactId);
        $newCallCount = ((int) ($contact['call_count'] ?? 0)) + 1;

        $wpdb->update(
            $contactsTable,
            [
                'followup_date' => sanitize_text_field($date),
                'call_count' => $newCallCount,
                'last_call_result' => sanitize_text_field($notes),
                'updated_at' => current_time('mysql')
            ],
            ['id' => $contactId],
            ['%s', '%d', '%s', '%s'],
            ['%d']
        );

        $this->audit->record($actorUserId, 'contacts.contact.add_followup', 'contact', (string) $contactId, null, [
            'followup_date' => $date,
            'notes' => $notes
        ]);

        return true;
    }

    public function sendToKanban(int $contactId, int $operatorId, string $stageId, string $desc, int $actorUserId)
    {
        global $wpdb;
        $kanbanTable = $wpdb->prefix . 'avina_kanban_tasks';
        $logsTable = $wpdb->prefix . 'avina_kanban_task_logs';
        $contact = $this->rawFind($contactId);

        if (!$contact) {
            return new WP_Error('avina_crm_contact_not_found', __('مخاطب موردنظر یافت نشد.', 'avina-crm'), ['status' => 404]);
        }

        $stageColors = [
            'lead' => '#6366f1',
            'contacted' => '#eab308',
            'demo' => '#3b82f6',
            'won' => '#10b981',
            'lost' => '#ef4444'
        ];
        $stageGlows = [
            'lead' => 'rgba(99, 102, 241, 0.12)',
            'contacted' => 'rgba(234, 179, 8, 0.12)',
            'demo' => 'rgba(59, 130, 246, 0.12)',
            'won' => 'rgba(16, 185, 129, 0.12)',
            'lost' => 'rgba(239, 68, 68, 0.12)'
        ];
        $color = $stageColors[$stageId] ?? '#6366f1';
        $glow = $stageGlows[$stageId] ?? 'rgba(99, 102, 241, 0.12)';

        $wpdb->insert(
            $kanbanTable,
            [
                'title' => $contact['full_name'],
                'description' => sanitize_textarea_field($desc),
                'stage_id' => sanitize_key($stageId),
                'assignee_user_id' => $operatorId,
                'contact_id' => $contactId,
                'color_tag' => $color,
                'color_glow' => $glow,
                'created_by_user_id' => $actorUserId,
                'created_at' => current_time('mysql'),
                'updated_at' => current_time('mysql')
            ],
            ['%s', '%s', '%s', '%d', '%d', '%s', '%s', '%d', '%s', '%s']
        );

        $taskId = (int) $wpdb->insert_id;

        $wpdb->insert(
            $logsTable,
            [
                'task_id' => $taskId,
                'action' => 'created',
                'details' => sprintf('وظیفه از روی مخاطب %s ایجاد و به اپراتور واگذار شد.', $contact['full_name']),
                'created_by_user_id' => $actorUserId,
                'created_at' => current_time('mysql')
            ],
            ['%d', '%s', '%s', '%d', '%s']
        );

        $operator = get_user_by('id', $operatorId);
        $operatorName = $operator ? $operator->display_name : ('کاربر شناسه ' . $operatorId);
        $logText = sprintf('وظیفه برای کاربر %s ارسال شد در تاریخ %s و در انتظار انجام/برگشت هستم.', $operatorName, current_time('Y/m/d H:i'));
        $this->addFollowup($contactId, current_time('Y-m-d'), $logText, 'ارجاع به کانبان', $actorUserId);

        return ['task_id' => $taskId];
    }

    public function sendMessage(int $contactId, string $phone, string $messageText, string $channel, int $actorUserId)
    {
        global $wpdb;
        $table = $wpdb->prefix . 'avina_messages_log';

        $wpdb->insert(
            $table,
            [
                'recipient_phone' => sanitize_text_field($phone),
                'message_text' => sanitize_textarea_field($messageText),
                'channel' => sanitize_key($channel),
                'status' => 'sent',
                'created_by_user_id' => $actorUserId,
                'created_at' => current_time('mysql')
            ],
            ['%s', '%s', '%s', '%s', '%d', '%s']
        );

        $logText = sprintf('ارسال پیام پیش‌فرض از طریق %s: %s', strtoupper($channel), $messageText);
        $this->addFollowup($contactId, current_time('Y-m-d'), $logText, 'ارسال پیام', $actorUserId);

        return true;
    }

    public function exportRows(array $filters): array
    {
        $items = $this->list(array_merge($filters, ['per_page' => 10000, 'page' => 1]))['items'];

        $headers = [
            __('نام کامل', 'avina-crm'),
            __('تلفن', 'avina-crm'),
            __('ایمیل', 'avina-crm'),
            __('شغل', 'avina-crm'),
            __('مورد نیاز', 'avina-crm'),
            __('محصول/خدمت', 'avina-crm'),
            __('احتمال خرید', 'avina-crm'),
            __('تاریخ پیگیری', 'avina-crm'),
            __('تعداد تماس‌ها', 'avina-crm'),
            __('آخرین صحبت', 'avina-crm'),
            __('مرحله چرخه عمر', 'avina-crm'),
        ];

        $configured = get_option('avina_crm_custom_fields', []);
        $contactConfig = $configured['contact'] ?? [];
        usort($contactConfig, fn($a, $b) => ((int)($a['order'] ?? 0)) <=> ((int)($b['order'] ?? 0)));

        foreach ($contactConfig as $cf) {
            $headers[] = $cf['label'];
        }

        $rows = [];
        foreach ($items as $item) {
            $row = [
                $item['full_name'],
                $item['phone'],
                $item['email'],
                $item['job'],
                $item['requirement_type'] === 'purchase' ? 'خرید' : 'خدمات',
                $item['product_or_service'],
                $item['buying_probability'] . ' ستاره',
                $item['followup_date'] ?? '—',
                $item['call_count'],
                $item['last_call_result'],
                $item['lifecycle_stage']
            ];
            $cfValues = $item['custom_fields'] ?? [];
            if (is_object($cfValues)) {
                $cfValues = (array)$cfValues;
            }
            if (!is_array($cfValues)) {
                $cfValues = [];
            }
            foreach ($contactConfig as $cf) {
                $row[] = $cfValues[$cf['id']] ?? '';
            }
            $rows[] = $row;
        }

        return ['headers' => $headers, 'rows' => $rows];
    }

    private function rawFind(int $id): ?array
    {
        global $wpdb;
        $table = $wpdb->prefix . 'avina_contacts';

        $row = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table} WHERE id = %d", $id), ARRAY_A);

        return $row ?: null;
    }

    private function teamExists(int $teamId): bool
    {
        global $wpdb;
        $table = $wpdb->prefix . 'avina_teams';

        return (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$table} WHERE id = %d", $teamId)) > 0;
    }

    private function normalizeTags($tags): string
    {
        if (is_array($tags)) {
            $tags = implode(',', $tags);
        }

        $parts = array_filter(array_map('trim', explode(',', (string) $tags)));
        $parts = array_map('sanitize_text_field', $parts);

        return substr(implode(',', array_unique($parts)), 0, 500);
    }

    private function decorate(array $row): array
    {
        $row['id'] = (int) $row['id'];
        $row['owner_user_id'] = $row['owner_user_id'] !== null ? (int) $row['owner_user_id'] : null;
        $row['team_id'] = $row['team_id'] !== null ? (int) $row['team_id'] : null;
        $row['is_archived'] = (bool) $row['is_archived'];
        $row['tags_list'] = $row['tags'] !== '' ? explode(',', $row['tags']) : [];
        $row['custom_fields'] = !empty($row['custom_fields']) ? json_decode($row['custom_fields'], true) : new \stdClass();
        $row['buying_probability'] = (int) ($row['buying_probability'] ?? 3);
        $row['call_count'] = (int) ($row['call_count'] ?? 0);
        return $row;
    }
}
