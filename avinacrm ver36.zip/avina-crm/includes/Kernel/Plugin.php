<?php

declare(strict_types=1);

namespace AvinaCRM\Kernel;

use AvinaCRM\Admin\MenuRegistrar;
use AvinaCRM\Capabilities\CapabilityRegistrar;
use AvinaCRM\Capabilities\RoleProvisioner;
use AvinaCRM\Database\Migrator;
use AvinaCRM\Frontend\ShortcodeRegistrar;
use AvinaCRM\Frontend\TemplateController;

final class Plugin
{
    private static ?Plugin $instance = null;

    private function __construct()
    {
    }

    public static function instance(): self
    {
        if (self::$instance === null) {
            self::$instance = new self();
        }

        return self::$instance;
    }

    /**
     * Runs on register_activation_hook. Idempotent by construction: every
     * step it calls (dbDelta, add_cap, add_role-if-missing, INSERT ...
     * ON DUPLICATE KEY UPDATE) is itself safe to repeat. Never deletes or
     * overwrites existing CRM data, options a site administrator has
     * already changed, or unrelated WordPress roles.
     */
    public function activate(): void
    {
        (new Migrator())->run();
        (new CapabilityRegistrar())->grantToAdministrator();
        (new RoleProvisioner())->ensureOperatorRole();

        // Create Admin Page automatically if it doesn't exist. Idempotent:
        // re-running activation never creates a duplicate — it first
        // checks the cached option, then falls back to a LIKE query
        // against existing published pages before inserting anything.
        \AvinaCRM\Support\AdminPageLocator::ensureAdminPageExists();

        flush_rewrite_rules();
    }

    /**
     * Runs on register_deactivation_hook. Stage 2 instruction: deactivation
     * must not delete data. It also does not remove roles or capabilities
     * — those are configuration, not data, and removing them on a merely
     * temporary deactivation (e.g. troubleshooting a conflict) would be
     * needlessly disruptive; re-activating simply re-grants them via
     * activate(), which is itself idempotent.
     */
    public function deactivate(): void
    {
        flush_rewrite_rules();
    }

    /**
     * Runs on every plugins_loaded (once PHP version + text domain are
     * already confirmed OK by avina-crm.php). Wires up the runtime-only
     * hooks: admin menu, settings, REST routes, shortcodes, template
     * override. Nothing here writes to the database except the
     * versioned, idempotent maybeMigrate() check.
     */
    public function init(): void
    {
        $migrated = (new Migrator())->maybeMigrate();

        if ($migrated) {
            // A schema/version bump may have introduced new capabilities
            // (Stage 3 added ~30) — resync administrator's grants and the
            // operator role without requiring a manual deactivate/
            // reactivate. Both calls are idempotent (has_cap()-guarded /
            // get_role()-guarded), so this is safe even if it somehow
            // ran twice.
            (new CapabilityRegistrar())->grantToAdministrator();
            (new RoleProvisioner())->ensureOperatorRole();
        }

        (new MenuRegistrar())->bootstrap();
        (new \AvinaCRM\Rest\RestRegistrar())->bootstrap();
        (new ShortcodeRegistrar())->bootstrap();
        (new TemplateController())->bootstrap();
        (new \AvinaCRM\Webhooks\WebhookEventListener())->bootstrap();
    }
}
