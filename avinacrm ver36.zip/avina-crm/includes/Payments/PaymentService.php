<?php

declare(strict_types=1);

namespace AvinaCRM\Payments;

use AvinaCRM\Audit\AuditLogger;
use AvinaCRM\Invoices\InvoiceService;
use WP_Error;

final class PaymentService
{
    public const METHODS = ['manual', 'bank_transfer', 'cash', 'card', 'cheque', 'other'];

    private AuditLogger $audit;
    private InvoiceService $invoices;

    public function __construct(?AuditLogger $audit = null, ?InvoiceService $invoices = null)
    {
        $this->audit = $audit ?? new AuditLogger();
        $this->invoices = $invoices ?? new InvoiceService();
    }

    /**
     * Records a manual/offline payment against an invoice and immediately
     * re-syncs the invoice's paid_total + derived status. The amount is
     * validated against the invoice's remaining balance — overpayment
     * beyond the outstanding total is rejected rather than silently
     * accepted, so paid_total can never legitimately exceed total through
     * this path.
     *
     * @return array{id: int}|WP_Error
     */
    public function record(int $invoiceId, array $data, int $actorUserId)
    {
        $invoice = $this->invoices->rawFind($invoiceId);

        if ($invoice === null) {
            return new WP_Error('avina_crm_invoice_not_found', __('فاکتور موردنظر یافت نشد.', 'avina-crm'), ['status' => 404]);
        }

        if (!current_user_can('payments.payment.create')) {
            return new WP_Error('avina_crm_forbidden', __('شما اجازه ثبت پرداخت را ندارید.', 'avina-crm'), ['status' => 403]);
        }

        if ($invoice['status'] === 'void') {
            return new WP_Error('avina_crm_invalid_invoice_state', __('امکان ثبت پرداخت برای فاکتور باطل‌شده وجود ندارد.', 'avina-crm'), ['status' => 400]);
        }

        $amount = round((float) ($data['amount'] ?? 0), 2);

        if ($amount <= 0) {
            return new WP_Error('avina_crm_invalid_amount', __('مبلغ پرداخت باید بزرگ‌تر از صفر باشد.', 'avina-crm'), ['status' => 400]);
        }

        $remainingBalance = round((float) $invoice['total'] - (float) $invoice['paid_total'], 2);

        if ($amount > $remainingBalance + 0.01) {
            return new WP_Error(
                'avina_crm_overpayment',
                sprintf(
                    /* translators: %s: remaining balance */
                    __('مبلغ پرداخت از باقیمانده فاکتور (%s) بیشتر است.', 'avina-crm'),
                    number_format($remainingBalance, 2)
                ),
                ['status' => 400]
            );
        }

        $method = in_array($data['method'] ?? '', self::METHODS, true) ? $data['method'] : 'manual';

        global $wpdb;
        $table = $wpdb->prefix . 'avina_payments';

        $wpdb->insert(
            $table,
            [
                'invoice_id' => $invoiceId,
                'amount' => $amount,
                'method' => $method,
                'reference' => sanitize_text_field($data['reference'] ?? ''),
                'paid_at' => !empty($data['paid_at']) ? $this->normalizeDatetime($data['paid_at']) : current_time('mysql'),
                'recorded_by_user_id' => $actorUserId,
                'created_at' => current_time('mysql'),
            ],
            ['%d', '%f', '%s', '%s', '%s', '%d', '%s']
        );

        $id = (int) $wpdb->insert_id;

        $this->invoices->syncPaymentState($invoiceId, $actorUserId);

        $this->audit->record($actorUserId, 'payments.payment.create', 'invoice', (string) $invoiceId, null, ['payment_id' => $id, 'amount' => $amount]);

        return ['id' => $id];
    }

    public function listForInvoice(int $invoiceId): array
    {
        global $wpdb;
        $table = $wpdb->prefix . 'avina_payments';

        $rows = $wpdb->get_results(
            $wpdb->prepare("SELECT * FROM {$table} WHERE invoice_id = %d ORDER BY paid_at DESC", $invoiceId),
            ARRAY_A
        );

        return array_map(static function (array $row): array {
            $row['id'] = (int) $row['id'];
            $row['invoice_id'] = (int) $row['invoice_id'];
            $row['amount'] = (float) $row['amount'];

            return $row;
        }, $rows ?: []);
    }

    private function normalizeDatetime(string $value): string
    {
        $timestamp = strtotime($value);

        return $timestamp !== false ? gmdate('Y-m-d H:i:s', $timestamp) : current_time('mysql');
    }
}
