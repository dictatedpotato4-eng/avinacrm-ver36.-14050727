<?php

declare(strict_types=1);

namespace AvinaCRM\Deals;

use AvinaCRM\Audit\AuditLogger;
use AvinaCRM\Pipelines\PipelineService;
use AvinaCRM\Support\Scope;
use WP_Error;

final class DealService
{
    private AuditLogger $audit;
    private PipelineService $pipelines;

    public function __construct(?AuditLogger $audit = null, ?PipelineService $pipelines = null)
    {
        $this->audit = $audit ?? new AuditLogger();
        $this->pipelines = $pipelines ?? new PipelineService();
    }

    public function list(array $filters): array
    {
        global $wpdb;
        $table = $wpdb->prefix . 'avina_deals';

        $where = ['is_archived = 0'];

        $visibility = Scope::visibilityClause('deals.deal.view', ['owner_user_id', 'created_by_user_id'], 'team_id');
        if ($visibility !== '') {
            $where[] = $visibility;
        }

        if (!empty($filters['pipeline_id'])) {
            $where[] = $wpdb->prepare('pipeline_id = %d', (int) $filters['pipeline_id']);
        }

        if (!empty($filters['status']) && in_array($filters['status'], ['open', 'won', 'lost'], true)) {
            $where[] = $wpdb->prepare('status = %s', $filters['status']);
        }

        $whereSql = implode(' AND ', $where);

        $rows = $wpdb->get_results(
            "SELECT * FROM {$table} WHERE {$whereSql} ORDER BY created_at DESC LIMIT 500",
            ARRAY_A
        );

        return array_map([$this, 'decorate'], $rows ?: []);
    }

    /**
     * Kanban board data: every stage of a pipeline, each with its deals
     * and aggregated metrics (count + summed value) — computed here in
     * PHP against the already-scoped result set, not trusted from the
     * client.
     */
    public function board(int $pipelineId): array
    {
        $stages = $this->pipelines->stagesOf($pipelineId);
        $deals = $this->list(['pipeline_id' => $pipelineId, 'status' => 'open']);

        $columns = [];
        foreach ($stages as $stage) {
            $stageDeals = array_values(array_filter($deals, static fn ($d) => $d['stage_id'] === $stage['id']));
            $columns[] = [
                'stage' => $stage,
                'deals' => $stageDeals,
                'count' => count($stageDeals),
                'total_value' => array_sum(array_column($stageDeals, 'value')),
            ];
        }

        return $columns;
    }

    public function find(int $id): ?array
    {
        $row = $this->rawFind($id);

        if ($row === null || !$this->canView($row)) {
            return null;
        }

        return $this->decorate($row);
    }

    /**
     * @return array{id: int}|WP_Error
     */
    public function create(array $data, int $actorUserId)
    {
        $title = sanitize_text_field($data['title'] ?? '');

        if ($title === '') {
            return new WP_Error('avina_crm_invalid_deal', __('عنوان معامله الزامی است.', 'avina-crm'), ['status' => 400]);
        }

        $pipelineId = (int) ($data['pipeline_id'] ?? 0);
        if (!$this->pipelines->pipelineExists($pipelineId)) {
            return new WP_Error('avina_crm_invalid_pipeline', __('پایپ‌لاین معتبر نیست.', 'avina-crm'), ['status' => 400]);
        }

        $stageId = (int) ($data['stage_id'] ?? 0);
        if (!$this->pipelines->stageExists($stageId, $pipelineId)) {
            return new WP_Error('avina_crm_invalid_stage', __('مرحله معتبر نیست یا متعلق به این پایپ‌لاین نیست.', 'avina-crm'), ['status' => 400]);
        }

        $ownerUserId = !empty($data['owner_user_id']) ? (int) $data['owner_user_id'] : $actorUserId;
        if (get_user_by('id', $ownerUserId) === false) {
            return new WP_Error('avina_crm_invalid_owner', __('کاربر مسئول معتبر نیست.', 'avina-crm'), ['status' => 400]);
        }

        $value = $this->sanitizeMoney($data['value'] ?? 0);

        $coreKeys = ['title', 'pipeline_id', 'stage_id', 'contact_id', 'customer_id', 'value', 'currency', 'expected_close_date', 'status', 'owner_user_id', 'team_id'];
        $customFields = [];
        $configured = get_option('avina_crm_custom_fields', []);
        $dealConfig = $configured['deal'] ?? [];
        $allowedCustomKeys = array_column($dealConfig, 'id');

        foreach ($data as $key => $val) {
            if (!in_array($key, $coreKeys, true) && in_array($key, $allowedCustomKeys, true)) {
                $customFields[$key] = sanitize_text_field((string)$val);
            }
        }
        $customFieldsJson = !empty($customFields) ? wp_json_encode($customFields, JSON_UNESCAPED_UNICODE) : null;

        global $wpdb;
        $table = $wpdb->prefix . 'avina_deals';

        $wpdb->insert(
            $table,
            [
                'title' => $title,
                'pipeline_id' => $pipelineId,
                'stage_id' => $stageId,
                'contact_id' => !empty($data['contact_id']) ? (int) $data['contact_id'] : null,
                'customer_id' => !empty($data['customer_id']) ? (int) $data['customer_id'] : null,
                'value' => $value,
                'currency' => $this->sanitizeCurrency($data['currency'] ?? 'IRR'),
                'expected_close_date' => !empty($data['expected_close_date']) ? $this->normalizeDate($data['expected_close_date']) : null,
                'status' => 'open',
                'owner_user_id' => $ownerUserId,
                'team_id' => !empty($data['team_id']) ? (int) $data['team_id'] : null,
                'is_archived' => 0,
                'created_by_user_id' => $actorUserId,
                'created_at' => current_time('mysql'),
                'updated_at' => current_time('mysql'),
                'custom_fields' => $customFieldsJson,
            ],
            ['%s', '%d', '%d', '%d', '%d', '%f', '%s', '%s', '%s', '%d', '%d', '%d', '%d', '%s', '%s', '%s']
        );

        $id = (int) $wpdb->insert_id;

        $this->recordStageHistory($id, null, $stageId, $actorUserId);
        $this->audit->record($actorUserId, 'deals.deal.create', 'deal', (string) $id, null, ['title' => $title, 'value' => $value]);

        $smsData = array_merge($data, ['custom_fields' => $customFields]);
        $smsService = new \AvinaCRM\SMS\SmsService($this->audit);
        $smsService->triggerSms('deal', $smsData, $actorUserId);

        return ['id' => $id];
    }

    /**
     * Server-side authorized stage transition — the only path a deal's
     * stage_id may change. If the target stage is flagged is_won/is_lost,
     * the deal's status is updated to match automatically (a deal cannot
     * sit in a "won" column while status stays "open").
     *
     * @return true|WP_Error
     */
    public function changeStage(int $dealId, int $newStageId, int $actorUserId, string $lostReason = '')
    {
        $deal = $this->rawFind($dealId);

        if ($deal === null) {
            return new WP_Error('avina_crm_deal_not_found', __('معامله موردنظر یافت نشد.', 'avina-crm'), ['status' => 404]);
        }

        if (!$this->canModify($deal)) {
            return new WP_Error('avina_crm_forbidden', __('شما اجازه تغییر مرحله این معامله را ندارید.', 'avina-crm'), ['status' => 403]);
        }

        if (!current_user_can('deals.deal.change_stage')) {
            return new WP_Error('avina_crm_forbidden', __('شما اجازه تغییر مرحله معاملات را ندارید.', 'avina-crm'), ['status' => 403]);
        }

        $stage = $this->pipelines->findStage($newStageId);

        if ($stage === null || (int) $stage['pipeline_id'] !== (int) $deal['pipeline_id']) {
            return new WP_Error('avina_crm_invalid_stage', __('مرحله معتبر نیست یا متعلق به این پایپ‌لاین نیست.', 'avina-crm'), ['status' => 400]);
        }

        $newStatus = 'open';
        if ((int) $stage['is_won'] === 1) {
            $newStatus = 'won';
        } elseif ((int) $stage['is_lost'] === 1) {
            $newStatus = 'lost';
        }

        global $wpdb;
        $table = $wpdb->prefix . 'avina_deals';

        $wpdb->update(
            $table,
            [
                'stage_id' => $newStageId,
                'status' => $newStatus,
                'lost_reason' => $newStatus === 'lost' ? sanitize_text_field($lostReason) : '',
                'updated_at' => current_time('mysql'),
            ],
            ['id' => $dealId],
            ['%d', '%s', '%s', '%s'],
            ['%d']
        );

        $this->recordStageHistory($dealId, (int) $deal['stage_id'], $newStageId, $actorUserId);
        $this->audit->record(
            $actorUserId,
            'deals.deal.change_stage',
            'deal',
            (string) $dealId,
            ['stage_id' => $deal['stage_id'], 'status' => $deal['status']],
            ['stage_id' => $newStageId, 'status' => $newStatus]
        );

        do_action('avina_crm/deal_stage_changed', $dealId, $newStageId, $newStatus);
        if ($newStatus === 'won') {
            do_action('avina_crm/deal_won', $dealId);
        } elseif ($newStatus === 'lost') {
            do_action('avina_crm/deal_lost', $dealId);
        }

        return true;
    }

    /**
     * @return true|WP_Error
     */
    public function update(int $id, array $data, int $actorUserId)
    {
        $existing = $this->rawFind($id);

        if ($existing === null) {
            return new WP_Error('avina_crm_deal_not_found', __('معامله موردنظر یافت نشد.', 'avina-crm'), ['status' => 404]);
        }

        if (!$this->canModify($existing)) {
            return new WP_Error('avina_crm_forbidden', __('شما اجازه ویرایش این معامله را ندارید.', 'avina-crm'), ['status' => 403]);
        }

        $fields = [];
        $formats = [];

        if (isset($data['title'])) {
            $title = sanitize_text_field($data['title']);
            if ($title === '') {
                return new WP_Error('avina_crm_invalid_deal', __('عنوان معامله نمی‌تواند خالی باشد.', 'avina-crm'), ['status' => 400]);
            }
            $fields['title'] = $title;
            $formats[] = '%s';
        }

        if (isset($data['value'])) {
            $fields['value'] = $this->sanitizeMoney($data['value']);
            $formats[] = '%f';
        }

        if (isset($data['expected_close_date'])) {
            $fields['expected_close_date'] = $data['expected_close_date'] ? $this->normalizeDate($data['expected_close_date']) : null;
            $formats[] = '%s';
        }

        if (isset($data['contact_id'])) {
            $fields['contact_id'] = !empty($data['contact_id']) ? (int) $data['contact_id'] : null;
            $formats[] = '%d';
        }

        if (isset($data['customer_id'])) {
            $fields['customer_id'] = !empty($data['customer_id']) ? (int) $data['customer_id'] : null;
            $formats[] = '%d';
        }

        $configured = get_option('avina_crm_custom_fields', []);
        $dealConfig = $configured['deal'] ?? [];
        $allowedCustomKeys = array_column($dealConfig, 'id');
        $customUpdates = [];
        foreach ($data as $key => $val) {
            if (in_array($key, $allowedCustomKeys, true)) {
                $customUpdates[$key] = sanitize_text_field((string)$val);
            }
        }

        if (!empty($customUpdates)) {
            $existingCustomJson = $existing['custom_fields'] ?? '';
            $existingCustom = [];
            if ($existingCustomJson !== '') {
                $existingCustom = json_decode($existingCustomJson, true);
                if (!is_array($existingCustom)) {
                    $existingCustom = [];
                }
            }
            $mergedCustom = array_merge($existingCustom, $customUpdates);
            $fields['custom_fields'] = wp_json_encode($mergedCustom, JSON_UNESCAPED_UNICODE);
            $formats[] = '%s';
        }

        if (empty($fields)) {
            return true;
        }

        $fields['updated_at'] = current_time('mysql');
        $formats[] = '%s';

        global $wpdb;
        $wpdb->update($wpdb->prefix . 'avina_deals', $fields, ['id' => $id], $formats, ['%d']);

        $this->audit->record($actorUserId, 'deals.deal.update', 'deal', (string) $id, $existing, $fields);

        return true;
    }

    /**
     * @return true|WP_Error
     */
    public function archive(int $id, int $actorUserId)
    {
        $existing = $this->rawFind($id);

        if ($existing === null) {
            return new WP_Error('avina_crm_deal_not_found', __('معامله موردنظر یافت نشد.', 'avina-crm'), ['status' => 404]);
        }

        global $wpdb;
        $wpdb->update(
            $wpdb->prefix . 'avina_deals',
            ['is_archived' => 1, 'updated_at' => current_time('mysql')],
            ['id' => $id],
            ['%d', '%s'],
            ['%d']
        );

        $this->audit->record($actorUserId, 'deals.deal.archive', 'deal', (string) $id, $existing, ['is_archived' => 1]);

        return true;
    }

    private function recordStageHistory(int $dealId, ?int $fromStageId, int $toStageId, int $actorUserId): void
    {
        global $wpdb;
        $table = $wpdb->prefix . 'avina_deal_stage_history';

        $wpdb->insert(
            $table,
            [
                'deal_id' => $dealId,
                'from_stage_id' => $fromStageId,
                'to_stage_id' => $toStageId,
                'changed_by_user_id' => $actorUserId,
                'created_at' => current_time('mysql'),
            ],
            ['%d', '%d', '%d', '%d', '%s']
        );
    }

    private function canView(array $row): bool
    {
        if ($this->isManager()) {
            return true;
        }

        $userId = get_current_user_id();

        if ((int) ($row['owner_user_id'] ?? 0) === $userId || (int) ($row['created_by_user_id'] ?? 0) === $userId) {
            return true;
        }

        if (!empty($row['team_id']) && Scope::isTeamMember($userId, (int) $row['team_id'])) {
            return true;
        }

        return false;
    }

    private function canModify(array $row): bool
    {
        return $this->canView($row);
    }

    private function isManager(): bool
    {
        return current_user_can('manage_options') || current_user_can('users-roles.user.view');
    }

    private function rawFind(int $id): ?array
    {
        global $wpdb;
        $table = $wpdb->prefix . 'avina_deals';

        $row = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table} WHERE id = %d AND is_archived = 0", $id), ARRAY_A);

        return $row ?: null;
    }

    private function sanitizeMoney($value): float
    {
        return round((float) $value, 2);
    }

    private function sanitizeCurrency(string $currency): string
    {
        $currency = strtoupper(sanitize_text_field($currency));

        return preg_match('/^[A-Z]{3}$/', $currency) ? $currency : 'IRR';
    }

    private function normalizeDate(string $value): string
    {
        $timestamp = strtotime($value);

        return $timestamp !== false ? gmdate('Y-m-d', $timestamp) : gmdate('Y-m-d');
    }

    private function decorate(array $row): array
    {
        $row['id'] = (int) $row['id'];
        $row['pipeline_id'] = (int) $row['pipeline_id'];
        $row['stage_id'] = (int) $row['stage_id'];
        $row['contact_id'] = $row['contact_id'] !== null ? (int) $row['contact_id'] : null;
        $row['customer_id'] = $row['customer_id'] !== null ? (int) $row['customer_id'] : null;
        $row['owner_user_id'] = $row['owner_user_id'] !== null ? (int) $row['owner_user_id'] : null;
        $row['team_id'] = $row['team_id'] !== null ? (int) $row['team_id'] : null;
        $row['value'] = (float) $row['value'];
        $row['is_archived'] = (bool) $row['is_archived'];
        $row['custom_fields'] = !empty($row['custom_fields']) ? json_decode($row['custom_fields'], true) : new \stdClass();

        return $row;
    }
}
