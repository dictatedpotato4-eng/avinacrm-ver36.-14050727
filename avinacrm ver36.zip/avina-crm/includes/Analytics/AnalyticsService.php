<?php

declare(strict_types=1);

namespace AvinaCRM\Analytics;

use AvinaCRM\Support\Scope;

final class AnalyticsService
{
    private const RANGE_DAYS = ['7d' => 7, '30d' => 30, '90d' => 90];

    public function dashboard(string $range): array
    {
        global $wpdb;
        $days = self::RANGE_DAYS[$range] ?? 30;
        $since = gmdate('Y-m-d H:i:s', strtotime("-{$days} days"));

        // Widgets statistical queries
        $contactsToday = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}avina_contacts WHERE is_archived = 0 AND DATE(created_at) = CURDATE()");
        $buyingProbToday = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}avina_contacts WHERE is_archived = 0 AND buying_probability >= 4 AND DATE(created_at) = CURDATE()");
        $followupsToday = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}avina_contacts WHERE is_archived = 0 AND followup_date = CURDATE()");
        $interactionsToday = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}avina_messages_log WHERE DATE(created_at) = CURDATE()");

        // Chart 1: Lifecycle Stage distribution
        $lifecycleStats = $wpdb->get_results(
            "SELECT lifecycle_stage, COUNT(*) as cnt FROM {$wpdb->prefix}avina_contacts WHERE is_archived = 0 GROUP BY lifecycle_stage",
            ARRAY_A
        ) ?: [];

        // Chart 2: Card Reader Intake statuses distribution
        $intakeStats = $wpdb->get_results(
            "SELECT status, COUNT(*) as cnt FROM {$wpdb->prefix}avina_device_intakes GROUP BY status",
            ARRAY_A
        ) ?: [];

        // Kanban configuration to decide if Kanban is active
        $kanbanSettings = get_option('avina_crm_kanban_settings', ['enabled' => true]);

        return [
            'range' => in_array($range, array_keys(self::RANGE_DAYS), true) ? $range : '30d',
            'widgets_data' => [
                'contacts_today' => $contactsToday,
                'buying_prob_today' => $buyingProbToday,
                'followups_today' => $followupsToday,
                'interactions_today' => $interactionsToday,
            ],
            'charts_data' => [
                'lifecycle' => $lifecycleStats,
                'intakes' => $intakeStats,
            ],
            'kanban_enabled' => !empty($kanbanSettings['enabled']),
            'deals' => $this->dealsSummary($since),
            'tasks' => $this->taskBottlenecks(),
            'customers' => $this->customerGrowth($since),
            'recent_activities' => $this->recentActivities($since),
        ];
    }

    private function dealsSummary(string $since): array
    {
        global $wpdb;
        $table = $wpdb->prefix . 'avina_deals';

        $where = 'is_archived = 0 AND created_at >= %s';
        $params = [$since];

        $visibility = Scope::visibilityClause('deals.deal.view', ['owner_user_id', 'created_by_user_id'], 'team_id');
        $whereSql = $visibility !== '' ? "{$where} AND {$visibility}" : $where;

        $rows = $wpdb->get_results(
            $wpdb->prepare("SELECT status, COUNT(*) as cnt, COALESCE(SUM(value),0) as total_value FROM {$table} WHERE {$whereSql} GROUP BY status", ...$params),
            ARRAY_A
        );

        $summary = ['open' => ['count' => 0, 'value' => 0.0], 'won' => ['count' => 0, 'value' => 0.0], 'lost' => ['count' => 0, 'value' => 0.0]];

        foreach ((array) $rows as $row) {
            if (isset($summary[$row['status']])) {
                $summary[$row['status']] = ['count' => (int) $row['cnt'], 'value' => (float) $row['total_value']];
            }
        }

        return $summary;
    }

    private function taskBottlenecks(): array
    {
        global $wpdb;
        $table = $wpdb->prefix . 'avina_tasks';

        $where = 'is_archived = 0';
        $visibility = Scope::visibilityClause('tasks.task.view', ['assignee_user_id', 'created_by_user_id'], 'team_id');
        $whereSql = $visibility !== '' ? "{$where} AND {$visibility}" : $where;

        $openCount = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$table} WHERE {$whereSql} AND status IN ('open','in_progress')");
        $overdueCount = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$table} WHERE {$whereSql} AND status IN ('open','in_progress') AND due_at IS NOT NULL AND due_at < NOW()");

        return ['open' => $openCount, 'overdue' => $overdueCount];
    }

    private function customerGrowth(string $since): array
    {
        global $wpdb;
        $table = $wpdb->prefix . 'avina_customers';

        $where = 'is_archived = 0';
        $visibility = Scope::visibilityClause('customers.customer.view', ['owner_user_id', 'created_by_user_id'], 'team_id');
        $whereSql = $visibility !== '' ? "{$where} AND {$visibility}" : $where;

        $totalCount = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$table} WHERE {$whereSql}");
        $newCount = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$table} WHERE {$whereSql} AND created_at >= %s", $since));

        return ['total' => $totalCount, 'new_in_range' => $newCount];
    }

    private function recentActivities(string $since): array
    {
        global $wpdb;
        $table = $wpdb->prefix . 'avina_activities';

        $where = 'is_archived = 0 AND created_at >= %s';
        $visibility = Scope::visibilityClause('activities.activity.view', ['owner_user_id', 'created_by_user_id'], 'team_id');
        $whereSql = $visibility !== '' ? "{$where} AND {$visibility}" : $where;

        $rows = $wpdb->get_results(
            $wpdb->prepare("SELECT id, kind, subject, created_at FROM {$table} WHERE {$whereSql} ORDER BY created_at DESC LIMIT 10", $since),
            ARRAY_A
        );

        return array_map(static function (array $row): array {
            $row['id'] = (int) $row['id'];
            return $row;
        }, $rows ?: []);
    }
}
