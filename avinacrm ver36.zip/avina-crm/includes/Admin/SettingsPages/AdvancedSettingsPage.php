<?php

declare(strict_types=1);

namespace AvinaCRM\Admin\SettingsPages;

use AvinaCRM\Admin\SettingsRegistry;

final class AdvancedSettingsPage extends AbstractSettingsPage
{
    public const SLUG = 'avina-crm-settings-advanced';

    protected function group(): string
    {
        return SettingsRegistry::GROUP_ADVANCED;
    }

    protected function pageSlug(): string
    {
        return self::SLUG;
    }

    protected function sectionTitleFa(): string
    {
        return __('تنظیمات پیشرفته', 'avina-crm');
    }
}
