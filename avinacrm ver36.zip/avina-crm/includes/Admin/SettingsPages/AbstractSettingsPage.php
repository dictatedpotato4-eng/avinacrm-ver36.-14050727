<?php

declare(strict_types=1);

namespace AvinaCRM\Admin\SettingsPages;

use AvinaCRM\Admin\SettingsRegistry;

/**
 * Shared machinery for both settings pages: registers each field with
 * register_setting()/add_settings_field() and renders a masked value for
 * any field flagged `secret` (never echoes the real secret value back
 * into the HTML `value` attribute — only a fixed placeholder, or an
 * empty field if nothing is stored yet).
 */
abstract class AbstractSettingsPage
{
    abstract protected function group(): string;

    abstract protected function pageSlug(): string;

    abstract protected function sectionTitleFa(): string;

    public function registerSettings(): void
    {
        $group = $this->group();

        foreach (SettingsRegistry::fieldsInGroup($group) as $field) {
            register_setting(
                $group,
                $field['key'],
                [
                    'type' => $field['type'],
                    'default' => $field['default'],
                    'sanitize_callback' => $field['sanitize'],
                    // Secrets never autoload with the rest of wp_options on
                    // every page request (Stage 2 decision #2).
                    'show_in_rest' => false,
                ]
            );

            if ($field['secret']) {
                // add_option() only sets autoload on first creation; if the
                // option does not exist yet, seed it explicitly with
                // autoload = 'no' so it is never loaded on every request.
                if (get_option($field['key'], null) === null) {
                    add_option($field['key'], $field['default'], '', 'no');
                }

                // Secret fields always render blank in the UI (never echo
                // the real value back). Submitting the form with the field
                // left blank must mean "keep the existing secret", not
                // "erase it" — otherwise every unrelated settings save
                // would silently wipe any configured secret.
                add_filter(
                    'pre_update_option_' . $field['key'],
                    static function ($newValue, $oldValue) {
                        if ($newValue === '' || $newValue === null) {
                            return $oldValue;
                        }
                        return $newValue;
                    },
                    10,
                    2
                );
            }
        }

        // WordPress core's options.php save handler checks
        // current_user_can('manage_options') by default for any settings
        // group; this filter narrows that check to this group's own
        // real capability instead, per each field's declared requirement.
        add_filter('option_page_capability_' . $group, function () use ($group) {
            $fields = SettingsRegistry::fieldsInGroup($group);
            return $fields[0]['capability'] ?? 'manage_options';
        });

        add_settings_section(
            $group . '_section',
            $this->sectionTitleFa(),
            '__return_false',
            $this->pageSlug()
        );

        foreach (SettingsRegistry::fieldsInGroup($group) as $field) {
            add_settings_field(
                $field['key'],
                esc_html($field['label_fa']),
                function () use ($field) {
                    $this->renderField($field);
                },
                $this->pageSlug(),
                $group . '_section'
            );
        }
    }

    private function renderField(array $field): void
    {
        $stored = get_option($field['key'], $field['default']);

        if ($field['secret']) {
            $hasValue = is_string($stored) && $stored !== '';
            printf(
                '<input type="password" name="%1$s" value="" placeholder="%2$s" autocomplete="new-password" class="regular-text" />',
                esc_attr($field['key']),
                $hasValue ? esc_attr__('•••••••• (مقداری ذخیره شده است — برای تغییر، مقدار جدید را وارد کنید)', 'avina-crm') : esc_attr__('مقداری تنظیم نشده است', 'avina-crm')
            );
            // Secret fields render blank; leaving the field empty on save
            // means "keep the existing value" — handled by the sanitize
            // callback's caller (see save-time merge in SettingsPage).
        } elseif ($field['type'] === 'boolean') {
            printf(
                '<label><input type="checkbox" name="%1$s" value="1" %2$s /> %3$s</label>',
                esc_attr($field['key']),
                checked((bool) $stored, true, false),
                esc_html__('فعال', 'avina-crm')
            );
        } elseif ($field['key'] === 'avina_crm_default_theme') {
            printf('<select name="%s">', esc_attr($field['key']));
            printf(
                '<option value="light" %s>%s</option>',
                selected($stored, 'light', false),
                esc_html__('روشن', 'avina-crm')
            );
            printf(
                '<option value="dark" %s>%s</option>',
                selected($stored, 'dark', false),
                esc_html__('تیره', 'avina-crm')
            );
            echo '</select>';
        } elseif ($field['key'] === 'avina_crm_gemini_instruction') {
            printf(
                '<textarea name="%1$s" rows="5" class="large-text">%2$s</textarea>',
                esc_attr($field['key']),
                esc_textarea((string) $stored)
            );
        } else {
            printf(
                '<input type="text" name="%1$s" value="%2$s" class="regular-text" />',
                esc_attr($field['key']),
                esc_attr((string) $stored)
            );
        }

        printf('<p class="description">%s</p>', esc_html($field['help_fa']));
    }

    public function render(): void
    {
        if (!current_user_can('settings.setting.view')) {
            wp_die(esc_html__('شما اجازه دسترسی به این صفحه را ندارید.', 'avina-crm'));
        }

        echo '<div class="wrap" dir="rtl">';
        printf('<h1>%s</h1>', esc_html(get_admin_page_title()));
        echo '<form method="post" action="options.php">';
        settings_fields($this->group());
        do_settings_sections($this->pageSlug());
        if (current_user_can('settings.setting.update')) {
            submit_button(__('ذخیره تغییرات', 'avina-crm'));
        }
        echo '</form>';
        echo '</div>';
    }
}
