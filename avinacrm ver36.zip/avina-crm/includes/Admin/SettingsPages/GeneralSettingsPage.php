<?php

declare(strict_types=1);

namespace AvinaCRM\Admin\SettingsPages;

use AvinaCRM\Admin\SettingsRegistry;

final class GeneralSettingsPage extends AbstractSettingsPage
{
    public const SLUG = 'avina-crm-settings-general';

    protected function group(): string
    {
        return SettingsRegistry::GROUP_GENERAL;
    }

    protected function pageSlug(): string
    {
        return self::SLUG;
    }

    protected function sectionTitleFa(): string
    {
        return __('تنظیمات عمومی', 'avina-crm');
    }
}
