<?php

declare(strict_types=1);

namespace AvinaCRM\Admin;

use AvinaCRM\Database\Migrator;
use AvinaCRM\Database\Schema;

final class DiagnosticsPage
{
    public const SLUG = 'avina-crm-diagnostics';

    public function render(): void
    {
        if (!current_user_can('platform.diagnostics.view')) {
            wp_die(esc_html__('شما اجازه دسترسی به این صفحه را ندارید.', 'avina-crm'));
        }

        global $wpdb;

        $checks = [];

        $phpOk = version_compare(PHP_VERSION, AVINA_CRM_MIN_PHP, '>=');
        $checks[] = [
            'label' => __('نسخه PHP', 'avina-crm'),
            'value' => PHP_VERSION . ' (' . sprintf(__('حداقل مورد نیاز: %s', 'avina-crm'), AVINA_CRM_MIN_PHP) . ')',
            'ok' => $phpOk,
        ];

        $dbVersion = get_option(Migrator::OPTION_DB_VERSION, '0');
        $checks[] = [
            'label' => __('نسخه ساختار پایگاه‌داده', 'avina-crm'),
            'value' => (string) $dbVersion . ' / ' . Migrator::DB_VERSION,
            'ok' => version_compare((string) $dbVersion, Migrator::DB_VERSION, '>='),
        ];

        $charsetCollate = $wpdb->get_charset_collate();
        $allTableKeys = array_merge(
            array_keys(Schema::moduleDefinitions($wpdb->prefix, $charsetCollate)),
            array_keys(Schema::businessDefinitions($wpdb->prefix, $charsetCollate)),
            array_keys(Schema::salesDefinitions($wpdb->prefix, $charsetCollate)),
            array_keys(Schema::integrationDefinitions($wpdb->prefix, $charsetCollate))
        );
        foreach ($allTableKeys as $tableKey) {
            $tableName = $wpdb->prefix . 'avina_' . $tableKey;
            $exists = $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $tableName)) === $tableName;
            $checks[] = [
                'label' => sprintf(__('جدول %s', 'avina-crm'), $tableName),
                'value' => $exists ? __('موجود است', 'avina-crm') : __('یافت نشد', 'avina-crm'),
                'ok' => $exists,
            ];
        }

        $checks[] = [
            'label' => __('نقش اپراتور', 'avina-crm'),
            'value' => get_role(\AvinaCRM\Capabilities\RoleProvisioner::ROLE_SLUG) !== null ? __('ثبت شده', 'avina-crm') : __('ثبت نشده', 'avina-crm'),
            'ok' => get_role(\AvinaCRM\Capabilities\RoleProvisioner::ROLE_SLUG) !== null,
        ];

        echo '<div class="wrap" dir="rtl">';
        echo '<h1>' . esc_html__('تشخیص سامانه آوینا CRM', 'avina-crm') . '</h1>';
        echo '<table class="widefat striped"><thead><tr>';
        echo '<th>' . esc_html__('بررسی', 'avina-crm') . '</th><th>' . esc_html__('مقدار', 'avina-crm') . '</th><th>' . esc_html__('وضعیت', 'avina-crm') . '</th>';
        echo '</tr></thead><tbody>';

        foreach ($checks as $check) {
            echo '<tr>';
            echo '<td>' . esc_html($check['label']) . '</td>';
            echo '<td>' . esc_html($check['value']) . '</td>';
            echo '<td>' . ($check['ok'] ? '<span style="color:#1a7f37;">✓ ' . esc_html__('سالم', 'avina-crm') . '</span>' : '<span style="color:#d63638;">✗ ' . esc_html__('نیازمند بررسی', 'avina-crm') . '</span>') . '</td>';
            echo '</tr>';
        }

        echo '</tbody></table>';
        echo '</div>';
    }
}
