<?php

declare(strict_types=1);

namespace AvinaCRM\Admin;

use AvinaCRM\Audit\AuditLogger;
use AvinaCRM\Capabilities\RoleProvisioner;
use AvinaCRM\Operators\OperatorService;

final class OperatorsPage
{
    public const SLUG = 'avina-crm-operators';
    public const FORM_ACTION = 'avina_crm_create_operator';
    public const NONCE_ACTION = 'avina_crm_create_operator_action';
    public const NONCE_FIELD = 'avina_crm_create_operator_nonce';

    public function registerFormHandler(): void
    {
        add_action('admin_post_' . self::FORM_ACTION, [$this, 'handleCreate']);
    }

    public function render(): void
    {
        if (!current_user_can('users-roles.user.view')) {
            wp_die(esc_html__('شما اجازه دسترسی به این صفحه را ندارید.', 'avina-crm'));
        }

        $service = new OperatorService(new RoleProvisioner(), new AuditLogger());
        $operators = $service->listOperators();
        $canCreate = current_user_can('users-roles.user.create');
        $notice = isset($_GET['avina_crm_notice']) ? sanitize_key(wp_unslash($_GET['avina_crm_notice'])) : '';

        echo '<div class="wrap" dir="rtl">';
        echo '<h1>' . esc_html__('اپراتورهای آوینا CRM', 'avina-crm') . '</h1>';

        if ($notice === 'created') {
            echo '<div class="notice notice-success"><p>' . esc_html__('اپراتور جدید با موفقیت ایجاد شد. ایمیل تنظیم گذرواژه برای او ارسال شد.', 'avina-crm') . '</p></div>';
        } elseif ($notice === 'error') {
            $message = isset($_GET['avina_crm_message']) ? sanitize_text_field(wp_unslash($_GET['avina_crm_message'])) : '';
            echo '<div class="notice notice-error"><p>' . esc_html($message !== '' ? $message : __('خطایی در ایجاد اپراتور رخ داد.', 'avina-crm')) . '</p></div>';
        }

        echo '<h2>' . esc_html__('لیست اپراتورها', 'avina-crm') . '</h2>';
        echo '<table class="widefat striped"><thead><tr>';
        echo '<th>' . esc_html__('نام نمایشی', 'avina-crm') . '</th>';
        echo '<th>' . esc_html__('نام کاربری', 'avina-crm') . '</th>';
        echo '<th>' . esc_html__('ایمیل', 'avina-crm') . '</th>';
        echo '<th>' . esc_html__('صفحه اختصاصی', 'avina-crm') . '</th>';
        echo '</tr></thead><tbody>';

        if (empty($operators)) {
            echo '<tr><td colspan="4">' . esc_html__('هنوز هیچ اپراتوری ایجاد نشده است.', 'avina-crm') . '</td></tr>';
        }

        foreach ($operators as $operator) {
            echo '<tr>';
            echo '<td>' . esc_html($operator['display_name']) . '</td>';
            echo '<td>' . esc_html($operator['username']) . '</td>';
            echo '<td>' . esc_html($operator['email']) . '</td>';
            if ($operator['page_id']) {
                // Deliberately get_permalink(), not get_edit_post_link():
                // this must open the real, chrome-free front-end app
                // shell (a new tab, no wp-admin/editor wrapper), not the
                // Gutenberg editor's broken live-shortcode-preview iframe.
                $viewLink = get_permalink($operator['page_id']);
                echo '<td>' . ($viewLink ? '<a href="' . esc_url($viewLink) . '" target="_blank" rel="noopener">' . esc_html__('مشاهده صفحه', 'avina-crm') . '</a>' : esc_html__('دارد', 'avina-crm')) . '</td>';
            } else {
                echo '<td>' . esc_html__('ندارد', 'avina-crm') . '</td>';
            }
            echo '</tr>';
        }

        echo '</tbody></table>';

        if ($canCreate) {
            echo '<h2>' . esc_html__('ایجاد اپراتور جدید', 'avina-crm') . '</h2>';
            echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '">';
            wp_nonce_field(self::NONCE_ACTION, self::NONCE_FIELD);
            echo '<input type="hidden" name="action" value="' . esc_attr(self::FORM_ACTION) . '" />';
            echo '<table class="form-table"><tbody>';

            echo '<tr><th><label for="avina_full_name">' . esc_html__('نام کامل', 'avina-crm') . '</label></th>';
            echo '<td><input type="text" id="avina_full_name" name="full_name" class="regular-text" required /></td></tr>';

            echo '<tr><th><label for="avina_username">' . esc_html__('نام کاربری', 'avina-crm') . '</label></th>';
            echo '<td><input type="text" id="avina_username" name="username" class="regular-text" required /></td></tr>';

            echo '<tr><th><label for="avina_email">' . esc_html__('ایمیل', 'avina-crm') . '</label></th>';
            echo '<td><input type="email" id="avina_email" name="email" class="regular-text" required /></td></tr>';

            echo '<tr><th>' . esc_html__('صفحه اختصاصی', 'avina-crm') . '</th>';
            echo '<td><label><input type="checkbox" name="create_page" value="1" checked /> ' . esc_html__('ایجاد صفحه اختصاصی با کد کوتاه داشبورد اپراتور', 'avina-crm') . '</label></td></tr>';

            echo '</tbody></table>';
            submit_button(__('ایجاد اپراتور', 'avina-crm'));
            echo '</form>';
        }

        echo '</div>';
    }

    public function handleCreate(): void
    {
        if (!current_user_can('users-roles.user.create')) {
            wp_die(esc_html__('شما اجازه ایجاد اپراتور را ندارید.', 'avina-crm'));
        }

        check_admin_referer(self::NONCE_ACTION, self::NONCE_FIELD);

        $service = new OperatorService(new RoleProvisioner(), new AuditLogger());

        $result = $service->createOperator(
            [
                'full_name' => sanitize_text_field(wp_unslash($_POST['full_name'] ?? '')),
                'username' => sanitize_text_field(wp_unslash($_POST['username'] ?? '')),
                'email' => sanitize_text_field(wp_unslash($_POST['email'] ?? '')),
                'create_page' => !empty($_POST['create_page']),
            ],
            get_current_user_id()
        );

        $redirectUrl = admin_url('admin.php?page=' . self::SLUG);

        if (is_wp_error($result)) {
            $redirectUrl = add_query_arg(
                [
                    'avina_crm_notice' => 'error',
                    'avina_crm_message' => rawurlencode($result->get_error_message()),
                ],
                $redirectUrl
            );
        } else {
            $redirectUrl = add_query_arg(['avina_crm_notice' => 'created'], $redirectUrl);
        }

        wp_safe_redirect($redirectUrl);
        exit;
    }
}
