<?php

declare(strict_types=1);

namespace AvinaCRM\Admin;

/**
 * Every setting the plugin exposes, in one declarative list, each with:
 * stable option key, type, default, sanitize callback, capability
 * requirement, Persian label, one-line Persian help text, and whether it
 * is a secret (masked in the UI, autoload disabled, never echoed back
 * into an HTML value attribute, never included in REST responses or
 * logs).
 *
 * Stage 2 registers only a General group (real, functional) and an
 * Advanced group containing one worked example of a secret field
 * (webhook secret) so the masking/autoload-off mechanism exists and is
 * exercised — no module in this stage actually consumes it yet; that
 * happens when a later stage (e.g. Messaging/SMS) adds its own real
 * secret fields using this exact same mechanism.
 */
final class SettingsRegistry
{
    public const GROUP_GENERAL = 'avina_crm_general';
    public const GROUP_ADVANCED = 'avina_crm_advanced';

    /**
     * @return array<int, array{
     *   key: string, group: string, type: string, default: mixed,
     *   sanitize: callable, capability: string, label_fa: string,
     *   help_fa: string, secret: bool
     * }>
     */
    public static function fields(): array
    {
        return [
            [
                'key' => 'avina_crm_app_name',
                'group' => self::GROUP_GENERAL,
                'type' => 'string',
                'default' => 'آوینا CRM',
                'sanitize' => 'sanitize_text_field',
                'capability' => 'settings.setting.update',
                'label_fa' => 'نام سامانه',
                'help_fa' => 'نامی که در بالای پنل عملیاتی آوینا نمایش داده می‌شود.',
                'secret' => false,
            ],
            [
                'key' => 'avina_crm_default_theme',
                'group' => self::GROUP_GENERAL,
                'type' => 'string',
                'default' => 'dark',
                'sanitize' => [self::class, 'sanitizeTheme'],
                'capability' => 'settings.setting.update',
                'label_fa' => 'پوسته پیش‌فرض',
                'help_fa' => 'پوسته روشن یا تیره‌ای که به‌طور پیش‌فرض برای کاربران جدید نمایش داده می‌شود.',
                'secret' => false,
            ],
            [
                'key' => 'avina_crm_debug_mode',
                'group' => self::GROUP_GENERAL,
                'type' => 'boolean',
                'default' => false,
                'sanitize' => [self::class, 'sanitizeBool'],
                'capability' => 'settings.setting.update',
                'label_fa' => 'حالت اشکال‌زدایی',
                'help_fa' => 'در صورت فعال بودن، جزئیات فنی بیشتری در گزارش سامانه ثبت می‌شود. هیچ‌گاه اطلاعات محرمانه ثبت نمی‌شود.',
                'secret' => false,
            ],
            [
                'key' => 'avina_crm_webhook_secret',
                'group' => self::GROUP_ADVANCED,
                'type' => 'string',
                'default' => '',
                'sanitize' => [self::class, 'sanitizeSecret'],
                'capability' => 'settings.setting.update',
                'label_fa' => 'کلید مخفی وب‌هوک (نمونه)',
                'help_fa' => 'این مقدار هرگز در پاسخ‌های API، صفحه سایت یا گزارش‌ها نمایش داده نمی‌شود.',
                'secret' => true,
            ],
            [
                'key' => 'avina_crm_gemini_api_key',
                'group' => self::GROUP_ADVANCED,
                'type' => 'string',
                'default' => '',
                'sanitize' => [self::class, 'sanitizeSecret'],
                'capability' => 'settings.setting.update',
                'label_fa' => 'کلید Gemini API هوش مصنوعی آوینا',
                'help_fa' => 'کلید API رایگان از Google AI Studio برای دستیار هوشمند آوینا.',
                'secret' => true,
            ],
            [
                'key' => 'avina_crm_gemini_instruction',
                'group' => self::GROUP_ADVANCED,
                'type' => 'string',
                'default' => 'شما دستیار هوش مصنوعی آوینا در سیستم ارتباط با مشتری هستید. به سوالات با مهربانی، دقت و زبان فارسی پاسخ دهید و راه‌کارهای بازاریابی بدهید.',
                'sanitize' => 'sanitize_textarea_field',
                'capability' => 'settings.setting.update',
                'label_fa' => 'تربیت و رفتار دستیار آوینا',
                'help_fa' => 'دستورالعمل‌هایی که دستیار هوش مصنوعی آوینا باید در تحلیل داده‌ها و گفتگو رعایت کند.',
                'secret' => false,
            ],
        ];
    }

    public static function field(string $key): ?array
    {
        foreach (self::fields() as $field) {
            if ($field['key'] === $key) {
                return $field;
            }
        }

        return null;
    }

    /**
     * @return array<int, array{key: string, group: string, type: string,
     *   default: mixed, sanitize: callable, capability: string,
     *   label_fa: string, help_fa: string, secret: bool}>
     */
    public static function fieldsInGroup(string $group): array
    {
        return array_values(array_filter(
            self::fields(),
            static fn (array $field): bool => $field['group'] === $group
        ));
    }

    public static function sanitizeTheme($value): string
    {
        $value = is_string($value) ? $value : '';

        return in_array($value, ['light', 'dark'], true) ? $value : 'light';
    }

    public static function sanitizeBool($value): bool
    {
        return (bool) $value;
    }

    /**
     * Secret sanitize callback: trims and caps length, but performs no
     * other transformation. Masking for *display* happens in the
     * rendering layer (SettingsPage), never here — this callback only
     * controls what gets persisted.
     */
    public static function sanitizeSecret($value): string
    {
        $value = is_string($value) ? trim($value) : '';

        return substr($value, 0, 255);
    }
}
