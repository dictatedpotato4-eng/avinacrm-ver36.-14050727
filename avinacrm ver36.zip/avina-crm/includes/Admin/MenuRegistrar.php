<?php

declare(strict_types=1);

namespace AvinaCRM\Admin;

use AvinaCRM\Admin\SettingsPages\AdvancedSettingsPage;
use AvinaCRM\Admin\SettingsPages\GeneralSettingsPage;

final class MenuRegistrar
{
    private OperatorsPage $operatorsPage;
    private ModulesPage $modulesPage;
    private DiagnosticsPage $diagnosticsPage;
    private GeneralSettingsPage $generalSettingsPage;
    private AdvancedSettingsPage $advancedSettingsPage;
    private FormBuilderPage $formBuilderPage;

    public function __construct()
    {
        $this->operatorsPage = new OperatorsPage();
        $this->modulesPage = new ModulesPage();
        $this->diagnosticsPage = new DiagnosticsPage();
        $this->generalSettingsPage = new GeneralSettingsPage();
        $this->advancedSettingsPage = new AdvancedSettingsPage();
        $this->formBuilderPage = new FormBuilderPage();
    }

    public function bootstrap(): void
    {
        $this->operatorsPage->registerFormHandler();

        add_action('admin_init', function () {
            $this->generalSettingsPage->registerSettings();
            $this->advancedSettingsPage->registerSettings();
        });

        // Deliberately NOT enqueuing the Tailwind runtime or the React
        // app bundle inside wp-admin: wp-admin's own core CSS/JS
        // (admin-bar, dashicons, jQuery-driven admin scripts, and every
        // other active plugin's admin assets) is not isolated from the
        // page content the way the dedicated frontend app-shell template
        // is (see TemplateController — that page skips get_header()/
        // get_footer() entirely). Loading the same Tailwind-driven app
        // shell on top of the full wp-admin chrome caused unstyled/
        // oversized elements whenever the Tailwind CDN script failed to
        // load or ran into a specificity conflict with wp-admin's CSS.
        // The wp-admin pages below now only ever link out to the real
        // app shell (a dedicated, chrome-free WordPress Page), never
        // render it inline.
        add_action('admin_menu', [$this, 'registerMenu']);
    }

    public function registerMenu(): void
    {
        if (!current_user_can('platform.admin.access')) {
            return;
        }

        add_menu_page(
            __('آوینا CRM', 'avina-crm'),
            __('آوینا CRM', 'avina-crm'),
            'platform.admin.access',
            'avina-crm',
            [$this, 'renderDashboard'],
            'dashicons-groups',
            26
        );

        add_submenu_page(
            'avina-crm',
            __('ورود به داشبورد CRM', 'avina-crm'),
            __('ورود به داشبورد CRM', 'avina-crm'),
            'platform.admin.access',
            'avina-crm',
            [$this, 'renderDashboard']
        );

        add_submenu_page(
            'avina-crm',
            __('اپراتورها', 'avina-crm'),
            __('اپراتورها', 'avina-crm'),
            'users-roles.user.view',
            OperatorsPage::SLUG,
            [$this->operatorsPage, 'render']
        );

        add_submenu_page(
            'avina-crm',
            __('تنظیمات عمومی', 'avina-crm'),
            __('تنظیمات عمومی', 'avina-crm'),
            'settings.setting.view',
            GeneralSettingsPage::SLUG,
            [$this->generalSettingsPage, 'render']
        );

        add_submenu_page(
            'avina-crm',
            __('تنظیمات پیشرفته', 'avina-crm'),
            __('تنظیمات پیشرفته', 'avina-crm'),
            'settings.setting.view',
            AdvancedSettingsPage::SLUG,
            [$this->advancedSettingsPage, 'render']
        );

        add_submenu_page(
            'avina-crm',
            __('تشخیص سامانه', 'avina-crm'),
            __('تشخیص سامانه', 'avina-crm'),
            'platform.diagnostics.view',
            DiagnosticsPage::SLUG,
            [$this->diagnosticsPage, 'render']
        );
    }

    /**
     * Every "open the CRM" submenu item lands here. Instead of rendering
     * the Tailwind/React app shell inline inside wp-admin (which caused
     * broken/oversized, unstyled UI — see the bootstrap() docblock),
     * this shows a small native wp-admin screen that links out to the
     * real, chrome-free app-shell page and opens it in a new tab
     * automatically. If the browser's popup blocker prevents the
     * automatic open, a normal link is always visible as a fallback.
     */
    public function renderDashboard(): void
    {
        if (!current_user_can('platform.admin.access')) {
            wp_die(esc_html__('شما اجازه دسترسی به این صفحه را ندارید.', 'avina-crm'));
        }

        $appUrl = \AvinaCRM\Support\AdminPageLocator::url();

        echo '<div class="wrap" dir="rtl">';
        echo '<h1>' . esc_html__('آوینا CRM', 'avina-crm') . '</h1>';

        if ($appUrl === null) {
            echo '<div class="notice notice-error"><p>' . esc_html__('صفحه‌ی اختصاصی پنل مدیریت پیدا یا ساخته نشد. لطفاً افزونه را غیرفعال و دوباره فعال کنید، یا یک برگه با کد کوتاه [avina_crm_admin] بسازید.', 'avina-crm') . '</p></div>';
            echo '</div>';
            return;
        }

        echo '<div style="max-width:640px;background:#fff;border:1px solid #dcdcde;border-radius:8px;padding:2rem;margin-top:1rem;text-align:center;">';
        echo '<p style="font-size:1.05rem;margin-bottom:1.5rem;">' . esc_html__('پنل مدیریت آوینا CRM در یک صفحه‌ی جداگانه و بدون چارچوب مدیریت وردپرس اجرا می‌شود تا با استایل‌های افزونه تداخل پیدا نکند. این صفحه به‌طور خودکار در یک تب جدید باز می‌شود.', 'avina-crm') . '</p>';
        echo '<p><a href="' . esc_url($appUrl) . '" target="_blank" rel="noopener" class="button button-primary button-hero">' . esc_html__('باز کردن پنل مدیریت در تب جدید', 'avina-crm') . '</a></p>';
        echo '<p style="margin-top:1rem;color:#646970;font-size:.9rem;">' . esc_html__('اگر تب جدید باز نشد، مرورگر شما احتمالاً پنجره‌های بازشو را مسدود کرده — روی دکمه‌ی بالا کلیک کنید.', 'avina-crm') . '</p>';
        echo '</div>';
        echo '</div>';

        printf(
            '<script>(function(){var w=window.open(%s, "_blank", "noopener");})();</script>',
            wp_json_encode($appUrl)
        );
    }
}
