<?php

declare(strict_types=1);

namespace AvinaCRM\Activities;

use AvinaCRM\Audit\AuditLogger;
use AvinaCRM\Support\Scope;
use WP_Error;

final class ActivityService
{
    public const KINDS = ['call', 'meeting', 'note'];

    private AuditLogger $audit;

    public function __construct(?AuditLogger $audit = null)
    {
        $this->audit = $audit ?? new AuditLogger();
    }

    public function list(array $filters): array
    {
        global $wpdb;
        $table = $wpdb->prefix . 'avina_activities';

        $where = ['is_archived = 0'];

        $visibility = Scope::visibilityClause('activities.activity.view', ['owner_user_id', 'created_by_user_id'], 'team_id');
        if ($visibility !== '') {
            $where[] = $visibility;
        }

        if (!empty($filters['related_type']) && !empty($filters['related_id'])) {
            $where[] = $wpdb->prepare('related_type = %s AND related_id = %d', $filters['related_type'], (int) $filters['related_id']);
        }

        if (!empty($filters['kind']) && in_array($filters['kind'], self::KINDS, true)) {
            $where[] = $wpdb->prepare('kind = %s', $filters['kind']);
        }

        if (!empty($filters['pending_only'])) {
            $where[] = 'completed_at IS NULL';
        }

        $whereSql = implode(' AND ', $where);

        $rows = $wpdb->get_results(
            "SELECT * FROM {$table} WHERE {$whereSql} ORDER BY COALESCE(next_action_at, created_at) ASC LIMIT 200",
            ARRAY_A
        );

        return array_map([$this, 'decorate'], $rows ?: []);
    }

    /**
     * @return array{id: int}|WP_Error
     */
    public function create(array $data, int $actorUserId)
    {
        $kind = in_array($data['kind'] ?? '', self::KINDS, true) ? $data['kind'] : 'note';
        $subject = sanitize_text_field($data['subject'] ?? '');

        if ($subject === '') {
            return new WP_Error('avina_crm_invalid_activity', __('موضوع فعالیت الزامی است.', 'avina-crm'), ['status' => 400]);
        }

        $ownerUserId = !empty($data['owner_user_id']) ? (int) $data['owner_user_id'] : $actorUserId;
        if (get_user_by('id', $ownerUserId) === false) {
            return new WP_Error('avina_crm_invalid_owner', __('کاربر مسئول معتبر نیست.', 'avina-crm'), ['status' => 400]);
        }

        global $wpdb;
        $table = $wpdb->prefix . 'avina_activities';

        $wpdb->insert(
            $table,
            [
                'kind' => $kind,
                'subject' => $subject,
                'body' => sanitize_textarea_field($data['body'] ?? ''),
                'related_type' => sanitize_key($data['related_type'] ?? ''),
                'related_id' => !empty($data['related_id']) ? (int) $data['related_id'] : null,
                'next_action_at' => !empty($data['next_action_at']) ? $this->normalizeDatetime($data['next_action_at']) : null,
                'owner_user_id' => $ownerUserId,
                'team_id' => !empty($data['team_id']) ? (int) $data['team_id'] : null,
                'is_archived' => 0,
                'created_by_user_id' => $actorUserId,
                'created_at' => current_time('mysql'),
                'updated_at' => current_time('mysql'),
            ],
            ['%s', '%s', '%s', '%s', '%d', '%s', '%d', '%d', '%d', '%d', '%s', '%s']
        );

        $id = (int) $wpdb->insert_id;

        $this->audit->record($actorUserId, 'activities.activity.create', 'activity', (string) $id, null, ['subject' => $subject]);

        return ['id' => $id];
    }

    /**
     * @return true|WP_Error
     */
    public function complete(int $id, int $actorUserId)
    {
        global $wpdb;
        $table = $wpdb->prefix . 'avina_activities';

        $existing = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table} WHERE id = %d", $id), ARRAY_A);

        if ($existing === null) {
            return new WP_Error('avina_crm_activity_not_found', __('فعالیت موردنظر یافت نشد.', 'avina-crm'), ['status' => 404]);
        }

        $wpdb->update(
            $table,
            ['completed_at' => current_time('mysql'), 'updated_at' => current_time('mysql')],
            ['id' => $id],
            ['%s', '%s'],
            ['%d']
        );

        $this->audit->record($actorUserId, 'activities.activity.complete', 'activity', (string) $id, null, ['completed' => true]);

        return true;
    }

    private function normalizeDatetime(string $value): string
    {
        $timestamp = strtotime($value);

        return $timestamp !== false ? gmdate('Y-m-d H:i:s', $timestamp) : current_time('mysql');
    }

    private function decorate(array $row): array
    {
        $row['id'] = (int) $row['id'];
        $row['related_id'] = $row['related_id'] !== null ? (int) $row['related_id'] : null;
        $row['owner_user_id'] = $row['owner_user_id'] !== null ? (int) $row['owner_user_id'] : null;
        $row['team_id'] = $row['team_id'] !== null ? (int) $row['team_id'] : null;
        $row['is_completed'] = $row['completed_at'] !== null;

        return $row;
    }
}
