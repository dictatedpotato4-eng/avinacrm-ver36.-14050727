<?php

declare(strict_types=1);

namespace AvinaCRM\Modules;

/**
 * Static registry of the modules this plugin is architected to eventually
 * contain, seeded into the {prefix}avina_modules table by the migrator.
 *
 * Stage 1 decision #3: `social-connectors`, `recruitment`, and `avina` are
 * NOT included here — they had no real implementation in the legacy
 * application and must not appear anywhere, not even as a disabled row,
 * until a future stage gives them a real design and real code.
 *
 * `form-builder` is likewise omitted for the same reason it was already
 * deliberately deferred in the legacy app.
 *
 * Every module here is seeded with is_active = 0: this stage builds the
 * module *registry* (so the Modules admin screen and future per-operator
 * assignment have something real to list), not the modules themselves.
 * A module only flips to is_active = 1 in the stage that actually
 * implements its Controller/Service/Rest/Capabilities classes — never
 * before, and never as a placeholder screen.
 */
final class ModuleDefinitions
{
    /**
     * @return array<int, array{slug: string, name_fa: string, is_core: bool, sort_order: int}>
     */
    public static function all(): array
    {
        return [
            ['slug' => 'platform', 'name_fa' => 'زیرساخت سامانه', 'is_core' => true, 'sort_order' => 10],
            ['slug' => 'module-manager', 'name_fa' => 'مدیریت ماژول‌ها', 'is_core' => true, 'sort_order' => 20],
            ['slug' => 'settings', 'name_fa' => 'تنظیمات', 'is_core' => true, 'sort_order' => 30],
            ['slug' => 'theme-customization', 'name_fa' => 'تم و شخصی‌سازی', 'is_core' => false, 'sort_order' => 40],
            ['slug' => 'contacts', 'name_fa' => 'مخاطبین', 'is_core' => false, 'sort_order' => 50],
            ['slug' => 'customers', 'name_fa' => 'مشتریان', 'is_core' => false, 'sort_order' => 60],
            ['slug' => 'phonebook', 'name_fa' => 'دفترچه تلفن', 'is_core' => false, 'sort_order' => 70],
            ['slug' => 'reception', 'name_fa' => 'پذیرش', 'is_core' => false, 'sort_order' => 80],
            ['slug' => 'kanban', 'name_fa' => 'کانبان', 'is_core' => false, 'sort_order' => 90],
            ['slug' => 'activities', 'name_fa' => 'فعالیت‌ها و پیگیری‌ها', 'is_core' => false, 'sort_order' => 95],
            ['slug' => 'teams', 'name_fa' => 'تیم‌ها', 'is_core' => false, 'sort_order' => 45],
            ['slug' => 'tasks', 'name_fa' => 'وظایف', 'is_core' => false, 'sort_order' => 100],
            ['slug' => 'reminders', 'name_fa' => 'یادآورها و پیگیری‌ها', 'is_core' => false, 'sort_order' => 110],
            ['slug' => 'reports', 'name_fa' => 'گزارشات', 'is_core' => false, 'sort_order' => 120],
            ['slug' => 'deals', 'name_fa' => 'معاملات', 'is_core' => false, 'sort_order' => 130],
            ['slug' => 'invoices', 'name_fa' => 'فاکتورها', 'is_core' => false, 'sort_order' => 140],
            ['slug' => 'payments', 'name_fa' => 'پرداخت‌ها', 'is_core' => false, 'sort_order' => 150],
            ['slug' => 'notifications', 'name_fa' => 'اطلاع‌رسانی', 'is_core' => false, 'sort_order' => 160],
            ['slug' => 'messaging', 'name_fa' => 'پیامک', 'is_core' => false, 'sort_order' => 170],
            ['slug' => 'tickets', 'name_fa' => 'درخواست‌های داخلی', 'is_core' => false, 'sort_order' => 180],
            ['slug' => 'backup-restore', 'name_fa' => 'پشتیبان‌گیری و بازیابی', 'is_core' => false, 'sort_order' => 190],
            ['slug' => 'webhooks', 'name_fa' => 'وب‌هوک‌ها و یکپارچه‌سازی', 'is_core' => false, 'sort_order' => 195],
            ['slug' => 'audit', 'name_fa' => 'ثبت رویداد', 'is_core' => true, 'sort_order' => 200],
            ['slug' => 'security', 'name_fa' => 'امنیت', 'is_core' => true, 'sort_order' => 210],
        ];
    }

    public static function slugs(): array
    {
        return array_column(self::all(), 'slug');
    }
}
