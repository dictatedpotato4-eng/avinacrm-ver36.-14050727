<?php

declare(strict_types=1);

namespace AvinaCRM\Webhooks;

/**
 * Registers listeners for the plugin's internal domain-event hooks
 * (fired by DealService, InvoiceService, TicketService) and turns each
 * into a signed webhook dispatch. This is the only class that calls
 * WebhookService::dispatch() — no REST controller calls it directly, so
 * a webhook can only ever fire in response to a real state change that
 * already passed that module's own authorization checks.
 */
final class WebhookEventListener
{
    private WebhookService $service;

    public function __construct(?WebhookService $service = null)
    {
        $this->service = $service ?? new WebhookService();
    }

    public function bootstrap(): void
    {
        add_action('avina_crm/deal_stage_changed', function (int $dealId, int $stageId, string $status) {
            $this->service->dispatch('deal.stage_changed', ['deal_id' => $dealId, 'stage_id' => $stageId, 'status' => $status]);
        }, 10, 3);

        add_action('avina_crm/deal_won', function (int $dealId) {
            $this->service->dispatch('deal.won', ['deal_id' => $dealId]);
        });

        add_action('avina_crm/deal_lost', function (int $dealId) {
            $this->service->dispatch('deal.lost', ['deal_id' => $dealId]);
        });

        add_action('avina_crm/invoice_paid', function (int $invoiceId) {
            $this->service->dispatch('invoice.paid', ['invoice_id' => $invoiceId]);
        });

        add_action('avina_crm/ticket_created', function (int $ticketId) {
            $this->service->dispatch('ticket.created', ['ticket_id' => $ticketId]);
        });
    }
}
