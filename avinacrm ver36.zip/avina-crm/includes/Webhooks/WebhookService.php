<?php

declare(strict_types=1);

namespace AvinaCRM\Webhooks;

use AvinaCRM\Audit\AuditLogger;
use WP_Error;

/**
 * Webhook secrets are generated once at creation, stored in the
 * database for HMAC signing purposes only, and NEVER read back out
 * through list()/find() — decorate() strips the column unconditionally.
 * There is no "reveal secret" endpoint at all; if a site owner needs the
 * secret again, the only path is deleting and recreating the webhook,
 * which is a deliberate design choice, not an oversight.
 */
final class WebhookService
{
    /** @var array<int, string> event types this plugin can dispatch */
    public const EVENT_TYPES = [
        'deal.stage_changed',
        'deal.won',
        'deal.lost',
        'invoice.paid',
        'ticket.created',
    ];

    private AuditLogger $audit;

    public function __construct(?AuditLogger $audit = null)
    {
        $this->audit = $audit ?? new AuditLogger();
    }

    public function list(): array
    {
        global $wpdb;
        $table = $wpdb->prefix . 'avina_webhooks';

        $rows = $wpdb->get_results("SELECT * FROM {$table} WHERE is_archived = 0 ORDER BY created_at DESC", ARRAY_A);

        return array_map([$this, 'decorate'], $rows ?: []);
    }

    /**
     * @return array{id: int}|WP_Error
     */
    public function create(array $data, int $actorUserId)
    {
        $name = sanitize_text_field($data['name'] ?? '');
        $targetUrl = esc_url_raw($data['target_url'] ?? '');

        if ($name === '' || $targetUrl === '' || !wp_http_validate_url($targetUrl)) {
            return new WP_Error('avina_crm_invalid_webhook', __('نام و آدرس معتبر برای وب‌هوک الزامی است.', 'avina-crm'), ['status' => 400]);
        }

        $eventTypes = array_values(array_intersect((array) ($data['event_types'] ?? []), self::EVENT_TYPES));

        if (empty($eventTypes)) {
            return new WP_Error('avina_crm_invalid_webhook', __('حداقل یک رویداد باید انتخاب شود.', 'avina-crm'), ['status' => 400]);
        }

        $secret = wp_generate_password(40, false, false);

        global $wpdb;
        $table = $wpdb->prefix . 'avina_webhooks';

        $wpdb->insert(
            $table,
            [
                'name' => $name,
                'target_url' => $targetUrl,
                'secret' => $secret,
                'event_types' => implode(',', $eventTypes),
                'is_active' => 1,
                'is_archived' => 0,
                'created_by_user_id' => $actorUserId,
                'created_at' => current_time('mysql'),
                'updated_at' => current_time('mysql'),
            ],
            ['%s', '%s', '%s', '%s', '%d', '%d', '%d', '%s', '%s']
        );

        $id = (int) $wpdb->insert_id;

        // Secret is included ONLY in this single create-response payload,
        // shown once — the same one-time-reveal pattern used for API
        // keys elsewhere. It is never stored in the audit log (redacted
        // automatically by AuditLogger's key-pattern matching on
        // "secret") and never returned by any subsequent GET.
        $this->audit->record($actorUserId, 'webhooks.webhook.create', 'webhook', (string) $id, null, ['name' => $name, 'target_url' => $targetUrl]);

        return ['id' => $id, 'secret' => $secret];
    }

    /**
     * @return true|WP_Error
     */
    public function toggleActive(int $id, bool $isActive, int $actorUserId)
    {
        if (!$this->exists($id)) {
            return new WP_Error('avina_crm_webhook_not_found', __('وب‌هوک موردنظر یافت نشد.', 'avina-crm'), ['status' => 404]);
        }

        global $wpdb;
        $wpdb->update(
            $wpdb->prefix . 'avina_webhooks',
            ['is_active' => $isActive ? 1 : 0, 'updated_at' => current_time('mysql')],
            ['id' => $id],
            ['%d', '%s'],
            ['%d']
        );

        $this->audit->record($actorUserId, 'webhooks.webhook.update', 'webhook', (string) $id, null, ['is_active' => $isActive]);

        return true;
    }

    /**
     * @return true|WP_Error
     */
    public function delete(int $id, int $actorUserId)
    {
        if (!$this->exists($id)) {
            return new WP_Error('avina_crm_webhook_not_found', __('وب‌هوک موردنظر یافت نشد.', 'avina-crm'), ['status' => 404]);
        }

        global $wpdb;
        $wpdb->update(
            $wpdb->prefix . 'avina_webhooks',
            ['is_archived' => 1, 'is_active' => 0, 'updated_at' => current_time('mysql')],
            ['id' => $id],
            ['%d', '%d', '%s'],
            ['%d']
        );

        $this->audit->record($actorUserId, 'webhooks.webhook.delete', 'webhook', (string) $id, null, null);

        return true;
    }

    /**
     * Dispatches an event to every active webhook subscribed to
     * $eventType. Called from domain services (DealService, InvoiceService,
     * TicketService) via a WordPress action hook, not called directly by
     * any REST controller, so a user can never trigger an arbitrary
     * webhook fire through the REST API.
     *
     * @param array<string, mixed> $payload
     */
    public function dispatch(string $eventType, array $payload): void
    {
        global $wpdb;
        $table = $wpdb->prefix . 'avina_webhooks';

        $webhooks = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT * FROM {$table} WHERE is_active = 1 AND is_archived = 0 AND FIND_IN_SET(%s, event_types) > 0",
                $eventType
            ),
            ARRAY_A
        );

        foreach ((array) $webhooks as $webhook) {
            $this->send($webhook, $eventType, $payload);
        }
    }

    private function send(array $webhook, string $eventType, array $payload): void
    {
        $body = wp_json_encode([
            'event' => $eventType,
            'data' => $payload,
            'timestamp' => time(),
        ]);

        // HMAC SHA-256 signature over the raw request body, so the
        // receiving endpoint can verify the payload came from this site
        // and was not tampered with in transit.
        $signature = hash_hmac('sha256', (string) $body, $webhook['secret']);

        $response = wp_remote_post($webhook['target_url'], [
            'timeout' => 10,
            'headers' => [
                'Content-Type' => 'application/json',
                'X-Avina-Signature' => $signature,
                'X-Avina-Event' => $eventType,
            ],
            'body' => $body,
        ]);

        $success = !is_wp_error($response) && (int) wp_remote_retrieve_response_code($response) < 300;
        $status = is_wp_error($response) ? null : (int) wp_remote_retrieve_response_code($response);

        global $wpdb;
        $logsTable = $wpdb->prefix . 'avina_webhook_logs';

        $wpdb->insert(
            $logsTable,
            [
                'webhook_id' => (int) $webhook['id'],
                'event_type' => $eventType,
                // Only a short, non-sensitive summary is logged — never
                // the full payload (which may include business data) and
                // never the signature or secret.
                'payload_summary' => substr($eventType . ':' . wp_json_encode(array_keys($payload)), 0, 500),
                'response_status' => $status,
                'attempt_count' => 1,
                'success' => $success ? 1 : 0,
                'created_at' => current_time('mysql'),
            ],
            ['%d', '%s', '%s', '%d', '%d', '%d', '%s']
        );
    }

    public function logsFor(int $webhookId): array
    {
        global $wpdb;
        $table = $wpdb->prefix . 'avina_webhook_logs';

        $rows = $wpdb->get_results(
            $wpdb->prepare("SELECT * FROM {$table} WHERE webhook_id = %d ORDER BY created_at DESC LIMIT 50", $webhookId),
            ARRAY_A
        );

        return $rows ?: [];
    }

    private function exists(int $id): bool
    {
        global $wpdb;
        $table = $wpdb->prefix . 'avina_webhooks';

        return (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$table} WHERE id = %d AND is_archived = 0", $id)) > 0;
    }

    /**
     * Strips the secret column unconditionally — this is the only
     * function that ever turns a raw webhook row into API-facing data.
     */
    private function decorate(array $row): array
    {
        unset($row['secret']);

        $row['id'] = (int) $row['id'];
        $row['is_active'] = (bool) $row['is_active'];
        $row['event_types'] = $row['event_types'] !== '' ? explode(',', $row['event_types']) : [];

        return $row;
    }
}
