<?php

declare(strict_types=1);

namespace AvinaCRM\Capabilities;

/**
 * Grants every foundation capability to the `administrator` role.
 * `add_cap()` is naturally idempotent (re-adding a capability the role
 * already has is a no-op), so this is safe to call on every activation
 * and does not need its own "already ran" guard.
 *
 * This deliberately does NOT touch any other existing WordPress role —
 * Editors, Authors, Subscribers, etc. are completely unaffected, per the
 * Stage 1 rule against unsafe, unscoped side effects on the host site.
 */
final class CapabilityRegistrar
{
    public function grantToAdministrator(): void
    {
        $role = get_role('administrator');

        if ($role === null) {
            return; // Defensive: a site with no administrator role is not something we can recover from here.
        }

        foreach (CapabilityDefinitions::all() as $capability) {
            if (!$role->has_cap($capability)) {
                $role->add_cap($capability);
            }
        }
    }

    /**
     * Removes only the capabilities this plugin itself added to
     * `administrator`. Called from deactivation. Never touches any other
     * role, and never touches CRM data — capability removal is not data
     * deletion.
     */
    public function revokeFromAdministrator(): void
    {
        $role = get_role('administrator');

        if ($role === null) {
            return;
        }

        foreach (CapabilityDefinitions::all() as $capability) {
            $role->remove_cap($capability);
        }
    }
}
