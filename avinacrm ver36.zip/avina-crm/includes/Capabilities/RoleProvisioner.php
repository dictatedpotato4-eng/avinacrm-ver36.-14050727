<?php

declare(strict_types=1);

namespace AvinaCRM\Capabilities;

/**
 * Owns the `avina_operator` WordPress role: a minimal base role for CRM
 * operators who authenticate with normal WordPress credentials and use
 * only the frontend [avina_crm_user] dashboard, never wp-admin screens.
 *
 * Stage 2 foundation only: this role currently grants `read` (WordPress's
 * own baseline, so the account is a normal, valid WP user) plus
 * `platform.operator_dashboard.view` (access to their own frontend
 * shortcode page). Per-module business capabilities
 * (contacts.contact.view, etc.) are granted individually to a specific
 * operator user by a later stage's admin screen, once those modules
 * exist — this class only establishes the role itself and the mechanism
 * for granting/revoking arbitrary capability strings on a user, which
 * that later work will call into.
 */
final class RoleProvisioner
{
    public const ROLE_SLUG = 'avina_operator';

    public function ensureOperatorRole(): void
    {
        if (get_role(self::ROLE_SLUG) !== null) {
            // Idempotent: role already exists, but make sure it still has
            // the baseline capability in case a prior partial run missed it.
            $role = get_role(self::ROLE_SLUG);
            if (!$role->has_cap('platform.operator_dashboard.view')) {
                $role->add_cap('platform.operator_dashboard.view');
            }
            return;
        }

        add_role(
            self::ROLE_SLUG,
            __('اپراتور آوینا CRM', 'avina-crm'),
            [
                'read' => true,
                'platform.operator_dashboard.view' => true,
            ]
        );
    }

    /**
     * Removes the role definition only — never removes or reassigns the
     * WordPress user accounts that hold it. A user who had this role
     * simply loses the role's capabilities; their account, posts, and any
     * CRM data tied to their user_id are completely untouched.
     */
    public function removeOperatorRole(): void
    {
        if (get_role(self::ROLE_SLUG) !== null) {
            remove_role(self::ROLE_SLUG);
        }
    }

    /**
     * Grants one capability string to one specific user (in addition to
     * whatever their role already grants). Used by future module stages
     * to enable a module for one operator without changing the shared
     * `avina_operator` role for everyone else.
     */
    public function grantCapabilityToUser(int $userId, string $capability): bool
    {
        $user = get_user_by('id', $userId);

        if ($user === false) {
            return false;
        }

        $user->add_cap($capability);

        return true;
    }

    public function revokeCapabilityFromUser(int $userId, string $capability): bool
    {
        $user = get_user_by('id', $userId);

        if ($user === false) {
            return false;
        }

        $user->remove_cap($capability);

        return true;
    }
}
