<?php

declare(strict_types=1);

namespace AvinaCRM\Capabilities;

/**
 * Stage 2 foundation capabilities only. Business-module capabilities
 * (contacts.contact.view, deals.pipeline.manage, etc.) are added by the
 * stage that implements each module — this list only covers what Stage 2
 * itself needs: the admin menu gate, settings, the module registry
 * screen, operator management, audit log viewing, and the two frontend
 * dashboard shortcodes.
 *
 * Naming follows the exact `{module-slug}.{resource}.{action}` convention
 * already established in the legacy application, reusing its literal
 * permission strings wherever an equivalent already existed there
 * (platform.health.view, platform.diagnostics.view, settings.setting.*,
 * audit.log.view, users-roles.user.*, users-roles.user_role.manage).
 */
final class CapabilityDefinitions
{
    /**
     * @return array<int, string>
     */
    public static function all(): array
    {
        return [
            // Admin menu gate — controls whether the «آوینا CRM» top-level
            // wp-admin menu appears at all.
            'platform.admin.access',

            // System status / diagnostics (reused verbatim from the
            // legacy Platform module's Permissions.php).
            'platform.health.view',
            'platform.diagnostics.view',

            // Frontend shortcode gates.
            'platform.admin_dashboard.view',
            'platform.operator_dashboard.view',

            // Settings (reused verbatim from the legacy Settings module).
            'settings.setting.view',
            'settings.setting.update',

            // Audit (reused verbatim from the legacy Audit module).
            'audit.log.view',

            // Operator/user management (reused verbatim from the legacy
            // UsersRoles module, minus the parts WordPress now owns
            // natively — no users-roles.role.* here, since WordPress
            // roles/capabilities themselves replace that sub-scope).
            'users-roles.user.view',
            'users-roles.user.create',
            'users-roles.user.update',
            'users-roles.user.disable',
            'users-roles.user_role.manage',

            // Module registry (new — the legacy app had no wp-admin-style
            // menu to gate, so this concept did not exist there).
            'module-manager.module.view',
            'module-manager.module.manage',

            // Teams (Stage 3).
            'teams.team.view',
            'teams.team.create',
            'teams.team.update',
            'teams.team.manage_members',

            // Contacts (Stage 3, reused verbatim from the legacy Contacts
            // module's Permissions.php).
            'contacts.contact.view',
            'contacts.contact.create',
            'contacts.contact.update',
            'contacts.contact.archive',
            'contacts.contact.export',

            // Customers (Stage 3, reused verbatim where the legacy module
            // already defined the equivalent).
            'customers.customer.view',
            'customers.customer.create',
            'customers.customer.update',
            'customers.customer.archive',
            'customers.customer.convert',

            // Phonebook (Stage 3 — read-projection over contacts/customers).
            'phonebook.entry.view',

            // Reception (Stage 3, reused verbatim from the legacy Reception
            // module's Permissions.php).
            'reception.reception.view',
            'reception.reception.create',
            'reception.reception.update',
            'reception.reception.checkout',

            // Activities & follow-ups (Stage 3 — new module, no legacy
            // equivalent existed as its own module).
            'activities.activity.view',
            'activities.activity.create',
            'activities.activity.update',
            'activities.activity.complete',

            // Tasks (Stage 3, reused verbatim from the legacy Tasks module).
            'tasks.task.view',
            'tasks.task.create',
            'tasks.task.update',
            'tasks.task.assign',
            'tasks.task.complete',

            // Reminders (Stage 3, reused verbatim from the legacy Reminders
            // module).
            'reminders.reminder.view',
            'reminders.reminder.create',
            'reminders.reminder.update',
            'reminders.reminder.dismiss',

            // Notifications (Stage 3, reused verbatim from the legacy
            // Notifications module).
            'notifications.notification.view',
            'notifications.notification.markread',

            // Tickets / internal requests (Stage 3 — implements the gap
            // identified in Stage 1 §10 and closed by Stage 2 decision #6).
            'tickets.ticket.view',
            'tickets.ticket.create',
            'tickets.ticket.reply',
            'tickets.ticket.manage_status',

            // Pipelines & stages (Stage 4).
            'pipelines.pipeline.view',
            'pipelines.pipeline.create',
            'pipelines.pipeline.update',
            'pipelines.pipeline.archive',

            // Deals & opportunities (Stage 4, reused verbatim where the
            // legacy Deals module already defined an equivalent).
            'deals.deal.view',
            'deals.deal.create',
            'deals.deal.update',
            'deals.deal.archive',
            'deals.deal.change_stage',

            // Invoices & items (Stage 4, reused verbatim from the legacy
            // Invoices module's Permissions.php).
            'invoices.invoice.view',
            'invoices.invoice.create',
            'invoices.invoice.update',
            'invoices.invoice.void',

            // Payments (Stage 4, reused verbatim from the legacy Payments
            // module's Permissions.php).
            'payments.payment.view',
            'payments.payment.create',

            // Analytics & dashboard (Stage 5).
            'analytics.dashboard.view',

            // Webhooks & integrations (Stage 5).
            'webhooks.webhook.view',
            'webhooks.webhook.create',
            'webhooks.webhook.update',
            'webhooks.webhook.delete',

            // Backup/export (Stage 5, reused verbatim from the legacy
            // Backup module's Permissions.php).
            'backup.export.download',
        ];
    }
}
