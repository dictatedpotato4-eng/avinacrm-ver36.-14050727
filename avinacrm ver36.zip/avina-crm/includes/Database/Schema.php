<?php

declare(strict_types=1);

namespace AvinaCRM\Database;

/**
 * Stage 2 foundation schema only. No CRM business-data tables (contacts,
 * deals, invoices, etc.) are created here — those belong to the stage
 * that implements each module. What Stage 2 needs tables for:
 *
 *  - avina_modules            module registry (drives the Modules admin
 *                              screen and future per-operator assignment)
 *  - avina_user_module_access per-user module visibility (Stage 1 §5: a
 *                              UI-visibility concern only, never itself
 *                              an authorization boundary)
 *  - avina_operator_pages     which WP page/shortcode instance belongs to
 *                              which operator (CRM page assignment
 *                              foundation)
 *  - avina_audit_log          foundation-level audit trail, so every
 *                              capability grant/revoke and operator
 *                              create/update from this stage onward is
 *                              already recorded, not bolted on later
 *
 * All FOREIGN KEY constraints are intentionally omitted (Stage 1 decision
 * #5 / Stage 2 decision #5): dbDelta() does not manage them reliably
 * across MySQL/MariaDB versions on shared hosting. Referential integrity
 * is enforced in the repository/service layer that writes to these
 * tables, not by the database schema itself.
 */
final class Schema
{
    public static function moduleDefinitions(string $prefix, string $charsetCollate): array
    {
        return [
            'modules' => "CREATE TABLE {$prefix}avina_modules (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  slug VARCHAR(100) NOT NULL,
  name_fa VARCHAR(191) NOT NULL,
  is_core TINYINT(1) NOT NULL DEFAULT 0,
  is_active TINYINT(1) NOT NULL DEFAULT 0,
  sort_order INT UNSIGNED NOT NULL DEFAULT 0,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY  (id),
  UNIQUE KEY slug (slug),
  KEY is_active (is_active)
) {$charsetCollate};",

            'user_module_access' => "CREATE TABLE {$prefix}avina_user_module_access (
  user_id BIGINT UNSIGNED NOT NULL,
  module_id BIGINT UNSIGNED NOT NULL,
  is_visible TINYINT(1) NOT NULL DEFAULT 1,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY  (user_id, module_id),
  KEY module_id (module_id)
) {$charsetCollate};",

            'operator_pages' => "CREATE TABLE {$prefix}avina_operator_pages (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  user_id BIGINT UNSIGNED NOT NULL,
  page_id BIGINT UNSIGNED NOT NULL,
  is_active TINYINT(1) NOT NULL DEFAULT 1,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY  (id),
  UNIQUE KEY user_id (user_id),
  KEY page_id (page_id)
) {$charsetCollate};",

            'audit_log' => "CREATE TABLE {$prefix}avina_audit_log (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  actor_user_id BIGINT UNSIGNED NULL,
  action VARCHAR(191) NOT NULL,
  object_type VARCHAR(100) NULL,
  object_id VARCHAR(64) NULL,
  before_state LONGTEXT NULL,
  after_state LONGTEXT NULL,
  ip_address VARCHAR(45) NOT NULL DEFAULT '',
  user_agent VARCHAR(255) NOT NULL DEFAULT '',
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY  (id),
  KEY actor_user_id (actor_user_id),
  KEY action (action),
  KEY object (object_type, object_id)
) {$charsetCollate};",
        ];
    }

    /**
     * Stage 3 business-module tables. Same conventions as
     * moduleDefinitions(): WordPress prefix, no FOREIGN KEY constraints
     * (referential integrity is enforced by each module's Service class
     * before every write), soft-delete via a `status`/`is_archived`
     * column rather than physical DELETE.
     */
    public static function businessDefinitions(string $prefix, string $charsetCollate): array
    {
        return [
            'teams' => "CREATE TABLE {$prefix}avina_teams (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  name VARCHAR(191) NOT NULL,
  description TEXT NULL,
  is_archived TINYINT(1) NOT NULL DEFAULT 0,
  created_by_user_id BIGINT UNSIGNED NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY  (id),
  KEY is_archived (is_archived)
) {$charsetCollate};",

            'team_members' => "CREATE TABLE {$prefix}avina_team_members (
  team_id BIGINT UNSIGNED NOT NULL,
  user_id BIGINT UNSIGNED NOT NULL,
  role_in_team VARCHAR(50) NOT NULL DEFAULT 'member',
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY  (team_id, user_id),
  KEY user_id (user_id)
) {$charsetCollate};",

            'contacts' => "CREATE TABLE {$prefix}avina_contacts (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  full_name VARCHAR(191) NOT NULL,
  phone VARCHAR(32) NOT NULL DEFAULT '',
  email VARCHAR(191) NOT NULL DEFAULT '',
  tags VARCHAR(500) NOT NULL DEFAULT '',
  lifecycle_stage VARCHAR(30) NOT NULL DEFAULT 'lead',
  owner_user_id BIGINT UNSIGNED NULL,
  team_id BIGINT UNSIGNED NULL,
  is_archived TINYINT(1) NOT NULL DEFAULT 0,
  created_by_user_id BIGINT UNSIGNED NULL,
  custom_fields LONGTEXT NULL,
  job VARCHAR(100) NOT NULL DEFAULT '',
  requirement_type VARCHAR(20) NOT NULL DEFAULT 'purchase',
  product_or_service VARCHAR(191) NOT NULL DEFAULT '',
  buying_probability INT NOT NULL DEFAULT 3,
  followup_date DATE NULL,
  call_count INT NOT NULL DEFAULT 0,
  last_call_result VARCHAR(255) NOT NULL DEFAULT '',
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY  (id),
  KEY phone (phone),
  KEY owner_user_id (owner_user_id),
  KEY team_id (team_id),
  KEY is_archived (is_archived),
  KEY followup_date (followup_date),
  KEY lifecycle_stage (lifecycle_stage)
) {$charsetCollate};",

            'contact_followups' => "CREATE TABLE {$prefix}avina_contact_followups (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  contact_id BIGINT UNSIGNED NOT NULL,
  followup_date DATE NOT NULL,
  notes TEXT NOT NULL,
  result VARCHAR(255) NOT NULL DEFAULT '',
  created_by_user_id BIGINT UNSIGNED NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY  (id),
  KEY contact_id (contact_id)
) {$charsetCollate};",

            'customers' => "CREATE TABLE {$prefix}avina_customers (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  contact_id BIGINT UNSIGNED NULL,
  full_name VARCHAR(191) NOT NULL,
  phone VARCHAR(32) NOT NULL DEFAULT '',
  email VARCHAR(191) NOT NULL DEFAULT '',
  status VARCHAR(30) NOT NULL DEFAULT 'active',
  owner_user_id BIGINT UNSIGNED NULL,
  team_id BIGINT UNSIGNED NULL,
  is_archived TINYINT(1) NOT NULL DEFAULT 0,
  created_by_user_id BIGINT UNSIGNED NULL,
  custom_fields LONGTEXT NULL,
  conversion_date DATE NULL,
  purchased_products VARCHAR(500) NOT NULL DEFAULT '',
  notes TEXT NULL,
  purchase_count INT NOT NULL DEFAULT 1,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY  (id),
  KEY contact_id (contact_id),
  KEY phone (phone),
  KEY owner_user_id (owner_user_id),
  KEY team_id (team_id),
  KEY is_archived (is_archived)
) {$charsetCollate};",

            'kanban_tasks' => "CREATE TABLE {$prefix}avina_kanban_tasks (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  title VARCHAR(191) NOT NULL,
  description TEXT NULL,
  stage_id VARCHAR(50) NOT NULL DEFAULT 'lead',
  assignee_user_id BIGINT UNSIGNED NULL,
  contact_id BIGINT UNSIGNED NULL,
  color_tag VARCHAR(20) NOT NULL DEFAULT '#6366f1',
  color_glow VARCHAR(50) NOT NULL DEFAULT 'rgba(99, 102, 241, 0.12)',
  created_by_user_id BIGINT UNSIGNED NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY  (id),
  KEY stage_id (stage_id),
  KEY assignee_user_id (assignee_user_id),
  KEY contact_id (contact_id)
) {$charsetCollate};",

            'kanban_task_logs' => "CREATE TABLE {$prefix}avina_kanban_task_logs (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  task_id BIGINT UNSIGNED NOT NULL,
  action VARCHAR(100) NOT NULL,
  details TEXT NULL,
  created_by_user_id BIGINT UNSIGNED NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY  (id),
  KEY task_id (task_id)
) {$charsetCollate};",

            'device_intakes' => "CREATE TABLE {$prefix}avina_device_intakes (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  customer_name VARCHAR(191) NOT NULL,
  device_model VARCHAR(191) NOT NULL,
  intake_date DATE NOT NULL,
  issue TEXT NOT NULL,
  accessories TEXT NULL,
  status VARCHAR(30) NOT NULL DEFAULT 'pending',
  created_by_user_id BIGINT UNSIGNED NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY  (id)
) {$charsetCollate};",

            'messages_log' => "CREATE TABLE {$prefix}avina_messages_log (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  recipient_phone VARCHAR(32) NOT NULL,
  message_text TEXT NOT NULL,
  channel VARCHAR(20) NOT NULL DEFAULT 'sms',
  status VARCHAR(20) NOT NULL DEFAULT 'sent',
  created_by_user_id BIGINT UNSIGNED NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY  (id)
) {$charsetCollate};",

            'products' => "CREATE TABLE {$prefix}avina_products (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  name VARCHAR(191) NOT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY  (id)
) {$charsetCollate};",

            'services' => "CREATE TABLE {$prefix}avina_services (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  name VARCHAR(191) NOT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY  (id)
) {$charsetCollate};",

            'customer_notes' => "CREATE TABLE {$prefix}avina_customer_notes (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  customer_id BIGINT UNSIGNED NOT NULL,
  body TEXT NOT NULL,
  created_by_user_id BIGINT UNSIGNED NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY  (id),
  KEY customer_id (customer_id)
) {$charsetCollate};",

            'receptions' => "CREATE TABLE {$prefix}avina_receptions (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  visitor_name VARCHAR(191) NOT NULL,
  visitor_phone VARCHAR(32) NOT NULL DEFAULT '',
  host_user_id BIGINT UNSIGNED NULL,
  purpose VARCHAR(255) NOT NULL DEFAULT '',
  status VARCHAR(20) NOT NULL DEFAULT 'checked_in',
  custom_fields LONGTEXT NULL,
  checked_in_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  checked_out_at DATETIME NULL,
  created_by_user_id BIGINT UNSIGNED NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY  (id),
  KEY host_user_id (host_user_id),
  KEY status (status)
) {$charsetCollate};",

            'reception_status_history' => "CREATE TABLE {$prefix}avina_reception_status_history (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  reception_id BIGINT UNSIGNED NOT NULL,
  from_status VARCHAR(20) NOT NULL DEFAULT '',
  to_status VARCHAR(20) NOT NULL,
  changed_by_user_id BIGINT UNSIGNED NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY  (id),
  KEY reception_id (reception_id)
) {$charsetCollate};",

            'activities' => "CREATE TABLE {$prefix}avina_activities (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  kind VARCHAR(20) NOT NULL DEFAULT 'note',
  subject VARCHAR(191) NOT NULL DEFAULT '',
  body TEXT NULL,
  related_type VARCHAR(30) NOT NULL DEFAULT '',
  related_id BIGINT UNSIGNED NULL,
  next_action_at DATETIME NULL,
  completed_at DATETIME NULL,
  owner_user_id BIGINT UNSIGNED NULL,
  team_id BIGINT UNSIGNED NULL,
  is_archived TINYINT(1) NOT NULL DEFAULT 0,
  created_by_user_id BIGINT UNSIGNED NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY  (id),
  KEY related (related_type, related_id),
  KEY owner_user_id (owner_user_id),
  KEY team_id (team_id)
) {$charsetCollate};",

            'tasks' => "CREATE TABLE {$prefix}avina_tasks (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  title VARCHAR(191) NOT NULL,
  description TEXT NULL,
  priority VARCHAR(10) NOT NULL DEFAULT 'normal',
  status VARCHAR(20) NOT NULL DEFAULT 'open',
  due_at DATETIME NULL,
  assignee_user_id BIGINT UNSIGNED NULL,
  team_id BIGINT UNSIGNED NULL,
  is_archived TINYINT(1) NOT NULL DEFAULT 0,
  created_by_user_id BIGINT UNSIGNED NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY  (id),
  KEY assignee_user_id (assignee_user_id),
  KEY team_id (team_id),
  KEY status (status)
) {$charsetCollate};",

            'reminders' => "CREATE TABLE {$prefix}avina_reminders (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  title VARCHAR(191) NOT NULL,
  related_type VARCHAR(30) NOT NULL DEFAULT '',
  related_id BIGINT UNSIGNED NULL,
  remind_at DATETIME NOT NULL,
  is_done TINYINT(1) NOT NULL DEFAULT 0,
  owner_user_id BIGINT UNSIGNED NULL,
  created_by_user_id BIGINT UNSIGNED NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY  (id),
  KEY owner_user_id (owner_user_id),
  KEY remind_at (remind_at)
) {$charsetCollate};",

            'notifications' => "CREATE TABLE {$prefix}avina_notifications (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  user_id BIGINT UNSIGNED NOT NULL,
  type VARCHAR(50) NOT NULL DEFAULT 'general',
  title VARCHAR(191) NOT NULL,
  body TEXT NULL,
  related_type VARCHAR(30) NOT NULL DEFAULT '',
  related_id BIGINT UNSIGNED NULL,
  is_read TINYINT(1) NOT NULL DEFAULT 0,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY  (id),
  KEY user_id (user_id),
  KEY is_read (is_read)
) {$charsetCollate};",

            'tickets' => "CREATE TABLE {$prefix}avina_tickets (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  subject VARCHAR(191) NOT NULL,
  body TEXT NOT NULL,
  sender_user_id BIGINT UNSIGNED NOT NULL,
  recipient_user_id BIGINT UNSIGNED NULL,
  team_id BIGINT UNSIGNED NULL,
  priority VARCHAR(10) NOT NULL DEFAULT 'normal',
  status VARCHAR(20) NOT NULL DEFAULT 'open',
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY  (id),
  KEY sender_user_id (sender_user_id),
  KEY recipient_user_id (recipient_user_id),
  KEY team_id (team_id),
  KEY status (status)
) {$charsetCollate};",

            'ticket_replies' => "CREATE TABLE {$prefix}avina_ticket_replies (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  ticket_id BIGINT UNSIGNED NOT NULL,
  author_user_id BIGINT UNSIGNED NOT NULL,
  body TEXT NOT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY  (id),
  KEY ticket_id (ticket_id)
) {$charsetCollate};",

            'ticket_participant_state' => "CREATE TABLE {$prefix}avina_ticket_participant_state (
  ticket_id BIGINT UNSIGNED NOT NULL,
  user_id BIGINT UNSIGNED NOT NULL,
  last_read_at DATETIME NULL,
  PRIMARY KEY  (ticket_id, user_id)
) {$charsetCollate};",
        ];
    }

    /**
     * Stage 4 tables: pipelines/stages, deals, kanban stage-history,
     * invoices/items, payments. Same conventions throughout: WordPress
     * prefix, no FOREIGN KEY constraints, soft-delete/archive columns.
     * All monetary columns are DECIMAL, never FLOAT, so server-side
     * total/discount/tax arithmetic in the Service layer is exact.
     */
    public static function salesDefinitions(string $prefix, string $charsetCollate): array
    {
        return [
            'pipelines' => "CREATE TABLE {$prefix}avina_pipelines (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  name VARCHAR(191) NOT NULL,
  is_archived TINYINT(1) NOT NULL DEFAULT 0,
  created_by_user_id BIGINT UNSIGNED NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY  (id),
  KEY is_archived (is_archived)
) {$charsetCollate};",

            'pipeline_stages' => "CREATE TABLE {$prefix}avina_pipeline_stages (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  pipeline_id BIGINT UNSIGNED NOT NULL,
  name VARCHAR(191) NOT NULL,
  sort_order INT UNSIGNED NOT NULL DEFAULT 0,
  win_probability TINYINT UNSIGNED NOT NULL DEFAULT 0,
  color VARCHAR(20) NOT NULL DEFAULT '#94a3b8',
  is_won TINYINT(1) NOT NULL DEFAULT 0,
  is_lost TINYINT(1) NOT NULL DEFAULT 0,
  is_archived TINYINT(1) NOT NULL DEFAULT 0,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY  (id),
  KEY pipeline_id (pipeline_id),
  KEY is_archived (is_archived)
) {$charsetCollate};",

            'deals' => "CREATE TABLE {$prefix}avina_deals (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  title VARCHAR(191) NOT NULL,
  pipeline_id BIGINT UNSIGNED NOT NULL,
  stage_id BIGINT UNSIGNED NOT NULL,
  contact_id BIGINT UNSIGNED NULL,
  customer_id BIGINT UNSIGNED NULL,
  value DECIMAL(18,2) NOT NULL DEFAULT 0.00,
  currency VARCHAR(10) NOT NULL DEFAULT 'IRR',
  expected_close_date DATE NULL,
  status VARCHAR(10) NOT NULL DEFAULT 'open',
  lost_reason VARCHAR(255) NOT NULL DEFAULT '',
  owner_user_id BIGINT UNSIGNED NULL,
  team_id BIGINT UNSIGNED NULL,
  is_archived TINYINT(1) NOT NULL DEFAULT 0,
  created_by_user_id BIGINT UNSIGNED NULL,
  custom_fields LONGTEXT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY  (id),
  KEY pipeline_id (pipeline_id),
  KEY stage_id (stage_id),
  KEY owner_user_id (owner_user_id),
  KEY team_id (team_id),
  KEY status (status),
  KEY is_archived (is_archived)
) {$charsetCollate};",

            'deal_stage_history' => "CREATE TABLE {$prefix}avina_deal_stage_history (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  deal_id BIGINT UNSIGNED NOT NULL,
  from_stage_id BIGINT UNSIGNED NULL,
  to_stage_id BIGINT UNSIGNED NOT NULL,
  changed_by_user_id BIGINT UNSIGNED NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY  (id),
  KEY deal_id (deal_id)
) {$charsetCollate};",

            'invoices' => "CREATE TABLE {$prefix}avina_invoices (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  type VARCHAR(10) NOT NULL DEFAULT 'invoice',
  number VARCHAR(50) NOT NULL DEFAULT '',
  contact_id BIGINT UNSIGNED NULL,
  customer_id BIGINT UNSIGNED NULL,
  status VARCHAR(20) NOT NULL DEFAULT 'draft',
  subtotal DECIMAL(18,2) NOT NULL DEFAULT 0.00,
  discount_total DECIMAL(18,2) NOT NULL DEFAULT 0.00,
  tax_total DECIMAL(18,2) NOT NULL DEFAULT 0.00,
  total DECIMAL(18,2) NOT NULL DEFAULT 0.00,
  paid_total DECIMAL(18,2) NOT NULL DEFAULT 0.00,
  currency VARCHAR(10) NOT NULL DEFAULT 'IRR',
  issue_date DATE NULL,
  due_date DATE NULL,
  owner_user_id BIGINT UNSIGNED NULL,
  team_id BIGINT UNSIGNED NULL,
  is_archived TINYINT(1) NOT NULL DEFAULT 0,
  created_by_user_id BIGINT UNSIGNED NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY  (id),
  UNIQUE KEY number (number),
  KEY contact_id (contact_id),
  KEY customer_id (customer_id),
  KEY owner_user_id (owner_user_id),
  KEY team_id (team_id),
  KEY status (status),
  KEY is_archived (is_archived)
) {$charsetCollate};",

            'invoice_items' => "CREATE TABLE {$prefix}avina_invoice_items (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  invoice_id BIGINT UNSIGNED NOT NULL,
  description VARCHAR(255) NOT NULL,
  quantity DECIMAL(12,3) NOT NULL DEFAULT 1.000,
  unit_price DECIMAL(18,2) NOT NULL DEFAULT 0.00,
  discount_percent DECIMAL(5,2) NOT NULL DEFAULT 0.00,
  tax_percent DECIMAL(5,2) NOT NULL DEFAULT 0.00,
  line_total DECIMAL(18,2) NOT NULL DEFAULT 0.00,
  sort_order INT UNSIGNED NOT NULL DEFAULT 0,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY  (id),
  KEY invoice_id (invoice_id)
) {$charsetCollate};",

            'payments' => "CREATE TABLE {$prefix}avina_payments (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  invoice_id BIGINT UNSIGNED NOT NULL,
  amount DECIMAL(18,2) NOT NULL DEFAULT 0.00,
  method VARCHAR(30) NOT NULL DEFAULT 'manual',
  reference VARCHAR(100) NOT NULL DEFAULT '',
  paid_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  recorded_by_user_id BIGINT UNSIGNED NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY  (id),
  KEY invoice_id (invoice_id)
) {$charsetCollate};",
        ];
    }

    /**
     * Stage 5 tables: webhook endpoint registry + dispatch attempt log.
     * The webhook `secret` column is written but NEVER selected back out
     * through any REST response (see WebhookService::decorate(), which
     * strips it) — it exists in the database only for HMAC signing at
     * dispatch time.
     */
    public static function integrationDefinitions(string $prefix, string $charsetCollate): array
    {
        return [
            'webhooks' => "CREATE TABLE {$prefix}avina_webhooks (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  name VARCHAR(191) NOT NULL,
  target_url VARCHAR(500) NOT NULL,
  secret VARCHAR(64) NOT NULL,
  event_types VARCHAR(500) NOT NULL DEFAULT '',
  is_active TINYINT(1) NOT NULL DEFAULT 1,
  is_archived TINYINT(1) NOT NULL DEFAULT 0,
  created_by_user_id BIGINT UNSIGNED NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY  (id),
  KEY is_active (is_active),
  KEY is_archived (is_archived)
) {$charsetCollate};",

            'webhook_logs' => "CREATE TABLE {$prefix}avina_webhook_logs (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  webhook_id BIGINT UNSIGNED NOT NULL,
  event_type VARCHAR(100) NOT NULL,
  payload_summary VARCHAR(500) NOT NULL DEFAULT '',
  response_status SMALLINT NULL,
  attempt_count TINYINT UNSIGNED NOT NULL DEFAULT 1,
  success TINYINT(1) NOT NULL DEFAULT 0,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY  (id),
  KEY webhook_id (webhook_id),
  KEY event_type (event_type),
  KEY success (success)
) {$charsetCollate};",
        ];
    }
}
