<?php

declare(strict_types=1);

namespace AvinaCRM\Invoices;

use AvinaCRM\Audit\AuditLogger;
use AvinaCRM\Support\Scope;
use WP_Error;

final class InvoiceService
{
    public const TYPES = ['quote', 'invoice'];
    public const STATUSES = ['draft', 'sent', 'accepted', 'partially_paid', 'paid', 'void'];

    private AuditLogger $audit;

    public function __construct(?AuditLogger $audit = null)
    {
        $this->audit = $audit ?? new AuditLogger();
    }

    public function list(array $filters): array
    {
        global $wpdb;
        $table = $wpdb->prefix . 'avina_invoices';

        $where = ['is_archived = 0'];

        $visibility = Scope::visibilityClause('invoices.invoice.view', ['owner_user_id', 'created_by_user_id'], 'team_id');
        if ($visibility !== '') {
            $where[] = $visibility;
        }

        if (!empty($filters['status']) && in_array($filters['status'], self::STATUSES, true)) {
            $where[] = $wpdb->prepare('status = %s', $filters['status']);
        }

        if (!empty($filters['type']) && in_array($filters['type'], self::TYPES, true)) {
            $where[] = $wpdb->prepare('type = %s', $filters['type']);
        }

        $whereSql = implode(' AND ', $where);

        $rows = $wpdb->get_results(
            "SELECT * FROM {$table} WHERE {$whereSql} ORDER BY created_at DESC LIMIT 300",
            ARRAY_A
        );

        return array_map([$this, 'decorate'], $rows ?: []);
    }

    public function find(int $id): ?array
    {
        $row = $this->rawFind($id);

        if ($row === null || !$this->canView($row)) {
            return null;
        }

        $row = $this->decorate($row);
        $row['items'] = $this->itemsFor($id);
        $row['payments'] = $this->paymentsFor($id);
        $row['balance_due'] = round($row['total'] - $row['paid_total'], 2);

        return $row;
    }

    /**
     * Creates an invoice/quote with its line items in one transaction-like
     * operation. Every monetary figure (subtotal, discount_total,
     * tax_total, total, and each item's line_total) is computed here from
     * quantity/unit_price/discount_percent/tax_percent — a client-sent
     * total is never trusted or stored as-is.
     *
     * @param array<int, array{description: string, quantity: mixed, unit_price: mixed, discount_percent?: mixed, tax_percent?: mixed}> $items
     * @return array{id: int}|WP_Error
     */
    public function create(array $data, array $items, int $actorUserId)
    {
        $type = in_array($data['type'] ?? '', self::TYPES, true) ? $data['type'] : 'invoice';

        if (empty($items)) {
            return new WP_Error('avina_crm_invalid_invoice', __('حداقل یک قلم کالا/خدمت الزامی است.', 'avina-crm'), ['status' => 400]);
        }

        $ownerUserId = !empty($data['owner_user_id']) ? (int) $data['owner_user_id'] : $actorUserId;
        if (get_user_by('id', $ownerUserId) === false) {
            return new WP_Error('avina_crm_invalid_owner', __('کاربر مسئول معتبر نیست.', 'avina-crm'), ['status' => 400]);
        }

        $computedItems = [];

        foreach ($items as $item) {
            $computed = $this->computeLineItem($item);

            if ($computed instanceof WP_Error) {
                return $computed;
            }

            $computedItems[] = $computed;
        }

        $totals = $this->sumTotals($computedItems);

        global $wpdb;
        $table = $wpdb->prefix . 'avina_invoices';

        $number = $this->generateNumber($type);

        $wpdb->insert(
            $table,
            [
                'type' => $type,
                'number' => $number,
                'contact_id' => !empty($data['contact_id']) ? (int) $data['contact_id'] : null,
                'customer_id' => !empty($data['customer_id']) ? (int) $data['customer_id'] : null,
                'status' => 'draft',
                'subtotal' => $totals['subtotal'],
                'discount_total' => $totals['discount_total'],
                'tax_total' => $totals['tax_total'],
                'total' => $totals['total'],
                'paid_total' => 0.00,
                'currency' => $this->sanitizeCurrency($data['currency'] ?? 'IRR'),
                'issue_date' => !empty($data['issue_date']) ? $this->normalizeDate($data['issue_date']) : gmdate('Y-m-d'),
                'due_date' => !empty($data['due_date']) ? $this->normalizeDate($data['due_date']) : null,
                'owner_user_id' => $ownerUserId,
                'team_id' => !empty($data['team_id']) ? (int) $data['team_id'] : null,
                'is_archived' => 0,
                'created_by_user_id' => $actorUserId,
                'created_at' => current_time('mysql'),
                'updated_at' => current_time('mysql'),
            ],
            ['%s', '%s', '%d', '%d', '%s', '%f', '%f', '%f', '%f', '%f', '%s', '%s', '%s', '%d', '%d', '%d', '%d', '%s', '%s']
        );

        $invoiceId = (int) $wpdb->insert_id;

        $this->insertItems($invoiceId, $computedItems);

        $this->audit->record($actorUserId, 'invoices.invoice.create', 'invoice', (string) $invoiceId, null, ['number' => $number, 'total' => $totals['total']]);

        return ['id' => $invoiceId, 'number' => $number];
    }

    /**
     * Replaces a draft invoice's line items and recomputes all totals
     * server-side. Restricted to status = 'draft' only — once an invoice
     * has been sent, accepted, or has any payment recorded, its items are
     * immutable, since changing a sent invoice's numbers after the fact
     * would silently invalidate whatever the recipient already saw.
     * Deleting-and-reinserting a still-unpublished draft's own child
     * line-item rows is not the "no hard delete of CRM data" concern
     * that governs top-level records — those items were never a
     * finalized business record to begin with.
     *
     * @param array<int, array{description: string, quantity: mixed, unit_price: mixed, discount_percent?: mixed, tax_percent?: mixed}> $items
     * @return true|WP_Error
     */
    public function updateItems(int $invoiceId, array $items, int $actorUserId)
    {
        $invoice = $this->rawFind($invoiceId);

        if ($invoice === null) {
            return new WP_Error('avina_crm_invoice_not_found', __('فاکتور موردنظر یافت نشد.', 'avina-crm'), ['status' => 404]);
        }

        if (!$this->canView($invoice)) {
            return new WP_Error('avina_crm_forbidden', __('شما اجازه ویرایش این فاکتور را ندارید.', 'avina-crm'), ['status' => 403]);
        }

        if ($invoice['status'] !== 'draft') {
            return new WP_Error(
                'avina_crm_invoice_not_editable',
                __('فقط فاکتورهای پیش‌نویس قابل ویرایش اقلام هستند.', 'avina-crm'),
                ['status' => 400]
            );
        }

        if (empty($items)) {
            return new WP_Error('avina_crm_invalid_invoice', __('حداقل یک قلم کالا/خدمت الزامی است.', 'avina-crm'), ['status' => 400]);
        }

        $computedItems = [];
        foreach ($items as $item) {
            $computed = $this->computeLineItem($item);
            if ($computed instanceof WP_Error) {
                return $computed;
            }
            $computedItems[] = $computed;
        }

        $totals = $this->sumTotals($computedItems);

        global $wpdb;
        $itemsTable = $wpdb->prefix . 'avina_invoice_items';

        $wpdb->delete($itemsTable, ['invoice_id' => $invoiceId], ['%d']);
        $this->insertItems($invoiceId, $computedItems);

        $wpdb->update(
            $wpdb->prefix . 'avina_invoices',
            [
                'subtotal' => $totals['subtotal'],
                'discount_total' => $totals['discount_total'],
                'tax_total' => $totals['tax_total'],
                'total' => $totals['total'],
                'updated_at' => current_time('mysql'),
            ],
            ['id' => $invoiceId],
            ['%f', '%f', '%f', '%f', '%s'],
            ['%d']
        );

        $this->audit->record($actorUserId, 'invoices.invoice.items_update', 'invoice', (string) $invoiceId, ['total' => $invoice['total']], ['total' => $totals['total']]);

        return true;
    }

    /**
     * @return true|WP_Error
     */
    public function changeStatus(int $id, string $status, int $actorUserId)
    {
        if (!in_array($status, self::STATUSES, true)) {
            return new WP_Error('avina_crm_invalid_status', __('وضعیت انتخاب‌شده معتبر نیست.', 'avina-crm'), ['status' => 400]);
        }

        $existing = $this->rawFind($id);

        if ($existing === null) {
            return new WP_Error('avina_crm_invoice_not_found', __('فاکتور موردنظر یافت نشد.', 'avina-crm'), ['status' => 404]);
        }

        if (!$this->canView($existing)) {
            return new WP_Error('avina_crm_forbidden', __('شما اجازه تغییر وضعیت این فاکتور را ندارید.', 'avina-crm'), ['status' => 403]);
        }

        // paid / partially_paid are DERIVED statuses maintained only by
        // PaymentService as payments are recorded — a direct status write
        // to either of those two values here would let someone mark an
        // unpaid invoice as paid without ever recording the money, so
        // that transition is refused on this path specifically.
        if (in_array($status, ['paid', 'partially_paid'], true)) {
            return new WP_Error(
                'avina_crm_invalid_status_transition',
                __('وضعیت پرداخت‌شده یا نیمه‌پرداخت‌شده فقط از طریق ثبت پرداخت به‌روزرسانی می‌شود.', 'avina-crm'),
                ['status' => 400]
            );
        }

        global $wpdb;
        $wpdb->update(
            $wpdb->prefix . 'avina_invoices',
            ['status' => $status, 'updated_at' => current_time('mysql')],
            ['id' => $id],
            ['%s', '%s'],
            ['%d']
        );

        $this->audit->record($actorUserId, 'invoices.invoice.status_change', 'invoice', (string) $id, ['status' => $existing['status']], ['status' => $status]);

        return true;
    }

    /**
     * Recomputes and persists paid_total + the derived paid/partially_paid
     * status for an invoice. Called by PaymentService after every payment
     * is recorded — this is the ONLY place that ever writes paid/
     * partially_paid, keeping the derivation in one place.
     */
    public function syncPaymentState(int $invoiceId, int $actorUserId): void
    {
        global $wpdb;

        $paymentsTable = $wpdb->prefix . 'avina_payments';
        $invoicesTable = $wpdb->prefix . 'avina_invoices';

        $paidTotal = (float) $wpdb->get_var(
            $wpdb->prepare("SELECT COALESCE(SUM(amount), 0) FROM {$paymentsTable} WHERE invoice_id = %d", $invoiceId)
        );

        $invoice = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$invoicesTable} WHERE id = %d", $invoiceId), ARRAY_A);

        if ($invoice === null) {
            return;
        }

        $total = (float) $invoice['total'];
        $newStatus = $invoice['status'];

        if ($invoice['status'] !== 'void') {
            if ($paidTotal >= $total && $total > 0) {
                $newStatus = 'paid';
            } elseif ($paidTotal > 0) {
                $newStatus = 'partially_paid';
            }
        }

        $wpdb->update(
            $invoicesTable,
            ['paid_total' => round($paidTotal, 2), 'status' => $newStatus, 'updated_at' => current_time('mysql')],
            ['id' => $invoiceId],
            ['%f', '%s', '%s'],
            ['%d']
        );

        $this->audit->record($actorUserId, 'invoices.invoice.payment_sync', 'invoice', (string) $invoiceId, ['status' => $invoice['status']], ['paid_total' => $paidTotal, 'status' => $newStatus]);

        if ($newStatus === 'paid' && $invoice['status'] !== 'paid') {
            do_action('avina_crm/invoice_paid', $invoiceId);
        }
    }

    /**
     * @param array{description: string, quantity: mixed, unit_price: mixed, discount_percent?: mixed, tax_percent?: mixed} $item
     * @return array{description: string, quantity: float, unit_price: float, discount_percent: float, tax_percent: float, line_total: float}|WP_Error
     */
    private function computeLineItem(array $item)
    {
        $description = sanitize_text_field($item['description'] ?? '');

        if ($description === '') {
            return new WP_Error('avina_crm_invalid_item', __('شرح هر قلم الزامی است.', 'avina-crm'), ['status' => 400]);
        }

        $quantity = (float) ($item['quantity'] ?? 0);
        $unitPrice = (float) ($item['unit_price'] ?? 0);
        $discountPercent = max(0, min(100, (float) ($item['discount_percent'] ?? 0)));
        $taxPercent = max(0, min(100, (float) ($item['tax_percent'] ?? 0)));

        if ($quantity <= 0 || $unitPrice < 0) {
            return new WP_Error('avina_crm_invalid_item', __('تعداد و قیمت واحد باید معتبر باشند.', 'avina-crm'), ['status' => 400]);
        }

        $lineSubtotal = $quantity * $unitPrice;
        $discountAmount = $lineSubtotal * ($discountPercent / 100);
        $taxable = $lineSubtotal - $discountAmount;
        $taxAmount = $taxable * ($taxPercent / 100);
        $lineTotal = round($taxable + $taxAmount, 2);

        return [
            'description' => $description,
            'quantity' => round($quantity, 3),
            'unit_price' => round($unitPrice, 2),
            'discount_percent' => round($discountPercent, 2),
            'tax_percent' => round($taxPercent, 2),
            'line_subtotal' => round($lineSubtotal, 2),
            'discount_amount' => round($discountAmount, 2),
            'tax_amount' => round($taxAmount, 2),
            'line_total' => $lineTotal,
        ];
    }

    /**
     * @param array<int, array<string, mixed>> $computedItems
     * @return array{subtotal: float, discount_total: float, tax_total: float, total: float}
     */
    private function sumTotals(array $computedItems): array
    {
        $subtotal = array_sum(array_column($computedItems, 'line_subtotal'));
        $discountTotal = array_sum(array_column($computedItems, 'discount_amount'));
        $taxTotal = array_sum(array_column($computedItems, 'tax_amount'));
        $total = array_sum(array_column($computedItems, 'line_total'));

        return [
            'subtotal' => round($subtotal, 2),
            'discount_total' => round($discountTotal, 2),
            'tax_total' => round($taxTotal, 2),
            'total' => round($total, 2),
        ];
    }

    private function insertItems(int $invoiceId, array $computedItems): void
    {
        global $wpdb;
        $table = $wpdb->prefix . 'avina_invoice_items';

        foreach (array_values($computedItems) as $index => $item) {
            $wpdb->insert(
                $table,
                [
                    'invoice_id' => $invoiceId,
                    'description' => $item['description'],
                    'quantity' => $item['quantity'],
                    'unit_price' => $item['unit_price'],
                    'discount_percent' => $item['discount_percent'],
                    'tax_percent' => $item['tax_percent'],
                    'line_total' => $item['line_total'],
                    'sort_order' => $index,
                    'created_at' => current_time('mysql'),
                ],
                ['%d', '%s', '%f', '%f', '%f', '%f', '%f', '%d', '%s']
            );
        }
    }

    private function itemsFor(int $invoiceId): array
    {
        global $wpdb;
        $table = $wpdb->prefix . 'avina_invoice_items';

        $rows = $wpdb->get_results(
            $wpdb->prepare("SELECT * FROM {$table} WHERE invoice_id = %d ORDER BY sort_order ASC", $invoiceId),
            ARRAY_A
        );

        return $rows ?: [];
    }

    private function paymentsFor(int $invoiceId): array
    {
        global $wpdb;
        $table = $wpdb->prefix . 'avina_payments';

        $rows = $wpdb->get_results(
            $wpdb->prepare("SELECT * FROM {$table} WHERE invoice_id = %d ORDER BY paid_at DESC", $invoiceId),
            ARRAY_A
        );

        return $rows ?: [];
    }

    private function generateNumber(string $type): string
    {
        global $wpdb;
        $table = $wpdb->prefix . 'avina_invoices';

        $prefix = $type === 'quote' ? 'Q' : 'INV';
        $count = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$table} WHERE type = %s", $type)) + 1;

        return sprintf('%s-%s-%04d', $prefix, gmdate('Y'), $count);
    }

    private function canView(array $row): bool
    {
        if (current_user_can('manage_options') || current_user_can('users-roles.user.view')) {
            return true;
        }

        $userId = get_current_user_id();

        if ((int) ($row['owner_user_id'] ?? 0) === $userId || (int) ($row['created_by_user_id'] ?? 0) === $userId) {
            return true;
        }

        if (!empty($row['team_id']) && Scope::isTeamMember($userId, (int) $row['team_id'])) {
            return true;
        }

        return false;
    }

    public function rawFind(int $id): ?array
    {
        global $wpdb;
        $table = $wpdb->prefix . 'avina_invoices';

        $row = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table} WHERE id = %d AND is_archived = 0", $id), ARRAY_A);

        return $row ?: null;
    }

    private function sanitizeCurrency(string $currency): string
    {
        $currency = strtoupper(sanitize_text_field($currency));

        return preg_match('/^[A-Z]{3}$/', $currency) ? $currency : 'IRR';
    }

    private function normalizeDate(string $value): string
    {
        $timestamp = strtotime($value);

        return $timestamp !== false ? gmdate('Y-m-d', $timestamp) : gmdate('Y-m-d');
    }

    private function decorate(array $row): array
    {
        $row['id'] = (int) $row['id'];
        $row['contact_id'] = $row['contact_id'] !== null ? (int) $row['contact_id'] : null;
        $row['customer_id'] = $row['customer_id'] !== null ? (int) $row['customer_id'] : null;
        $row['owner_user_id'] = $row['owner_user_id'] !== null ? (int) $row['owner_user_id'] : null;
        $row['team_id'] = $row['team_id'] !== null ? (int) $row['team_id'] : null;

        foreach (['subtotal', 'discount_total', 'tax_total', 'total', 'paid_total'] as $moneyField) {
            $row[$moneyField] = (float) $row[$moneyField];
        }

        $row['is_archived'] = (bool) $row['is_archived'];

        return $row;
    }
}
