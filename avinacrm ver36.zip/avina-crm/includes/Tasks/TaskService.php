<?php

declare(strict_types=1);

namespace AvinaCRM\Tasks;

use AvinaCRM\Audit\AuditLogger;
use AvinaCRM\Support\Scope;
use WP_Error;

final class TaskService
{
    public const PRIORITIES = ['low', 'normal', 'high', 'urgent'];
    public const STATUSES = ['open', 'in_progress', 'done', 'cancelled'];

    private AuditLogger $audit;

    public function __construct(?AuditLogger $audit = null)
    {
        $this->audit = $audit ?? new AuditLogger();
    }

    public function list(array $filters): array
    {
        global $wpdb;
        $table = $wpdb->prefix . 'avina_tasks';

        $where = ['is_archived = 0'];

        $visibility = Scope::visibilityClause('tasks.task.view', ['assignee_user_id', 'created_by_user_id'], 'team_id');
        if ($visibility !== '') {
            $where[] = $visibility;
        }

        if (!empty($filters['status']) && in_array($filters['status'], self::STATUSES, true)) {
            $where[] = $wpdb->prepare('status = %s', $filters['status']);
        }

        if (!empty($filters['priority']) && in_array($filters['priority'], self::PRIORITIES, true)) {
            $where[] = $wpdb->prepare('priority = %s', $filters['priority']);
        }

        $whereSql = implode(' AND ', $where);

        $rows = $wpdb->get_results(
            "SELECT * FROM {$table} WHERE {$whereSql} ORDER BY FIELD(priority,'urgent','high','normal','low'), COALESCE(due_at, '9999-12-31') ASC LIMIT 200",
            ARRAY_A
        );

        return array_map([$this, 'decorate'], $rows ?: []);
    }

    /**
     * @return array{id: int}|WP_Error
     */
    public function create(array $data, int $actorUserId)
    {
        $title = sanitize_text_field($data['title'] ?? '');

        if ($title === '') {
            return new WP_Error('avina_crm_invalid_task', __('عنوان وظیفه الزامی است.', 'avina-crm'), ['status' => 400]);
        }

        $assigneeUserId = !empty($data['assignee_user_id']) ? (int) $data['assignee_user_id'] : $actorUserId;

        // Cross-user assignment gate: assigning a task to someone OTHER
        // than yourself requires tasks.task.assign — otherwise a user
        // with only tasks.task.create could pile work onto colleagues
        // without authorization to do so.
        if ($assigneeUserId !== $actorUserId && !current_user_can('tasks.task.assign')) {
            return new WP_Error('avina_crm_forbidden', __('شما اجازه واگذاری وظیفه به دیگران را ندارید.', 'avina-crm'), ['status' => 403]);
        }

        if (get_user_by('id', $assigneeUserId) === false) {
            return new WP_Error('avina_crm_invalid_assignee', __('کاربر مسئول معتبر نیست.', 'avina-crm'), ['status' => 400]);
        }

        global $wpdb;
        $table = $wpdb->prefix . 'avina_tasks';

        $wpdb->insert(
            $table,
            [
                'title' => $title,
                'description' => sanitize_textarea_field($data['description'] ?? ''),
                'priority' => in_array($data['priority'] ?? '', self::PRIORITIES, true) ? $data['priority'] : 'normal',
                'status' => 'open',
                'due_at' => !empty($data['due_at']) ? $this->normalizeDatetime($data['due_at']) : null,
                'assignee_user_id' => $assigneeUserId,
                'team_id' => !empty($data['team_id']) ? (int) $data['team_id'] : null,
                'is_archived' => 0,
                'created_by_user_id' => $actorUserId,
                'created_at' => current_time('mysql'),
                'updated_at' => current_time('mysql'),
            ],
            ['%s', '%s', '%s', '%s', '%s', '%d', '%d', '%d', '%d', '%s', '%s']
        );

        $id = (int) $wpdb->insert_id;

        $this->audit->record($actorUserId, 'tasks.task.create', 'task', (string) $id, null, ['title' => $title, 'assignee_user_id' => $assigneeUserId]);

        return ['id' => $id];
    }

    /**
     * @return true|WP_Error
     */
    public function updateStatus(int $id, string $status, int $actorUserId)
    {
        if (!in_array($status, self::STATUSES, true)) {
            return new WP_Error('avina_crm_invalid_status', __('وضعیت انتخاب‌شده معتبر نیست.', 'avina-crm'), ['status' => 400]);
        }

        global $wpdb;
        $table = $wpdb->prefix . 'avina_tasks';

        $existing = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table} WHERE id = %d AND is_archived = 0", $id), ARRAY_A);

        if ($existing === null) {
            return new WP_Error('avina_crm_task_not_found', __('وظیفه موردنظر یافت نشد.', 'avina-crm'), ['status' => 404]);
        }

        if (!$this->canModify($existing)) {
            return new WP_Error('avina_crm_forbidden', __('شما اجازه تغییر این وظیفه را ندارید.', 'avina-crm'), ['status' => 403]);
        }

        $wpdb->update($table, ['status' => $status, 'updated_at' => current_time('mysql')], ['id' => $id], ['%s', '%s'], ['%d']);

        $action = $status === 'done' ? 'tasks.task.complete' : 'tasks.task.update';
        $this->audit->record($actorUserId, $action, 'task', (string) $id, ['status' => $existing['status']], ['status' => $status]);

        return true;
    }

    private function canModify(array $row): bool
    {
        if (current_user_can('manage_options') || current_user_can('tasks.task.assign')) {
            return true;
        }

        $userId = get_current_user_id();

        return (int) ($row['assignee_user_id'] ?? 0) === $userId || (int) ($row['created_by_user_id'] ?? 0) === $userId;
    }

    private function normalizeDatetime(string $value): string
    {
        $timestamp = strtotime($value);

        return $timestamp !== false ? gmdate('Y-m-d H:i:s', $timestamp) : current_time('mysql');
    }

    private function decorate(array $row): array
    {
        $row['id'] = (int) $row['id'];
        $row['assignee_user_id'] = $row['assignee_user_id'] !== null ? (int) $row['assignee_user_id'] : null;
        $row['team_id'] = $row['team_id'] !== null ? (int) $row['team_id'] : null;

        return $row;
    }
}
