<?php

declare(strict_types=1);

namespace AvinaCRM\Rest\Controllers;

use AvinaCRM\Rest\ApiResponse;
use AvinaCRM\Webhooks\WebhookService;
use WP_Error;
use WP_REST_Request;
use WP_REST_Response;

final class WebhooksController
{
    private WebhookService $service;

    public function __construct()
    {
        $this->service = new WebhookService();
    }

    public function list(WP_REST_Request $request): WP_REST_Response
    {
        return ApiResponse::success([
            'items' => $this->service->list(),
            'available_events' => WebhookService::EVENT_TYPES,
        ]);
    }

    public function viewPermissionCheck(): bool
    {
        return current_user_can('webhooks.webhook.view');
    }

    public function create(WP_REST_Request $request)
    {
        $params = $request->get_json_params() ?? [];
        $result = $this->service->create($params, get_current_user_id());

        return $result instanceof WP_Error ? ApiResponse::fromWpError($result) : ApiResponse::success($result, 201);
    }

    public function createPermissionCheck(): bool
    {
        return current_user_can('webhooks.webhook.create');
    }

    public function toggleActive(WP_REST_Request $request)
    {
        $params = $request->get_json_params() ?? [];
        $result = $this->service->toggleActive((int) $request->get_param('id'), !empty($params['is_active']), get_current_user_id());

        return $result instanceof WP_Error ? ApiResponse::fromWpError($result) : ApiResponse::success(['ok' => true]);
    }

    public function updatePermissionCheck(): bool
    {
        return current_user_can('webhooks.webhook.update');
    }

    public function delete(WP_REST_Request $request)
    {
        $result = $this->service->delete((int) $request->get_param('id'), get_current_user_id());

        return $result instanceof WP_Error ? ApiResponse::fromWpError($result) : ApiResponse::success(['ok' => true]);
    }

    public function deletePermissionCheck(): bool
    {
        return current_user_can('webhooks.webhook.delete');
    }

    public function logs(WP_REST_Request $request): WP_REST_Response
    {
        return ApiResponse::success($this->service->logsFor((int) $request->get_param('id')));
    }
}
