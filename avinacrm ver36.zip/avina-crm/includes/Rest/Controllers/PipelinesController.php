<?php

declare(strict_types=1);

namespace AvinaCRM\Rest\Controllers;

use AvinaCRM\Pipelines\PipelineService;
use AvinaCRM\Rest\ApiResponse;
use WP_Error;
use WP_REST_Request;
use WP_REST_Response;

final class PipelinesController
{
    private PipelineService $service;

    public function __construct()
    {
        $this->service = new PipelineService();
    }

    public function list(WP_REST_Request $request): WP_REST_Response
    {
        return ApiResponse::success($this->service->list());
    }

    public function viewPermissionCheck(): bool
    {
        return current_user_can('pipelines.pipeline.view');
    }

    public function create(WP_REST_Request $request)
    {
        $params = $request->get_json_params() ?? [];
        $result = $this->service->createPipeline((string) ($params['name'] ?? ''), get_current_user_id());

        return $result instanceof WP_Error ? ApiResponse::fromWpError($result) : ApiResponse::success($result, 201);
    }

    public function createPermissionCheck(): bool
    {
        return current_user_can('pipelines.pipeline.create');
    }

    public function addStage(WP_REST_Request $request)
    {
        $params = $request->get_json_params() ?? [];
        $result = $this->service->addStage((int) $request->get_param('id'), $params, get_current_user_id());

        return $result instanceof WP_Error ? ApiResponse::fromWpError($result) : ApiResponse::success($result, 201);
    }

    public function updatePermissionCheck(): bool
    {
        return current_user_can('pipelines.pipeline.update');
    }

    public function reorderStages(WP_REST_Request $request)
    {
        $params = $request->get_json_params() ?? [];
        $order = array_map('intval', (array) ($params['stage_ids'] ?? []));
        $result = $this->service->reorderStages((int) $request->get_param('id'), $order, get_current_user_id());

        return $result instanceof WP_Error ? ApiResponse::fromWpError($result) : ApiResponse::success(['ok' => true]);
    }
}
