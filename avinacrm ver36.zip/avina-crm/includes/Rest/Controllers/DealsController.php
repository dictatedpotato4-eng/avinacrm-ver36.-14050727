<?php

declare(strict_types=1);

namespace AvinaCRM\Rest\Controllers;

use AvinaCRM\Deals\DealService;
use AvinaCRM\Rest\ApiResponse;
use WP_Error;
use WP_REST_Request;
use WP_REST_Response;

final class DealsController
{
    private DealService $service;

    public function __construct()
    {
        $this->service = new DealService();
    }

    public function list(WP_REST_Request $request): WP_REST_Response
    {
        $filters = [
            'pipeline_id' => $request->get_param('pipeline_id'),
            'status' => (string) $request->get_param('status'),
        ];

        return ApiResponse::success($this->service->list($filters));
    }

    public function board(WP_REST_Request $request)
    {
        $pipelineId = (int) $request->get_param('pipeline_id');

        if ($pipelineId <= 0) {
            return ApiResponse::error('avina_crm_invalid_pipeline', __('شناسه پایپ‌لاین الزامی است.', 'avina-crm'), 400);
        }

        return ApiResponse::success($this->service->board($pipelineId));
    }

    public function viewPermissionCheck(): bool
    {
        return \AvinaCRM\Support\Scope::hasModulePermission('deals') || current_user_can('deals.deal.view');
    }

    public function get(WP_REST_Request $request)
    {
        $item = $this->service->find((int) $request->get_param('id'));

        if ($item === null) {
            return ApiResponse::error('avina_crm_deal_not_found', __('معامله موردنظر یافت نشد.', 'avina-crm'), 404);
        }

        return ApiResponse::success($item);
    }

    public function create(WP_REST_Request $request)
    {
        $params = $request->get_json_params() ?? [];
        $result = $this->service->create($params, get_current_user_id());

        return $result instanceof WP_Error ? ApiResponse::fromWpError($result) : ApiResponse::success($result, 201);
    }

    public function createPermissionCheck(): bool
    {
        return \AvinaCRM\Support\Scope::hasModulePermission('deals') || current_user_can('deals.deal.create');
    }

    public function update(WP_REST_Request $request)
    {
        $params = $request->get_json_params() ?? [];
        $result = $this->service->update((int) $request->get_param('id'), $params, get_current_user_id());

        return $result instanceof WP_Error ? ApiResponse::fromWpError($result) : ApiResponse::success(['ok' => true]);
    }

    public function updatePermissionCheck(): bool
    {
        return \AvinaCRM\Support\Scope::hasModulePermission('deals') || current_user_can('deals.deal.update');
    }

    public function changeStage(WP_REST_Request $request)
    {
        $params = $request->get_json_params() ?? [];
        $result = $this->service->changeStage(
            (int) $request->get_param('id'),
            (int) ($params['stage_id'] ?? 0),
            get_current_user_id(),
            (string) ($params['lost_reason'] ?? '')
        );

        return $result instanceof WP_Error ? ApiResponse::fromWpError($result) : ApiResponse::success(['ok' => true]);
    }

    public function changeStagePermissionCheck(): bool
    {
        return \AvinaCRM\Support\Scope::hasModulePermission('deals') || current_user_can('deals.deal.change_stage');
    }

    public function archive(WP_REST_Request $request)
    {
        $result = $this->service->archive((int) $request->get_param('id'), get_current_user_id());

        return $result instanceof WP_Error ? ApiResponse::fromWpError($result) : ApiResponse::success(['ok' => true]);
    }

    public function archivePermissionCheck(): bool
    {
        return \AvinaCRM\Support\Scope::hasModulePermission('deals') || current_user_can('deals.deal.archive');
    }
}
