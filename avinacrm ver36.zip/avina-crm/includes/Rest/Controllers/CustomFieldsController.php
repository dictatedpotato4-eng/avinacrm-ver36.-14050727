<?php

declare(strict_types=1);

namespace AvinaCRM\Rest\Controllers;

use AvinaCRM\Rest\ApiResponse;
use WP_REST_Request;
use WP_REST_Response;

final class CustomFieldsController
{
    private const ALLOWED_ENTITIES = ['reception', 'contact', 'customer', 'deal'];
    private const ALLOWED_TYPES = ['text', 'number', 'select', 'checkbox', 'file', 'date', 'textarea'];

    public function list(WP_REST_Request $request): WP_REST_Response
    {
        $entity = $request->get_param('entity');
        $allFields = get_option('avina_crm_custom_fields', []);
        $formSettings = get_option('avina_crm_form_settings', []);

        if (!is_array($allFields)) {
            $allFields = [];
        }

        if ($entity !== null && in_array($entity, self::ALLOWED_ENTITIES, true)) {
            $entityFields = $allFields[$entity] ?? [];
            usort($entityFields, fn($a, $b) => ((int)($a['order'] ?? 0)) <=> ((int)($b['order'] ?? 0)));
            
            $entitySettings = $formSettings[$entity] ?? [];
            $submitLabel = $entitySettings['submit_button_label'] ?? '';

            return ApiResponse::success([
                'fields' => $entityFields,
                'submit_button_label' => $submitLabel
            ]);
        }

        foreach ($allFields as $ent => &$fields) {
            if (is_array($fields)) {
                usort($fields, fn($a, $b) => ((int)($a['order'] ?? 0)) <=> ((int)($b['order'] ?? 0)));
            } else {
                $fields = [];
            }
        }

        return ApiResponse::success($allFields);
    }

    public function save(WP_REST_Request $request): WP_REST_Response
    {
        $params = $request->get_json_params() ?? [];

        $entity = sanitize_key($params['entity'] ?? '');
        $id = sanitize_key($params['id'] ?? '');
        $type = sanitize_key($params['type'] ?? '');
        $label = sanitize_text_field($params['label'] ?? '');
        $placeholder = sanitize_text_field($params['placeholder'] ?? '');
        $required = !empty($params['required']);
        $order = (int)($params['order'] ?? 0);
        $step = (int)($params['step'] ?? 1);

        $options = [];
        if (isset($params['options']) && is_array($params['options'])) {
            $options = array_map('sanitize_text_field', $params['options']);
        }

        if (!in_array($entity, self::ALLOWED_ENTITIES, true)) {
            return ApiResponse::error('avina_crm_invalid_entity', __('موجودیت هدف نامعتبر است.', 'avina-crm'), 400);
        }

        if ($id === '') {
            return ApiResponse::error('avina_crm_invalid_id', __('شناسه فیلد الزامی است.', 'avina-crm'), 400);
        }

        if (!in_array($type, self::ALLOWED_TYPES, true)) {
            return ApiResponse::error('avina_crm_invalid_type', __('نوع فیلد نامعتبر است.', 'avina-crm'), 400);
        }

        if ($label === '') {
            return ApiResponse::error('avina_crm_invalid_label', __('برچسب فیلد الزامی است.', 'avina-crm'), 400);
        }

        $allFields = get_option('avina_crm_custom_fields', []);
        if (!is_array($allFields)) {
            $allFields = [];
        }

        if (!isset($allFields[$entity]) || !is_array($allFields[$entity])) {
            $allFields[$entity] = [];
        }

        $fieldData = [
            'id' => $id,
            'entity' => $entity,
            'type' => $type,
            'label' => $label,
            'placeholder' => $placeholder,
            'required' => $required,
            'options' => $options,
            'order' => $order,
            'step' => $step,
        ];

        // Replace if already exists, else append
        $foundIndex = -1;
        foreach ($allFields[$entity] as $index => $field) {
            if ($field['id'] === $id) {
                $foundIndex = $index;
                break;
            }
        }

        if ($foundIndex >= 0) {
            $allFields[$entity][$foundIndex] = $fieldData;
        } else {
            $allFields[$entity][] = $fieldData;
        }

        update_option('avina_crm_custom_fields', $allFields, true);

        return ApiResponse::success($fieldData);
    }

    public function delete(WP_REST_Request $request): WP_REST_Response
    {
        $entity = sanitize_key($request->get_param('entity'));
        $fieldId = sanitize_key($request->get_param('field_id'));

        if (!in_array($entity, self::ALLOWED_ENTITIES, true)) {
            return ApiResponse::error('avina_crm_invalid_entity', __('موجودیت هدف نامعتبر است.', 'avina-crm'), 400);
        }

        $allFields = get_option('avina_crm_custom_fields', []);
        if (!is_array($allFields) || !isset($allFields[$entity])) {
            return ApiResponse::success(['ok' => true]);
        }

        $allFields[$entity] = array_values(array_filter(
            $allFields[$entity],
            fn($field) => $field['id'] !== $fieldId
        ));

        update_option('avina_crm_custom_fields', $allFields, true);

        return ApiResponse::success(['ok' => true]);
    }

    public function getFormSettings(WP_REST_Request $request): WP_REST_Response
    {
        $entity = sanitize_key($request->get_param('entity'));
        if (!in_array($entity, self::ALLOWED_ENTITIES, true)) {
            return ApiResponse::error('avina_crm_invalid_entity', __('موجودیت هدف نامعتبر است.', 'avina-crm'), 400);
        }

        $settings = get_option('avina_crm_form_settings', []);
        $entitySettings = $settings[$entity] ?? [
            'submit_button_label' => '',
            'sms_enabled' => false,
            'sms_provider' => 'ippanel',
            'sms_api_key' => '',
            'sms_sender' => '',
            'sms_recipient' => '',
            'sms_pattern_code' => '',
            'sms_pattern_variables' => '',
        ];

        return ApiResponse::success($entitySettings);
    }

    public function saveFormSettings(WP_REST_Request $request): WP_REST_Response
    {
        $params = $request->get_json_params() ?? [];

        $entity = sanitize_key($params['entity'] ?? '');
        if (!in_array($entity, self::ALLOWED_ENTITIES, true)) {
            return ApiResponse::error('avina_crm_invalid_entity', __('موجودیت هدف نامعتبر است.', 'avina-crm'), 400);
        }

        $settings = get_option('avina_crm_form_settings', []);
        if (!is_array($settings)) {
            $settings = [];
        }

        $settings[$entity] = [
            'submit_button_label' => sanitize_text_field($params['submit_button_label'] ?? ''),
            'sms_enabled' => !empty($params['sms_enabled']),
            'sms_provider' => sanitize_text_field($params['sms_provider'] ?? 'ippanel'),
            'sms_api_key' => sanitize_text_field($params['sms_api_key'] ?? ''),
            'sms_sender' => sanitize_text_field($params['sms_sender'] ?? ''),
            'sms_recipient' => sanitize_text_field($params['sms_recipient'] ?? ''),
            'sms_pattern_code' => sanitize_text_field($params['sms_pattern_code'] ?? ''),
            'sms_pattern_variables' => sanitize_textarea_field($params['sms_pattern_variables'] ?? ''),
        ];

        update_option('avina_crm_form_settings', $settings, true);

        return ApiResponse::success($settings[$entity]);
    }

    public function permissionCheck(): bool
    {
        return current_user_can('platform.admin.access');
    }
}
