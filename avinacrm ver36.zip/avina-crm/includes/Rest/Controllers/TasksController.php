<?php

declare(strict_types=1);

namespace AvinaCRM\Rest\Controllers;

use AvinaCRM\Rest\ApiResponse;
use AvinaCRM\Tasks\TaskService;
use WP_Error;
use WP_REST_Request;
use WP_REST_Response;

final class TasksController
{
    private TaskService $service;

    public function __construct()
    {
        $this->service = new TaskService();
    }

    public function list(WP_REST_Request $request): WP_REST_Response
    {
        $filters = [
            'status' => (string) $request->get_param('status'),
            'priority' => (string) $request->get_param('priority'),
        ];

        return ApiResponse::success($this->service->list($filters));
    }

    public function viewPermissionCheck(): bool
    {
        return \AvinaCRM\Support\Scope::hasModulePermission('tasks') || current_user_can('tasks.task.view');
    }

    public function create(WP_REST_Request $request)
    {
        $params = $request->get_json_params() ?? [];
        $result = $this->service->create($params, get_current_user_id());

        return $result instanceof WP_Error ? ApiResponse::fromWpError($result) : ApiResponse::success($result, 201);
    }

    public function createPermissionCheck(): bool
    {
        return \AvinaCRM\Support\Scope::hasModulePermission('tasks') || current_user_can('tasks.task.create');
    }

    public function updateStatus(WP_REST_Request $request)
    {
        $params = $request->get_json_params() ?? [];
        $result = $this->service->updateStatus((int) $request->get_param('id'), (string) ($params['status'] ?? ''), get_current_user_id());

        return $result instanceof WP_Error ? ApiResponse::fromWpError($result) : ApiResponse::success(['ok' => true]);
    }

    public function updatePermissionCheck(): bool
    {
        return \AvinaCRM\Support\Scope::hasModulePermission('tasks') || current_user_can('tasks.task.update') || current_user_can('tasks.task.complete');
    }
}
