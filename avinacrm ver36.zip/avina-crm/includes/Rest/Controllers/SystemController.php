<?php

declare(strict_types=1);

namespace AvinaCRM\Rest\Controllers;

use AvinaCRM\Database\Migrator;
use AvinaCRM\Rest\ApiResponse;
use WP_REST_Request;
use WP_REST_Response;

/**
 * GET /avina-crm/v1/system/status
 *
 * Permission: platform.health.view. Read-only, no object-level scoping
 * needed (this is system-wide status, not tied to any single record).
 */
final class SystemController
{
    public function handle(WP_REST_Request $request): WP_REST_Response
    {
        global $wpdb;

        $modulesTable = $wpdb->prefix . 'avina_modules';
        $activeModules = $wpdb->get_col("SELECT slug FROM {$modulesTable} WHERE is_active = 1 ORDER BY sort_order ASC");

        return ApiResponse::success([
            'plugin_version' => AVINA_CRM_VERSION,
            'db_version' => get_option(Migrator::OPTION_DB_VERSION, '0'),
            'php_version' => PHP_VERSION,
            'active_modules' => $activeModules,
        ]);
    }

    public function permissionCheck(): bool
    {
        return current_user_can('platform.health.view');
    }
}
