<?php

declare(strict_types=1);

namespace AvinaCRM\Rest\Controllers;

use AvinaCRM\Capabilities\CapabilityDefinitions;
use AvinaCRM\Capabilities\RoleProvisioner;
use AvinaCRM\Rest\ApiResponse;
use WP_REST_Request;
use WP_REST_Response;

/**
 * GET /avina-crm/v1/me
 *
 * Permission: must be logged in (is_user_logged_in). No specific
 * capability required beyond that — every authenticated WordPress user
 * is allowed to know who they are; the *content* of the response is
 * self-scoped (current_user only) so there is no object-level
 * authorization concern here.
 */
final class MeController
{
    public function handle(WP_REST_Request $request): WP_REST_Response
    {
        $user = wp_get_current_user();
        $targetId = (int) $request->get_param('user_id');
        $currentUserIsAdmin = \AvinaCRM\Support\Scope::isAdmin();

        if ($targetId > 0 && $currentUserIsAdmin) {
            $targetUser = get_userdata($targetId);
            if ($targetUser) {
                $user = $targetUser;
            }
        }

        $targetIsAdmin = \AvinaCRM\Support\Scope::isAdmin($user->ID);

        if ($targetIsAdmin) {
            $permissions = ['dashboard', 'settings', 'users', 'recruitment', 'inventory', 'customers', 'invoices', 'leads', 'expenses', 'cheques', 'reports', 'phonebook', 'ai-assistant', 'reception', 'tickets', 'tasks'];
        } else {
            $permissions = get_user_meta($user->ID, 'avina_crm_operator_permissions', true);
            if (!is_array($permissions)) {
                $permissions = ['dashboard', 'leads'];
            }
        }

        $messengerSettings = get_user_meta($user->ID, 'avina_crm_messenger_settings', true);
        if (empty($messengerSettings) || !is_array($messengerSettings)) {
            $messengerSettings = get_option('avina_crm_messenger_settings_' . $user->ID, []);
        }

        return ApiResponse::success([
            'id' => (string) $user->ID,
            'display_name' => $user->display_name,
            'username' => $user->user_login,
            'is_operator' => in_array(RoleProvisioner::ROLE_SLUG, (array) $user->roles, true),
            'is_administrator' => $targetIsAdmin,
            'capabilities' => $permissions,
            'permissions' => $permissions,
            'messengerSettings' => is_array($messengerSettings) ? $messengerSettings : [],
        ]);
    }

    public function saveMessenger(WP_REST_Request $request): WP_REST_Response
    {
        $userId = get_current_user_id();
        if ($userId <= 0) {
            return ApiResponse::error('unauthorized', 'کاربر وارد نشده است.', 401);
        }

        $params = $request->get_json_params() ?? [];
        $settings = is_array($params['messengerSettings'] ?? null) ? $params['messengerSettings'] : (is_array($params['messenger_settings'] ?? null) ? $params['messenger_settings'] : $params);

        $sanitized = [];
        if (is_array($settings)) {
            foreach ($settings as $k => $v) {
                $sanitized[sanitize_key((string)$k)] = sanitize_text_field((string)$v);
            }
        }

        update_user_meta($userId, 'avina_crm_messenger_settings', $sanitized);
        update_option('avina_crm_messenger_settings_' . $userId, $sanitized);

        return ApiResponse::success([
            'saved' => true,
            'messengerSettings' => $sanitized
        ]);
    }

    public function permissionCheck(): bool
    {
        return is_user_logged_in();
    }
}
