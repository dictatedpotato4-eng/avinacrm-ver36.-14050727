<?php

declare(strict_types=1);

namespace AvinaCRM\Rest\Controllers;

use AvinaCRM\Rest\ApiResponse;
use AvinaCRM\Support\Csv;
use WP_REST_Request;
use WP_REST_Response;

final class SettingsController
{
    public function getLayout(WP_REST_Request $request): WP_REST_Response
    {
        $userId = get_current_user_id();
        $layout = get_user_meta($userId, 'avina_crm_widgets_layout', true);
        if (empty($layout) || !is_array($layout)) {
            $layout = [
                'widgets' => [
                    ['id' => 'contacts_today', 'visible' => true, 'order' => 1],
                    ['id' => 'buying_prob_today', 'visible' => true, 'order' => 2],
                    ['id' => 'followups_today', 'visible' => true, 'order' => 3],
                    ['id' => 'interactions_today', 'visible' => true, 'order' => 4]
                ]
            ];
        }
        return ApiResponse::success($layout);
    }

    public function saveLayout(WP_REST_Request $request): WP_REST_Response
    {
        $userId = get_current_user_id();
        $params = $request->get_json_params() ?? [];
        update_user_meta($userId, 'avina_crm_widgets_layout', $params);
        return ApiResponse::success(['ok' => true]);
    }

    public function getKanbanTasks(WP_REST_Request $request): WP_REST_Response
    {
        global $wpdb;
        $count = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}avina_kanban_tasks");
        if ($count === 0) {
            $this->seedKanbanTasks();
        }
        $tasks = $wpdb->get_results(
            "SELECT t.*, c.phone as contact_phone FROM {$wpdb->prefix}avina_kanban_tasks t LEFT JOIN {$wpdb->prefix}avina_contacts c ON t.contact_id = c.id ORDER BY t.updated_at DESC",
            ARRAY_A
        ) ?: [];
        
        return ApiResponse::success($tasks);
    }

    public function updateKanbanTaskStage(WP_REST_Request $request): WP_REST_Response
    {
        global $wpdb;
        $id = (int) $request->get_param('id');
        $params = $request->get_json_params() ?? [];
        $stageId = sanitize_key($params['stage_id'] ?? 'lead');

        $existing = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$wpdb->prefix}avina_kanban_tasks WHERE id = %d", $id), ARRAY_A);
        if (!$existing) {
            return ApiResponse::error('avina_crm_task_not_found', __('تسک یافت نشد.', 'avina-crm'), 404);
        }

        $wpdb->update(
            $wpdb->prefix . 'avina_kanban_tasks',
            ['stage_id' => $stageId, 'updated_at' => current_time('mysql')],
            ['id' => $id],
            ['%s', '%s'],
            ['%d']
        );

        $wpdb->insert(
            $wpdb->prefix . 'avina_kanban_task_logs',
            [
                'task_id' => $id,
                'action' => 'stage_changed',
                'details' => sprintf('انتقال وظیفه از مرحله %s به مرحله %s', $existing['stage_id'], $stageId),
                'created_by_user_id' => get_current_user_id(),
                'created_at' => current_time('mysql')
            ],
            ['%d', '%s', '%s', '%d', '%s']
        );

        return ApiResponse::success(['ok' => true]);
    }

    private function seedKanbanTasks(): void
    {
        global $wpdb;
        $table = $wpdb->prefix . 'avina_kanban_tasks';
        $userId = get_current_user_id();

        $demoTasks = [
            ['title' => 'پیگیری خرید دستگاه Pax S90 آقای اکبری', 'description' => 'ارسال پیش‌فاکتور پکس و هماهنگی نماینده برای نصب سیم‌کارت', 'stage_id' => 'lead', 'color' => '#6366f1', 'glow' => 'rgba(99, 102, 241, 0.12)'],
            ['title' => 'ارسال دموی ویدئویی نرم‌افزار به خانم حسینی', 'description' => 'پرزنت محصولات نئونی و ارسال فایل‌های کاتالوگ در ایتا', 'stage_id' => 'contacted', 'color' => '#eab308', 'glow' => 'rgba(234, 179, 8, 0.12)'],
            ['title' => 'جلسه حضوری با مدیر خرید فروشگاه رفاه', 'description' => 'ساعت ۱۵ برای عقد قرارداد پذیرش ۵۰ دستگاه کارتخوان جدید', 'stage_id' => 'demo', 'color' => '#3b82f6', 'glow' => 'rgba(59, 130, 246, 0.12)'],
            ['title' => 'تعمیر برد تغذیه کارتخوان پکس اس ۹۱۰', 'description' => 'پذیرش شماره ۱۰۲ متعلق به آقای کریمی، عیب‌یابی کامل برد', 'stage_id' => 'lead', 'color' => '#6366f1', 'glow' => 'rgba(99, 102, 241, 0.12)'],
            ['title' => 'تسویه نهایی فاکتور خرید شرکت مانی', 'description' => 'تایید واریز مبلغ ۲۵۰ میلیون ریال و ثبت خرید در سیستم', 'stage_id' => 'won', 'color' => '#10b981', 'glow' => 'rgba(16, 185, 129, 0.12)'],
            ['title' => 'تماس دوم پیگیری پیشنهاد تخفیف فصلی', 'description' => 'مشتری درخواست ۵٪ تخفیف بیشتر داشت، منتظر تایید مدیریت', 'stage_id' => 'contacted', 'color' => '#eab308', 'glow' => 'rgba(234, 179, 8, 0.12)'],
            ['title' => 'پرزنت و دمو حسابداری ابری همکاران', 'description' => 'ارائه دسترسی موقت ۳ روزه دمو برای تست پنل ادمین', 'stage_id' => 'demo', 'color' => '#3b82f6', 'glow' => 'rgba(59, 130, 246, 0.12)'],
            ['title' => 'انصراف خرید به دلیل عدم پوشش شبکه روستایی', 'description' => 'مشتری در منطقه فاقد آنتن‌دهی بود و سفارش را لغو کرد.', 'stage_id' => 'lost', 'color' => '#ef4444', 'glow' => 'rgba(239, 68, 68, 0.12)'],
            ['title' => 'ارسال پیام خوش‌آمدگویی و آدرس دفتر', 'description' => 'پیامک آدرس و نقشه دسترسی برای پذیرش حضوری ارسال شد.', 'stage_id' => 'won', 'color' => '#10b981', 'glow' => 'rgba(16, 185, 129, 0.12)'],
            ['title' => 'پذیرش دستگاه کارتخوان نیوپوز آقای رضایی', 'description' => 'مشکل عدم روشن شدن صفحه نمایش به همراه متعلقات کیف و شارژر', 'stage_id' => 'lead', 'color' => '#6366f1', 'glow' => 'rgba(99, 102, 241, 0.12)']
        ];

        foreach ($demoTasks as $task) {
            $wpdb->insert(
                $table,
                [
                    'title' => $task['title'],
                    'description' => $task['description'],
                    'stage_id' => $task['stage_id'],
                    'assignee_user_id' => $userId,
                    'color_tag' => $task['color'],
                    'color_glow' => $task['glow'],
                    'created_by_user_id' => $userId,
                    'created_at' => current_time('mysql'),
                    'updated_at' => current_time('mysql')
                ],
                ['%s', '%s', '%s', '%d', '%s', '%s', '%d', '%s', '%s']
            );
        }
    }

    public function getSettings(WP_REST_Request $request): WP_REST_Response
    {
        global $wpdb;

        $templates = get_option('avina_crm_message_templates', [
            'template_1' => 'آدرس ما: تهران، خیابان آزادی...',
            'template_2' => 'سلام، حضور شما برای تاریخ [date] تایید شد.',
            'template_3' => 'خرید شما با موفقیت ثبت شد. با تشکر از اعتماد شما.',
            'template_4' => 'در انتظار حضور شما جهت بررسی و پذیرش هستیم.',
            'template_5' => 'محصولات جدید ما را در وب‌سایت مشاهده کنید.'
        ]);

        $kanban = get_option('avina_crm_kanban_settings', [
            'enabled' => true,
            'dashboard_visible' => true,
            'stages' => [
                ['id' => 'lead', 'name' => 'سرنخ جدید', 'color' => '#6366f1'],
                ['id' => 'contacted' , 'name' => 'اولین تماس', 'color' => '#eab308'],
                ['id' => 'demo', 'name' => 'جلسه دمو', 'color' => '#3b82f6'],
                ['id' => 'won', 'name' => 'موفق (خرید)', 'color' => '#10b981'],
                ['id' => 'lost', 'name' => 'لغو شده', 'color' => '#ef4444']
            ]
        ]);

        $keypad = get_option('avina_crm_keypad_settings', [
            'cooldown_seconds' => 60,
            'keys' => [
                '0' => ['channel' => 'sms', 'template' => 'خوش آمدید. عدد ۰ دریافت شد.'],
                '1' => ['channel' => 'sms', 'template' => 'پیگیری اول. عدد ۱ دریافت شد.'],
                '2' => ['channel' => 'eitaa', 'template' => 'ارسال پیام در ایتا. عدد ۲ دریافت شد.'],
                '3' => ['channel' => 'whatsapp', 'template' => 'ارسال پیام در واتساپ. عدد ۳ دریافت شد.'],
                '4' => ['channel' => 'sms', 'template' => 'عضویت شما تایید شد.'],
                '5' => ['channel' => 'sms', 'template' => 'فایل راهنما ارسال شد.'],
                '6' => ['channel' => 'sms', 'template' => 'درخواست شما ثبت شد.'],
                '7' => ['channel' => 'sms', 'template' => 'با شما تماس می‌گیریم.'],
                '8' => ['channel' => 'sms', 'template' => 'سفارش آماده ارسال است.'],
                '9' => ['channel' => 'sms', 'template' => 'ممنون از همراهی شما.']
            ]
        ]);

        $products = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}avina_products ORDER BY id DESC", ARRAY_A) ?: [];
        $services = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}avina_services ORDER BY id DESC", ARRAY_A) ?: [];

        return ApiResponse::success([
            'message_templates' => $templates,
            'kanban_settings' => $kanban,
            'keypad_settings' => $keypad,
            'products' => $products,
            'gemini_api_key' => get_option('avina_crm_gemini_api_key', ''),
            'gemini_api_key_dashboard' => get_option('avina_crm_gemini_api_key_dashboard', ''),
            'gemini_api_key_floating' => get_option('avina_crm_gemini_api_key_floating', ''),
            'gemini_api_key_training' => get_option('avina_crm_gemini_api_key_training', ''),
            'gemini_model' => get_option('avina_crm_gemini_model', 'gemini-3-flash-preview'),
            'gemini_proxy' => get_option('avina_crm_ai_proxy', ''),
            'gemini_instruction' => get_option('avina_crm_gemini_instruction', 'شما دستیار هوشمند آوینا هستید. آمار سیستم را تحلیل کنید و پاسخ دهید.')
        ]);
    }

    public function saveSettings(WP_REST_Request $request): WP_REST_Response
    {
        $params = $request->get_json_params() ?? [];

        if (isset($params['message_templates'])) {
            $templates = $params['message_templates'];
            $sanitized = [];
            foreach ($templates as $key => $val) {
                $sanitized[sanitize_key($key)] = sanitize_textarea_field((string)$val);
            }
            update_option('avina_crm_message_templates', $sanitized, true);
        }

        if (isset($params['kanban_settings'])) {
            $kanban = $params['kanban_settings'];
            $sanitized = [
                'enabled' => !empty($kanban['enabled']),
                'dashboard_visible' => !empty($kanban['dashboard_visible']),
                'stages' => []
            ];
            if (!empty($kanban['stages']) && is_array($kanban['stages'])) {
                foreach ($kanban['stages'] as $stage) {
                    $sanitized['stages'][] = [
                        'id' => sanitize_key($stage['id'] ?? ''),
                        'name' => sanitize_text_field($stage['name'] ?? ''),
                        'color' => sanitize_text_field($stage['color'] ?? '#6366f1')
                    ];
                }
            }
            update_option('avina_crm_kanban_settings', $sanitized, true);
        }

        if (isset($params['keypad_settings'])) {
            $keypad = $params['keypad_settings'];
            $sanitized = [
                'cooldown_seconds' => max(10, (int) ($keypad['cooldown_seconds'] ?? 60)),
                'keys' => []
            ];
            if (!empty($keypad['keys']) && is_array($keypad['keys'])) {
                foreach ($keypad['keys'] as $num => $keyData) {
                    $sanitized['keys'][(string)$num] = [
                        'channel' => sanitize_key($keyData['channel'] ?? 'sms'),
                        'template' => sanitize_textarea_field($keyData['template'] ?? '')
                    ];
                }
            }
            update_option('avina_crm_keypad_settings', $sanitized, true);
        }

        if (isset($params['gemini_api_key'])) {
            update_option('avina_crm_gemini_api_key', sanitize_text_field($params['gemini_api_key']), true);
        }

        if (isset($params['gemini_api_key_dashboard'])) {
            update_option('avina_crm_gemini_api_key_dashboard', sanitize_text_field($params['gemini_api_key_dashboard']), true);
        }

        if (isset($params['gemini_api_key_floating'])) {
            update_option('avina_crm_gemini_api_key_floating', sanitize_text_field($params['gemini_api_key_floating']), true);
        }

        if (isset($params['gemini_api_key_training'])) {
            update_option('avina_crm_gemini_api_key_training', sanitize_text_field($params['gemini_api_key_training']), true);
        }

        if (!empty($params['documentScannerSettings']['apiKey'])) {
            update_option('avina_crm_gemini_api_key', sanitize_text_field($params['documentScannerSettings']['apiKey']), true);
        }

        if (!empty($params['documentScannerSettings']['model'])) {
            $savedModel = sanitize_text_field($params['documentScannerSettings']['model']);
            if (in_array($savedModel, ['gemini-1.5-flash', 'gemini-2.5-flash', 'gemini-1.5-pro'], true)) {
                $savedModel = 'gemini-3-flash-preview';
            }
            update_option('avina_crm_gemini_model', $savedModel, true);
        }

        $rawProxy = '';
        if (isset($params['gemini_proxy'])) {
            $rawProxy = sanitize_text_field($params['gemini_proxy']);
        }
        if (isset($params['documentScannerSettings']['proxy'])) {
            $rawProxy = sanitize_text_field($params['documentScannerSettings']['proxy']);
        }
        if (strpos($rawProxy, '/32') !== false || strpos($rawProxy, '10.66.66.') !== false) {
            $rawProxy = '';
        }
        update_option('avina_crm_ai_proxy', $rawProxy, true);

        if (isset($params['gemini_instruction'])) {
            update_option('avina_crm_gemini_instruction', sanitize_textarea_field($params['gemini_instruction']), true);
        }

        return ApiResponse::success(['ok' => true]);
    }

    public function addProduct(WP_REST_Request $request): WP_REST_Response
    {
        $params = $request->get_json_params() ?? [];
        $name = sanitize_text_field($params['name'] ?? '');

        if ($name === '') {
            return ApiResponse::error('avina_crm_invalid_product', __('نام محصول الزامی است.', 'avina-crm'), 400);
        }

        global $wpdb;
        $wpdb->insert($wpdb->prefix . 'avina_products', ['name' => $name], ['%s']);

        return ApiResponse::success(['id' => (int) $wpdb->insert_id, 'name' => $name]);
    }

    public function deleteProduct(WP_REST_Request $request): WP_REST_Response
    {
        $id = (int) $request->get_param('id');
        global $wpdb;
        $wpdb->delete($wpdb->prefix . 'avina_products', ['id' => $id], ['%d']);

        return ApiResponse::success(['ok' => true]);
    }

    public function addService(WP_REST_Request $request): WP_REST_Response
    {
        $params = $request->get_json_params() ?? [];
        $name = sanitize_text_field($params['name'] ?? '');

        if ($name === '') {
            return ApiResponse::error('avina_crm_invalid_service', __('نام خدمت الزامی است.', 'avina-crm'), 400);
        }

        global $wpdb;
        $wpdb->insert($wpdb->prefix . 'avina_services', ['name' => $name], ['%s']);

        return ApiResponse::success(['id' => (int) $wpdb->insert_id, 'name' => $name]);
    }

    public function deleteService(WP_REST_Request $request): WP_REST_Response
    {
        $id = (int) $request->get_param('id');
        global $wpdb;
        $wpdb->delete($wpdb->prefix . 'avina_services', ['id' => $id], ['%d']);

        return ApiResponse::success(['ok' => true]);
    }

    public function exportIntakes(WP_REST_Request $request)
    {
        global $wpdb;
        $rows = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}avina_device_intakes ORDER BY id DESC", ARRAY_A) ?: [];

        $headers = [
            __('نام مشتری', 'avina-crm'),
            __('مدل دستگاه', 'avina-crm'),
            __('تاریخ پذیرش', 'avina-crm'),
            __('مشکل دستگاه', 'avina-crm'),
            __('متعلقات همراه', 'avina-crm'),
            __('وضعیت', 'avina-crm')
        ];

        $csvRows = [];
        foreach ($rows as $row) {
            $statusStr = 'در انتظار بررسی';
            if ($row['status'] === 'inspecting') { $statusStr = 'در حال عیب‌یابی'; }
            elseif ($row['status'] === 'repaired') { $statusStr = 'تعمیر شده'; }
            elseif ($row['status'] === 'delivered') { $statusStr = 'تحویل داده شده'; }
            elseif ($row['status'] === 'cancelled') { $statusStr = 'لغو پذیرش'; }

            $csvRows[] = [
                $row['customer_name'],
                $row['device_model'],
                $row['intake_date'],
                $row['issue'],
                $row['accessories'] ?? '',
                $statusStr
            ];
        }

        Csv::streamDownload('avina-crm-device-intakes.csv', $headers, $csvRows);
        exit;
    }

    public function permissionCheck(): bool
    {
        return current_user_can('manage_options');
    }
}
