<?php

declare(strict_types=1);

namespace AvinaCRM\Rest\Controllers;

use AvinaCRM\Rest\ApiResponse;
use WP_REST_Request;
use WP_REST_Response;

final class AiController
{
    public function chat(WP_REST_Request $request): WP_REST_Response
    {
        $params = $request->get_json_params() ?? [];
        $message = sanitize_textarea_field($params['message'] ?? '');
        $extraContext = sanitize_textarea_field($params['extraContext'] ?? '');

        if ($message === '') {
            return ApiResponse::error('avina_crm_ai_empty_message', __('پیام نمی‌تواند خالی باشد.', 'avina-crm'), 400);
        }

        $serviceType = sanitize_key((string)($params['serviceType'] ?? ''));
        $apiKey = trim((string)($params['apiKey'] ?? ''));
        if (empty($apiKey)) {
            if ($serviceType === 'dashboard') {
                $apiKey = get_option('avina_crm_gemini_api_key_dashboard', '');
            } elseif ($serviceType === 'floating') {
                $apiKey = get_option('avina_crm_gemini_api_key_floating', '');
            } elseif ($serviceType === 'training') {
                $apiKey = get_option('avina_crm_gemini_api_key_training', '');
            }
            if (empty($apiKey)) {
                $apiKey = get_option('avina_crm_gemini_api_key', '');
            }
        }
        if ($apiKey === '') {
            return ApiResponse::success([
                'reply' => 'سلام! من آوینا، دستیار هوشمند شما هستم. متأسفانه کلید Gemini API هنوز در تنظیمات پیشرفته افزونه ثبت نشده است. لطفاً ابتدا کلید API خود را در بخش تنظیمات ثبت کنید.'
            ]);
        }

        $instruction = get_option('avina_crm_gemini_instruction', 'شما دستیار هوشمند آوینا هستید. تحلیل‌های سازمانی، آمارهای عملکرد اپراتورها، و متن‌های پاسخ‌دهی به مشتریان را دقیق، کاربردی و محترمانه به زبان فارسی ارائه می‌دهید.');

        $userId = sanitize_text_field((string)($params['userId'] ?? get_current_user_id()));
        $userRole = sanitize_text_field((string)($params['userRole'] ?? ''));
        $isAdmin = current_user_can('manage_options') || ($userRole === 'admin');

        // Gather CRM statistics with strict user isolation
        global $wpdb;
        if ($isAdmin) {
            $contacts_cnt = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}avina_contacts WHERE is_archived = 0");
            $customers_cnt = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}avina_customers WHERE is_archived = 0");
            
            $deals_stats = $wpdb->get_results("SELECT status, COUNT(*) as cnt, SUM(value) as val FROM {$wpdb->prefix}avina_deals WHERE is_archived = 0 GROUP BY status", ARRAY_A);
            $deals_info = "";
            if (!empty($deals_stats)) {
                foreach ($deals_stats as $stat) {
                    $deals_info .= "وضعیت " . $stat['status'] . ": " . $stat['cnt'] . " معامله به ارزش " . number_format((float)$stat['val']) . " ریال. ";
                }
            } else {
                $deals_info = "معامله‌ای ثبت نشده است.";
            }

            $receptions_cnt = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}avina_device_intakes");
            $invoices_sum = (float) $wpdb->get_var("SELECT SUM(total) FROM {$wpdb->prefix}avina_invoices WHERE is_archived = 0");
            $payments_sum = (float) $wpdb->get_var("SELECT SUM(amount) FROM {$wpdb->prefix}avina_payments");

            $crmContext = "اطلاعات آماری پایگاه داده کلان CRM برای مدیریت ارشد سیستم:\n";
            $crmContext .= "- مخاطبین کل سیستم: $contacts_cnt\n";
            $crmContext .= "- مشتریان کل سیستم: $customers_cnt\n";
            $crmContext .= "- آمار معاملات: $deals_info\n";
            $crmContext .= "- کل پذیرش‌های ثبت شده: $receptions_cnt\n";
            $crmContext .= "- جمع فاکتورها: " . number_format($invoices_sum) . " ریال\n";
            $crmContext .= "- جمع پرداخت‌ها: " . number_format($payments_sum) . " ریال\n";
        } else {
            $cleanUid = preg_replace('/\D+/', '', $userId);
            $contacts_cnt = (int) $wpdb->get_var($wpdb->prepare(
                "SELECT COUNT(*) FROM {$wpdb->prefix}avina_contacts WHERE is_archived = 0 AND (owner_user_id = %s OR created_by_user_id = %s)",
                $cleanUid ?: $userId,
                $cleanUid ?: $userId
            ));
            $customers_cnt = (int) $wpdb->get_var($wpdb->prepare(
                "SELECT COUNT(*) FROM {$wpdb->prefix}avina_customers WHERE is_archived = 0 AND (owner_user_id = %s OR created_by_user_id = %s)",
                $cleanUid ?: $userId,
                $cleanUid ?: $userId
            ));

            $crmContext = "شما دستیار اختصاصی این اپراتور (شناسه کاربری: {$userId}) هستید.\n";
            $crmContext .= "شما صرفاً بر روی مخاطبین و وظایف شخصی این اپراتور تمرکز دارید و به هیچ عنوان نباید آمارهای مالی کلان سازمان، فاکتورها یا اطلاعات سایر اپراتورها را به وی نشان دهید.\n";
            $crmContext .= "- مخاطبین اختصاصی شما: $contacts_cnt\n";
            $crmContext .= "- مشتریان اختصاصی شما: $customers_cnt\n";
        }

        if (!empty($extraContext)) {
            $crmContext .= "\n[گزارش تفصیلی وضعیت عملیاتی و پرسنل]:\n" . $extraContext . "\n";
        }

        $systemPrompt = $instruction . "\n\n" . $crmContext . "\nدرخواست کاربر:\n" . $message;
        $contents = [['parts' => [['text' => $systemPrompt]]]];

        $res = $this->callGeminiApi($apiKey, 'gemini-3-flash-preview', $contents);

        if (!$res['success']) {
            return ApiResponse::error('avina_crm_ai_http_error', "Gemini API Error: " . $res['error'], $res['code']);
        }

        $data = json_decode($res['body'], true);
        $reply = $data['candidates'][0]['content']['parts'][0]['text'] ?? 'خطا در دریافت پاسخ از هوش مصنوعی.';

        return ApiResponse::success(['reply' => $reply]);
    }

    public function scanDocument(WP_REST_Request $request): WP_REST_Response
    {
        $params = $request->get_json_params() ?? [];
        $imageBase64 = trim((string)($params['image'] ?? ''));
        $apiKey = trim((string)($params['apiKey'] ?? ''));
        $model = trim((string)($params['model'] ?? 'gemini-3-flash-preview'));
        $proxy = trim((string)($params['proxy'] ?? ''));

        if (empty($apiKey)) {
            $apiKey = get_option('avina_crm_gemini_api_key', '');
        }

        if (empty($apiKey)) {
            return ApiResponse::error('avina_crm_ai_empty_key', 'کلید API هوش مصنوعی Gemini در تنظیمات مدیر ثبت نشده است.', 400);
        }

        if (empty($imageBase64)) {
            return ApiResponse::error('avina_crm_ai_empty_image', 'تصویر مدرک ارسالی خالی است.', 400);
        }

        // Clean base64 header if present
        if (strpos($imageBase64, ',') !== false) {
            $parts = explode(',', $imageBase64);
            $imageBase64 = end($parts);
        }

        // Save image to upload directory as real file to avoid large base64 storage
        $imageUrl = '';
        $upload_dir = wp_upload_dir();
        $target_dir = $upload_dir['basedir'] . '/avina-crm-docs';
        $target_url = $upload_dir['baseurl'] . '/avina-crm-docs';
        if (!file_exists($target_dir)) {
            wp_mkdir_p($target_dir);
        }
        $decoded = base64_decode($imageBase64);
        if ($decoded !== false) {
            $filename = 'scan_' . time() . '_' . wp_generate_password(6, false) . '.jpg';
            $filepath = $target_dir . '/' . $filename;
            if (@file_put_contents($filepath, $decoded) !== false) {
                $imageUrl = $target_url . '/' . $filename;
            }
        }

        $promptText = "شما یک سیستم تحلیل تصویر و OCR مدرک اداری فارسی هستید.
لطفاً این تصویر (کارت ملی، رسید، فاکتور، فرم پذیرش یا لیست مخاطبین/مشتریان) را به دقت بررسی کن.

اگر تصویر حاوی متن یا اطلاعات شناسه/فاکتور/پذیرش فارسی نیست، فیلد foundInfo را برابر false قرار بده.
در غیر این صورت اطلاعات واقعی موجود را در یک JSON خام با کلیدهای زیر استخراج نما:

{
  \"foundInfo\": true,
  \"name\": \"نام و نام خانوادگی اصلی\",
  \"mobile\": \"شماره همراه (مثلاً 09121234567)\",
  \"nationalCode\": \"کد ملی یا شناسه اقتصادی\",
  \"deviceModel\": \"مدل دستگاه، کالا یا عنوان خدمات\",
  \"serialNumber\": \"شماره سریال، شماره فاکتور یا کد رهگیری\",
  \"problemDescription\": \"شرح ایراد، توضیحات یا جزئیات فاکتور\",
  \"totalPrice\": \"مبلغ کل به عدد\",
  \"purchaseProbability\": 4,
  \"contacts\": [
    {
      \"name\": \"نام شخص یا مخاطب\",
      \"mobile\": \"شماره همراه\",
      \"notes\": \"توضیحات یا درخواست مرتبط با این شخص\",
      \"job\": \"شغل یا سمت در صورت وجود\",
      \"purchaseProbability\": 4
    }
  ]
}

قوانین مهم:
۱. اگر برگه شامل چندین شخص یا چندین شماره تماس و توضیحات است، برای تک‌تک آن‌ها یک آیتم مجزا در آرایه contacts بساز.
۲. بر اساس متن و میزان نیاز یا جدیت، فیلد purchaseProbability را بین عدد ۱ تا ۵ هوشمندانه تخمین بزن (۵ بیشترین تمایل خرید، ۱ کمترین).
۳. اگر فقط یک شخص در تصویر است، فیلدهای اصلی را پر کن و در آرایه contacts نیز همان یک نفر را قرار بده.
۴. خروجی باید الزاماً فقط یک آبجکت JSON معتبر باشد.";

        $contents = [[
            'parts' => [
                ['text' => $promptText],
                ['inline_data' => ['mime_type' => 'image/jpeg', 'data' => $imageBase64]]
            ]
        ]];

        $generationConfig = [
            'responseMimeType' => 'application/json',
            'temperature' => 0.1,
            'maxOutputTokens' => 1024,
        ];

        $res = $this->callGeminiApi($apiKey, $model, $contents, $proxy, $generationConfig);

        if (!$res['success']) {
            return ApiResponse::error('avina_crm_ai_google_error', "گوگل Gemini: " . $res['error'], $res['code']);
        }

        $data = json_decode($res['body'], true);
        $text = $data['candidates'][0]['content']['parts'][0]['text'] ?? '';

        $parsed = null;
        if ($text) {
            $parsed = json_decode($text, true);
            if (!$parsed && preg_match('/\{[\s\S]*\}/', $text, $matches)) {
                $parsed = json_decode($matches[0], true);
            }
        }

        return ApiResponse::success([
            'extracted' => $parsed,
            'raw' => $text,
            'usedModel' => $res['model'],
            'imageUrl' => $imageUrl
        ]);
    }

    private function callGeminiApi(string $apiKey, string $requestedModel, array $contents, string $customProxy = '', array $generationConfig = []): array
    {
        if (empty($requestedModel) || in_array($requestedModel, ['gemini-1.5-flash', 'gemini-2.5-flash', 'gemini-1.5-pro', 'gemini-pro', 'gemini-1.0-pro'], true)) {
            $requestedModel = 'gemini-3-flash-preview';
        }

        // Prioritized verified working models for this project
        $candidateModels = array_unique([$requestedModel, 'gemini-3-flash-preview', 'gemini-3.5-flash', 'gemini-flash-latest', 'gemma-4-26b-a4b-it']);
        
        $lastError = '';
        $lastCode = 500;

        $proxy = !empty($customProxy) ? $customProxy : get_option('avina_crm_ai_proxy', '');
        // If someone entered a CIDR like /32 or local VPN IP, ignore it so it connects directly
        if (!empty($proxy) && (strpos($proxy, '/32') !== false || strpos($proxy, '/24') !== false || strpos($proxy, '10.66.66.') !== false)) {
            $proxy = '';
        }
        if (empty($proxy) && defined('WP_PROXY_HOST') && WP_PROXY_HOST) {
            $proxy = WP_PROXY_HOST . (defined('WP_PROXY_PORT') && WP_PROXY_PORT ? ':' . WP_PROXY_PORT : '');
        }

        foreach ($candidateModels as $model) {
            $url = "https://generativelanguage.googleapis.com/v1beta/models/{$model}:generateContent?key={$apiKey}";
            
            $payload = ['contents' => $contents];
            if (!empty($generationConfig)) {
                $payload['generationConfig'] = $generationConfig;
            }

            $args = [
                'headers' => ['Content-Type' => 'application/json'],
                'body' => wp_json_encode($payload),
                'timeout' => 30,
                'sslverify' => false,
            ];

            if (!empty($proxy)) {
                $args['proxy'] = $proxy;
            }

            $response = wp_remote_post($url, $args);

            // If proxy failed (e.g. invalid host, connection refused), automatically retry direct!
            if (is_wp_error($response) && !empty($args['proxy'])) {
                unset($args['proxy']);
                $response = wp_remote_post($url, $args);
            }

            if (is_wp_error($response)) {
                $lastError = $response->get_error_message();
                continue;
            }

            $code = wp_remote_retrieve_response_code($response);
            $body = wp_remote_retrieve_body($response);

            if ($code === 200) {
                return ['success' => true, 'body' => $body, 'model' => $model];
            }

            $errData = json_decode($body, true);
            $lastError = $errData['error']['message'] ?? "HTTP $code: $body";
            $lastCode = $code;

            // If API key is definitely invalid, stop trying other models with same key
            if (strpos($lastError, 'API key not valid') !== false || strpos($lastError, 'API_KEY_INVALID') !== false) {
                break;
            }

            // For all other errors ("no longer available", "not found", "not supported", quota, etc.), continue to next model!
        }

        return ['success' => false, 'error' => $lastError, 'code' => $lastCode];
    }

    public function permissionCheck(): bool
    {
        return true;
    }
}
