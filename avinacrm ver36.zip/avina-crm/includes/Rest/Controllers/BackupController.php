<?php

declare(strict_types=1);

namespace AvinaCRM\Rest\Controllers;

use AvinaCRM\Backup\BackupService;
use WP_REST_Request;

final class BackupController
{
    private BackupService $service;

    public function __construct()
    {
        $this->service = new BackupService();
    }

    /**
     * Streams raw JSON directly (not a REST envelope — a file download
     * needs real HTTP headers and raw bytes, same pattern as the
     * Contacts CSV export in Stage 3).
     */
    public function exportJson(WP_REST_Request $request)
    {
        $tables = (array) $request->get_param('tables');
        $this->service->streamJson(array_map('sanitize_key', $tables), get_current_user_id());
        exit;
    }

    public function exportCsv(WP_REST_Request $request)
    {
        $table = sanitize_key((string) $request->get_param('table'));
        $this->service->streamCsv($table, get_current_user_id());
        exit;
    }

    public function listLocal(WP_REST_Request $request)
    {
        return \AvinaCRM\Rest\ApiResponse::success($this->service->listLocalBackups());
    }

    public function createLocal(WP_REST_Request $request)
    {
        $result = $this->service->createLocalBackup(get_current_user_id());
        return \AvinaCRM\Rest\ApiResponse::success($result);
    }

    public function deleteLocal(WP_REST_Request $request)
    {
        $filename = sanitize_text_field((string)$request->get_param('filename'));
        $result = $this->service->deleteLocalBackup($filename, get_current_user_id());
        if ($result) {
            return \AvinaCRM\Rest\ApiResponse::success(['ok' => true]);
        }
        return \AvinaCRM\Rest\ApiResponse::error('avina_crm_backup_delete_failed', __('حذف فایل پشتیبان ناموفق بود.', 'avina-crm'), 400);
    }

    public function downloadLocal(WP_REST_Request $request)
    {
        $filename = sanitize_text_field((string)$request->get_param('filename'));
        $this->service->downloadLocalBackup($filename, get_current_user_id());
        exit;
    }

    public function permissionCheck(): bool
    {
        return current_user_can('backup.export.download');
    }

    public function availableTables(): array
    {
        return BackupService::exportableTableKeys();
    }
}
