<?php

declare(strict_types=1);

namespace AvinaCRM\Rest\Controllers;

use AvinaCRM\Analytics\AnalyticsService;
use AvinaCRM\Rest\ApiResponse;
use WP_REST_Request;
use WP_REST_Response;

final class AnalyticsController
{
    private AnalyticsService $service;

    public function __construct()
    {
        $this->service = new AnalyticsService();
    }

    public function dashboard(WP_REST_Request $request): WP_REST_Response
    {
        $range = (string) ($request->get_param('range') ?: '30d');

        return ApiResponse::success($this->service->dashboard($range));
    }

    public function permissionCheck(): bool
    {
        return current_user_can('analytics.dashboard.view');
    }
}
