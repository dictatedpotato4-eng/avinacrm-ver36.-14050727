<?php

declare(strict_types=1);

namespace AvinaCRM\Rest\Controllers;

use AvinaCRM\Rest\ApiResponse;
use WP_REST_Request;
use WP_REST_Response;

final class AppDataController
{
    public function get(WP_REST_Request $request): WP_REST_Response
    {
        $data = get_option('avina_crm_app_data', []);
        
        if (empty($data) || !is_array($data)) {
            $data = [];
        }

        $deletedIds = get_option('avina_crm_deleted_ids', []);
        if (!is_array($deletedIds)) {
            $deletedIds = [];
        }

        // Clean out any previously deleted IDs from $data so they never appear
        if (!empty($deletedIds)) {
            $deletedSet = array_flip(array_map('strval', $deletedIds));
            $collections = ['leads', 'customers', 'receptions', 'tasks', 'tickets', 'contacts'];
            foreach ($collections as $col) {
                if (!empty($data[$col]) && is_array($data[$col])) {
                    $data[$col] = array_values(array_filter($data[$col], function($item) use ($deletedSet) {
                        $id = (string)($item['id'] ?? '');
                        return !isset($deletedSet[$id]);
                    }));
                }
            }
        }

        // Sync and merge contacts from MySQL table wp_avina_contacts
        $this->syncContactsFromDb($data, $deletedIds);

        // Sync and merge customers from MySQL table wp_avina_customers
        $this->syncCustomersFromDb($data, $deletedIds);

        return ApiResponse::success($data);
    }

    public function save(WP_REST_Request $request): WP_REST_Response
    {
        $params = $request->get_json_params() ?? [];
        if (!is_array($params)) {
            $params = [];
        }

        // Handle incoming deleted_ids
        $newDeletedIds = [];
        if (!empty($params['deleted_ids']) && is_array($params['deleted_ids'])) {
            $newDeletedIds = array_map('strval', $params['deleted_ids']);
        }
        $storedDeletedIds = get_option('avina_crm_deleted_ids', []);
        if (!is_array($storedDeletedIds)) {
            $storedDeletedIds = [];
        }
        $allDeletedIds = array_unique(array_merge($storedDeletedIds, $newDeletedIds));
        if (count($allDeletedIds) > count($storedDeletedIds)) {
            update_option('avina_crm_deleted_ids', array_slice($allDeletedIds, -5000), 'no');
        }

        // If items were marked deleted, archive them directly in MySQL tables
        if (!empty($newDeletedIds)) {
            $this->archiveDeletedItemsInDb($newDeletedIds);
        }

        // Convert any large base64 image strings to physical files on disk to prevent database bloating
        $this->convertBase64ImagesToUrls($params);

        $old_data = get_option('avina_crm_app_data', []);
        if (!is_array($old_data)) {
            $old_data = [];
        }

        // Resilient merging: NEVER let deleted items resurrect, and NEVER overwrite other operator records
        $this->mergeCollectionsSafely($old_data, $params, $allDeletedIds);

        // Upsert all leads directly into MySQL table wp_avina_contacts
        $this->upsertContactsToDb($params['leads'] ?? [], $allDeletedIds);

        // Upsert all customers directly into MySQL table wp_avina_customers
        $this->upsertCustomersToDb($params['customers'] ?? [], $allDeletedIds);

        // Detect new items and send email notification safely
        try {
            $this->detectAndNotifyNewItems($old_data, $params);
        } catch (\Throwable $e) {
            // Never allow notification errors to fail the save operation
        }

        // Purge any deleted IDs from params before updating option
        if (!empty($allDeletedIds)) {
            $deletedSet = array_flip(array_map('strval', $allDeletedIds));
            $collections = ['leads', 'customers', 'receptions', 'tasks', 'tickets', 'contacts'];
            foreach ($collections as $col) {
                if (!empty($params[$col]) && is_array($params[$col])) {
                    $params[$col] = array_values(array_filter($params[$col], function($item) use ($deletedSet) {
                        $id = (string)($item['id'] ?? '');
                        return !isset($deletedSet[$id]);
                    }));
                }
            }
        }

        update_option('avina_crm_app_data', $params, 'no');
        return ApiResponse::success(['ok' => true]);
    }

    private function convertBase64ImagesToUrls(array &$data): void
    {
        $upload_dir = wp_upload_dir();
        $target_dir = $upload_dir['basedir'] . '/avina-crm-docs';
        $target_url = $upload_dir['baseurl'] . '/avina-crm-docs';

        if (!file_exists($target_dir)) {
            wp_mkdir_p($target_dir);
        }

        array_walk_recursive($data, function (&$value) use ($target_dir, $target_url) {
            if (is_string($value) && strpos($value, 'data:image/') === 0 && strpos($value, ';base64,') !== false) {
                $parts = explode(';base64,', $value);
                $mime = str_replace('data:image/', '', $parts[0]);
                $ext = (strpos($mime, 'png') !== false) ? 'png' : 'jpg';
                $decoded = base64_decode($parts[1]);
                if ($decoded !== false && strlen($decoded) > 0) {
                    $filename = 'doc_' . time() . '_' . wp_generate_password(6, false) . '.' . $ext;
                    $filepath = $target_dir . '/' . $filename;
                    if (@file_put_contents($filepath, $decoded) !== false) {
                        $value = $target_url . '/' . $filename;
                    }
                }
            }
        });
    }

    private function detectAndNotifyNewItems(array $oldData, array $newData): void
    {
        $admin_email = get_option('admin_email');
        if (empty($admin_email)) {
            return;
        }

        // Helper to check if a new item is added by comparing IDs
        $find_new = function(string $key, array $oldItems, array $newItems) use ($admin_email) {
            $old_ids = array_column($oldItems, 'id');
            foreach ($newItems as $item) {
                if (!isset($item['id'])) {
                    continue;
                }
                if (!in_array($item['id'], $old_ids)) {
                    $this->sendNewItemNotificationEmail($admin_email, $key, $item);
                }
            }
        };

        $old_contacts = $oldData['contacts'] ?? [];
        $new_contacts = $newData['contacts'] ?? [];
        $find_new('contact', $old_contacts, $new_contacts);

        $old_customers = $oldData['customers'] ?? [];
        $new_customers = $newData['customers'] ?? [];
        $find_new('customer', $old_customers, $new_customers);

        $old_receptions = $oldData['receptions'] ?? [];
        $new_receptions = $newData['receptions'] ?? [];
        $find_new('reception', $old_receptions, $new_receptions);

        $old_leads = $oldData['leads'] ?? [];
        $new_leads = $newData['leads'] ?? [];
        $find_new('lead', $old_leads, $new_leads);

        // Task completion detection
        $old_tasks = $oldData['tasks'] ?? [];
        $new_tasks = $newData['tasks'] ?? [];
        
        $old_tasks_by_id = [];
        foreach ($old_tasks as $t) {
            if (isset($t['id'])) {
                $old_tasks_by_id[$t['id']] = $t;
            }
        }
        
        foreach ($new_tasks as $task) {
            if (!isset($task['id'])) {
                continue;
            }
            $old_task = $old_tasks_by_id[$task['id']] ?? null;
            if ($old_task) {
                $old_status = $old_task['statusId'] ?? '';
                $new_status = $task['statusId'] ?? '';
                
                $is_old_completed = ($old_status === 'col-3' || $old_status === 'col-4');
                $is_new_completed = ($new_status === 'col-3' || $new_status === 'col-4');
                
                if ($is_new_completed && !$is_old_completed) {
                    $this->sendTaskCompletedNotificationEmail($admin_email, $task);
                }
            }
        }
    }

    private function sendNewItemNotificationEmail(string $toEmail, string $type, array $item): void
    {
        $subject = '';
        $title = '';
        $details_html = '';

        if ($type === 'contact' || $type === 'lead') {
            $subject = '🔔 ثبت مخاطب جدید در سیستم آوینا CRM';
            $title = 'یک مخاطب جدید ثبت گردید';
            $name = $item['name'] ?? 'نامشخص';
            $phone = $item['phone'] ?? 'نامشخص';
            $email = $item['email'] ?? 'نامشخص';
            $source = $item['source'] ?? 'نامشخص';
            $details_html = "
                <tr><td style='padding: 8px; border-bottom: 1px solid #f0f4f8;'><strong>نام مخاطب:</strong></td><td style='padding: 8px; border-bottom: 1px solid #f0f4f8;'>{$name}</td></tr>
                <tr><td style='padding: 8px; border-bottom: 1px solid #f0f4f8;'><strong>شماره همراه:</strong></td><td style='padding: 8px; border-bottom: 1px solid #f0f4f8;'>{$phone}</td></tr>
                <tr><td style='padding: 8px; border-bottom: 1px solid #f0f4f8;'><strong>ایمیل:</strong></td><td style='padding: 8px; border-bottom: 1px solid #f0f4f8;'>{$email}</td></tr>
                <tr><td style='padding: 8px; border-bottom: 1px solid #f0f4f8;'><strong>منبع:</strong></td><td style='padding: 8px; border-bottom: 1px solid #f0f4f8;'>{$source}</td></tr>
            ";
        } elseif ($type === 'customer') {
            $subject = '🔔 ثبت مشتری جدید در سیستم آوینا CRM';
            $title = 'یک مشتری جدید ثبت گردید';
            $name = $item['name'] ?? 'نامشخص';
            $phone = $item['phone'] ?? 'نامشخص';
            $national_id = $item['nationalCode'] ?? ($item['nationalId'] ?? 'نامشخص');
            $details_html = "
                <tr><td style='padding: 8px; border-bottom: 1px solid #f0f4f8;'><strong>نام مشتری:</strong></td><td style='padding: 8px; border-bottom: 1px solid #f0f4f8;'>{$name}</td></tr>
                <tr><td style='padding: 8px; border-bottom: 1px solid #f0f4f8;'><strong>شماره همراه:</strong></td><td style='padding: 8px; border-bottom: 1px solid #f0f4f8;'>{$phone}</td></tr>
                <tr><td style='padding: 8px; border-bottom: 1px solid #f0f4f8;'><strong>کد ملی:</strong></td><td style='padding: 8px; border-bottom: 1px solid #f0f4f8;'>{$national_id}</td></tr>
            ";
        } elseif ($type === 'reception') {
            $subject = '🔔 ثبت پذیرش جدید دستگاه در سیستم آوینا CRM';
            $title = 'یک پذیرش جدید دستگاه ثبت گردید';
            $customer_name = $item['customerName'] ?? ($item['name'] ?? 'نامشخص');
            $device_model = $item['deviceModel'] ?? ($item['model'] ?? 'نامشخص');
            $request = $item['requestType'] ?? ($item['request'] ?? 'نامشخص');
            $phone = $item['phone'] ?? 'نامشخص';
            $details_html = "
                <tr><td style='padding: 8px; border-bottom: 1px solid #f0f4f8;'><strong>سفارش دهنده / مالک:</strong></td><td style='padding: 8px; border-bottom: 1px solid #f0f4f8;'>{$customer_name}</td></tr>
                <tr><td style='padding: 8px; border-bottom: 1px solid #f0f4f8;'><strong>دستگاه:</strong></td><td style='padding: 8px; border-bottom: 1px solid #f0f4f8;'>{$device_model}</td></tr>
                <tr><td style='padding: 8px; border-bottom: 1px solid #f0f4f8;'><strong>نوع درخواست:</strong></td><td style='padding: 8px; border-bottom: 1px solid #f0f4f8;'>{$request}</td></tr>
                <tr><td style='padding: 8px; border-bottom: 1px solid #f0f4f8;'><strong>شماره همراه:</strong></td><td style='padding: 8px; border-bottom: 1px solid #f0f4f8;'>{$phone}</td></tr>
            ";
        } elseif ($type === 'submission') {
            $subject = '📋 ثبت درخواست استخدام جدید در آوینا CRM';
            $title = 'یک درخواست استخدام جدید ثبت گردید';
            $name = $item['name'] ?? 'نامشخص';
            $position = $item['position'] ?? 'نامشخص';
            $mobile = $item['mobile'] ?? 'نامشخص';
            $resume = $item['resumeUrl'] ?? '#';
            $details_html = "
                <tr><td style='padding: 8px; border-bottom: 1px solid #f0f4f8;'><strong>نام و نام خانوادگی متقاضی:</strong></td><td style='padding: 8px; border-bottom: 1px solid #f0f4f8;'>{$name}</td></tr>
                <tr><td style='padding: 8px; border-bottom: 1px solid #f0f4f8;'><strong>عنوان شغلی درخواستی:</strong></td><td style='padding: 8px; border-bottom: 1px solid #f0f4f8;'>{$position}</td></tr>
                <tr><td style='padding: 8px; border-bottom: 1px solid #f0f4f8;'><strong>شماره همراه:</strong></td><td style='padding: 8px; border-bottom: 1px solid #f0f4f8;'>{$mobile}</td></tr>
                <tr><td style='padding: 8px; border-bottom: 1px solid #f0f4f8;'><strong>فایل رزومه / پیوست:</strong></td><td style='padding: 8px; border-bottom: 1px solid #f0f4f8;'><a href='{$resume}' target='_blank' style='color: #4f46e5; font-weight: bold;'>مشاهده رزومه</a></td></tr>
            ";
        } else {
            return;
        }

        // Send to manager email m.fulafi@yahoo.com as primary target + admin_email
        $recipients = array_filter(array_unique([$toEmail, 'm.fulafi@yahoo.com']));
        $headers = [
            'Content-Type: text/html; charset=UTF-8',
            'From: Avina CRM <no-reply@' . ($_SERVER['HTTP_HOST'] ?? 'localhost') . '>'
        ];

        // Beautiful RTL HTML Email template
        $body = "
        <div style='direction: rtl; text-align: right; font-family: Tahoma, Arial, sans-serif; padding: 20px; background-color: #f6f9fc;'>
            <div style='max-width: 600px; margin: 0 auto; background-color: #ffffff; border-radius: 12px; box-shadow: 0 4px 12px rgba(0,0,0,0.05); overflow: hidden; border: 1px solid #e1e8ed;'>
                <div style='background: linear-gradient(135deg, #6366f1 0%, #4f46e5 100%); color: #ffffff; padding: 24px; text-align: center;'>
                    <h2 style='margin: 0; font-size: 20px; font-weight: bold;'>سیستم هوشمند آوینا CRM</h2>
                    <p style='margin: 5px 0 0 0; font-size: 13px; opacity: 0.9;'>گزارش خودکار ثبت اطلاعات</p>
                </div>
                <div style='padding: 24px; color: #333333;'>
                    <h3 style='margin-top: 0; color: #4f46e5; font-size: 16px; border-bottom: 2px solid #f0f4f8; padding-bottom: 10px;'>{$title}</h3>
                    <table style='width: 100%; border-collapse: collapse; margin-top: 15px; font-size: 14px;'>
                        {$details_html}
                    </table>
                    <div style='margin-top: 25px; padding: 15px; background-color: #f8fafc; border-right: 4px solid #6366f1; border-radius: 4px; font-size: 12px; color: #555555;'>
                        این ایمیل به صورت خودکار جهت اطلاع‌رسانی به مدیریت کل سیستم ارسال شده است. برای مشاهده جزئیات بیشتر به پیشخوان مدیریت آوینا CRM مراجعه کنید.
                    </div>
                </div>
                <div style='background-color: #f1f5f9; padding: 15px; text-align: center; font-size: 11px; color: #64748b;'>
                    طراحی شده توسط دستیار هوشمند آوینا
                </div>
            </div>
        </div>
        ";

        foreach ($recipients as $recipient) {
            try {
                @wp_mail($recipient, $subject, $body, $headers);
            } catch (\Throwable $e) {}
        }
    }

    private function sendTaskCompletedNotificationEmail(string $toEmail, array $task): void
    {
        $subject = '✅ تکمیل وظیفه ارجاع شده در آوینا CRM';
        $title = 'یک وظیفه ارجاع شده به وضعیت تکمیل‌ شده تغییر یافت';
        
        $customer_name = $task['customerName'] ?? 'نامشخص';
        $project = $task['project'] ?? 'نامشخص';
        $notes = $task['notes'] ?? 'توضیحی ثبت نشده است.';
        
        $details_html = "
            <tr><td style='padding: 8px; border-bottom: 1px solid #f0f4f8;'><strong>عنوان کار / پروژه:</strong></td><td style='padding: 8px; border-bottom: 1px solid #f0f4f8;'>{$project}</td></tr>
            <tr><td style='padding: 8px; border-bottom: 1px solid #f0f4f8;'><strong>مشتری مربوطه:</strong></td><td style='padding: 8px; border-bottom: 1px solid #f0f4f8;'>{$customer_name}</td></tr>
            <tr><td style='padding: 8px; border-bottom: 1px solid #f0f4f8;'><strong>توضیحات / یادداشت:</strong></td><td style='padding: 8px; border-bottom: 1px solid #f0f4f8;'>{$notes}</td></tr>
        ";

        $headers = [
            'Content-Type: text/html; charset=UTF-8',
            'From: Avina CRM <no-reply@' . ($_SERVER['HTTP_HOST'] ?? 'localhost') . '>'
        ];

        $body = "
        <div style='direction: rtl; text-align: right; font-family: Tahoma, Arial, sans-serif; padding: 20px; background-color: #f6f9fc;'>
            <div style='max-width: 600px; margin: 0 auto; background-color: #ffffff; border-radius: 12px; box-shadow: 0 4px 12px rgba(0,0,0,0.05); overflow: hidden; border: 1px solid #e1e8ed;'>
                <div style='background: linear-gradient(135deg, #10b981 0%, #059669 100%); color: #ffffff; padding: 24px; text-align: center;'>
                    <h2 style='margin: 0; font-size: 20px; font-weight: bold;'>سیستم هوشمند آوینا CRM</h2>
                    <p style='margin: 5px 0 0 0; font-size: 13px; opacity: 0.9;'>اطلاع‌رسانی اتمام وظیفه</p>
                </div>
                <div style='padding: 24px; color: #333333;'>
                    <h3 style='margin-top: 0; color: #059669; font-size: 16px; border-bottom: 2px solid #f0f4f8; padding-bottom: 10px;'>{$title}</h3>
                    <table style='width: 100%; border-collapse: collapse; margin-top: 15px; font-size: 14px;'>
                        {$details_html}
                    </table>
                    <div style='margin-top: 25px; padding: 15px; background-color: #f8fafc; border-right: 4px solid #10b981; border-radius: 4px; font-size: 12px; color: #555555;'>
                        این کار توسط اپراتور به وضعیت نهایی تحویل/تسویه منتقل شده است. جهت بررسی گزارشات کامل به پنل مدیریت آوینا CRM مراجعه نمایید.
                    </div>
                </div>
                <div style='background-color: #f1f5f9; padding: 15px; text-align: center; font-size: 11px; color: #64748b;'>
                    طراحی شده توسط دستیار هوشمند آوینا
                </div>
            </div>
        </div>
        ";

        try {
            @wp_mail($toEmail, $subject, $body, $headers);
        } catch (\Throwable $e) {}
    }

    private function archiveDeletedItemsInDb(array $deletedIds): void
    {
        if (empty($deletedIds)) return;
        global $wpdb;
        $contactsTable = $wpdb->prefix . 'avina_contacts';
        $customersTable = $wpdb->prefix . 'avina_customers';
        $receptionsTable = $wpdb->prefix . 'avina_device_intakes';
        $tasksTable = $wpdb->prefix . 'avina_tasks';

        foreach ($deletedIds as $delId) {
            $strId = (string)$delId;
            $numId = (int)preg_replace('/\D+/', '', $strId);
            
            if ($numId > 0) {
                $wpdb->update($contactsTable, ['is_archived' => 1, 'updated_at' => current_time('mysql')], ['id' => $numId]);
                $wpdb->update($customersTable, ['is_archived' => 1, 'updated_at' => current_time('mysql')], ['id' => $numId]);
                $wpdb->update($tasksTable, ['is_archived' => 1, 'updated_at' => current_time('mysql')], ['id' => $numId]);
                $wpdb->delete($receptionsTable, ['id' => $numId]);
            }
        }
    }

    private function syncContactsFromDb(array &$data, array $deletedIds = []): void
    {
        global $wpdb;
        $table = $wpdb->prefix . 'avina_contacts';
        
        $tableCheck = $wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $table));
        if ($tableCheck !== $table) {
            return;
        }

        $deletedSet = !empty($deletedIds) ? array_flip(array_map('strval', $deletedIds)) : [];

        $rows = $wpdb->get_results("SELECT * FROM {$table} WHERE is_archived = 0 ORDER BY id DESC LIMIT 50000", ARRAY_A);
        if (empty($rows)) {
            return;
        }

        $existingLeads = is_array($data['leads'] ?? null) ? $data['leads'] : [];
        $leadMap = [];
        $phoneMap = [];

        foreach ($existingLeads as $lead) {
            $idKey = (string)($lead['id'] ?? '');
            if ($idKey !== '' && !isset($deletedSet[$idKey])) {
                $leadMap[$idKey] = $lead;
            }
            $cleanPhone = preg_replace('/\D+/', '', (string)($lead['mobile'] ?? ''));
            if ($cleanPhone !== '' && $idKey !== '' && !isset($deletedSet[$idKey])) {
                $phoneMap[$cleanPhone] = $idKey;
            }
        }

        foreach ($rows as $row) {
            $dbId = (string)$row['id'];
            if (isset($deletedSet[$dbId])) {
                continue;
            }

            $cleanPhone = preg_replace('/\D+/', '', (string)$row['phone']);
            
            $matchedKey = null;
            if (isset($leadMap[$dbId])) {
                $matchedKey = $dbId;
            } elseif ($cleanPhone !== '' && isset($phoneMap[$cleanPhone])) {
                $matchedKey = $phoneMap[$cleanPhone];
            }

            $reqs = !empty($row['product_or_service']) ? array_map('trim', explode(',', $row['product_or_service'])) : [];
            $history = [];
            if (!empty($row['last_call_result'])) {
                $history[] = [
                    'id' => 'fu-db-' . $dbId,
                    'date' => $row['updated_at'] ?: $row['created_at'],
                    'notes' => $row['last_call_result'],
                    'title' => 'نتیجه آخرین تماس / پیگیری'
                ];
            }

            $creatorUser = (string)($row['created_by_user_id'] ?: ($row['owner_user_id'] ?: 'admin'));

            $dbLead = [
                'id' => $dbId,
                'name' => $row['full_name'],
                'mobile' => $row['phone'],
                'job' => $row['job'] ?? '',
                'purpose' => $row['requirement_type'] ?: 'purchase',
                'requests' => $reqs,
                'status' => $row['lifecycle_stage'] === 'customer' ? 'completed' : ($row['lifecycle_stage'] === 'cancelled' ? 'canceled' : 'follow-up'),
                'followUpDate' => $row['followup_date'] ?? '',
                'cancellationReason' => '',
                'mood' => 'neutral',
                'purchaseProbability' => (int)($row['buying_probability'] ?? 3),
                'history' => $history,
                'createdBy' => $creatorUser,
                'createdById' => $creatorUser,
                'owner_user_id' => $creatorUser,
                'isCompleted' => $row['lifecycle_stage'] === 'customer',
                'createdAt' => $row['created_at'] ?: current_time('mysql'),
            ];

            if ($matchedKey !== null) {
                $merged = array_merge($dbLead, $leadMap[$matchedKey]);
                $merged['id'] = $dbId;
                // Preserve complete entered name - NEVER overwrite or truncate entered name!
                $enteredName = trim((string)($leadMap[$matchedKey]['name'] ?? ''));
                $merged['name'] = $enteredName !== '' ? $enteredName : $row['full_name'];
                $merged['mobile'] = $row['phone'];
                if (empty($merged['createdBy'])) {
                    $merged['createdBy'] = $creatorUser;
                }
                $leadMap[$matchedKey] = $merged;
            } else {
                $leadMap[$dbId] = $dbLead;
                if ($cleanPhone !== '') {
                    $phoneMap[$cleanPhone] = $dbId;
                }
            }
        }

        $data['leads'] = array_values($leadMap);
    }

    private function syncCustomersFromDb(array &$data, array $deletedIds = []): void
    {
        global $wpdb;
        $table = $wpdb->prefix . 'avina_customers';
        
        $tableCheck = $wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $table));
        if ($tableCheck !== $table) {
            return;
        }

        $deletedSet = !empty($deletedIds) ? array_flip(array_map('strval', $deletedIds)) : [];

        $rows = $wpdb->get_results("SELECT * FROM {$table} WHERE is_archived = 0 ORDER BY id DESC LIMIT 50000", ARRAY_A);
        if (empty($rows)) {
            return;
        }

        $existingCusts = is_array($data['customers'] ?? null) ? $data['customers'] : [];
        $custMap = [];
        $phoneMap = [];

        foreach ($existingCusts as $c) {
            $idKey = (string)($c['id'] ?? '');
            if ($idKey !== '' && !isset($deletedSet[$idKey])) {
                $custMap[$idKey] = $c;
            }
            $cleanPhone = preg_replace('/\D+/', '', (string)($c['mobile'] ?? ($c['phone'] ?? '')));
            if ($cleanPhone !== '' && $idKey !== '' && !isset($deletedSet[$idKey])) {
                $phoneMap[$cleanPhone] = $idKey;
            }
        }

        foreach ($rows as $row) {
            $dbId = (string)$row['id'];
            if (isset($deletedSet[$dbId])) {
                continue;
            }

            $cleanPhone = preg_replace('/\D+/', '', (string)$row['phone']);
            
            $matchedKey = null;
            if (isset($custMap[$dbId])) {
                $matchedKey = $dbId;
            } elseif ($cleanPhone !== '' && isset($phoneMap[$cleanPhone])) {
                $matchedKey = $phoneMap[$cleanPhone];
            }

            $creatorUser = (string)($row['created_by_user_id'] ?: ($row['owner_user_id'] ?: 'admin'));

            $dbCust = [
                'id' => $dbId,
                'name' => $row['full_name'],
                'mobile' => $row['phone'],
                'email' => $row['email'] ?? '',
                'nationalId' => '',
                'company' => '',
                'status' => $row['status'] ?: 'active',
                'createdBy' => $creatorUser,
                'createdById' => $creatorUser,
                'lastContact' => $row['created_at'] ?: current_time('mysql'),
            ];

            if ($matchedKey !== null) {
                $merged = array_merge($dbCust, $custMap[$matchedKey]);
                $merged['id'] = $dbId;
                $enteredName = trim((string)($custMap[$matchedKey]['name'] ?? ''));
                $merged['name'] = $enteredName !== '' ? $enteredName : $row['full_name'];
                $merged['mobile'] = $row['phone'];
                $custMap[$matchedKey] = $merged;
            } else {
                $custMap[$dbId] = $dbCust;
                if ($cleanPhone !== '') {
                    $phoneMap[$cleanPhone] = $dbId;
                }
            }
        }

        $data['customers'] = array_values($custMap);
    }

    private function mergeCollectionsSafely(array $oldData, array &$newData, array $deletedIds = []): void
    {
        $deletedSet = !empty($deletedIds) ? array_flip(array_map('strval', $deletedIds)) : [];
        $collectionsToMerge = ['leads', 'customers', 'receptions', 'tasks', 'invoices', 'products', 'tickets'];

        foreach ($collectionsToMerge as $key) {
            $oldItems = is_array($oldData[$key] ?? null) ? $oldData[$key] : [];
            $newItems = is_array($newData[$key] ?? null) ? $newData[$key] : [];

            // Build map of new items, filtering out deleted ones
            $itemMap = [];
            $phoneMap = [];
            foreach ($newItems as $item) {
                if (!is_array($item)) continue;
                $idKey = (string)($item['id'] ?? '');
                if ($idKey !== '' && !isset($deletedSet[$idKey])) {
                    $itemMap[$idKey] = $item;
                }
                $cleanPhone = preg_replace('/\D+/', '', (string)($item['mobile'] ?? ($item['phone'] ?? ($item['customerMobile'] ?? ''))));
                if ($cleanPhone !== '' && $idKey !== '' && !isset($deletedSet[$idKey])) {
                    $phoneMap[$cleanPhone] = $idKey;
                }
            }

            // Merge old items that are not in the new payload, provided they were NOT explicitly deleted
            foreach ($oldItems as $oldItem) {
                if (!is_array($oldItem)) continue;
                $idKey = (string)($oldItem['id'] ?? '');
                if ($idKey !== '' && isset($deletedSet[$idKey])) {
                    // DO NOT resurrect deleted item!
                    continue;
                }
                $cleanPhone = preg_replace('/\D+/', '', (string)($oldItem['mobile'] ?? ($oldItem['phone'] ?? ($oldItem['customerMobile'] ?? ''))));

                $exists = ($idKey !== '' && isset($itemMap[$idKey])) || ($cleanPhone !== '' && isset($phoneMap[$cleanPhone]));
                if (!$exists && $idKey !== '') {
                    $itemMap[$idKey] = $oldItem;
                    if ($cleanPhone !== '') {
                        $phoneMap[$cleanPhone] = $idKey;
                    }
                }
            }

            $newData[$key] = array_values($itemMap);
        }
    }

    private function upsertContactsToDb(array $leads, array $deletedIds = []): void
    {
        if (empty($leads)) return;

        $deletedSet = !empty($deletedIds) ? array_flip(array_map('strval', $deletedIds)) : [];
        global $wpdb;
        $table = $wpdb->prefix . 'avina_contacts';
        $tableCheck = $wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $table));
        if ($tableCheck !== $table) return;

        foreach ($leads as $lead) {
            if (!is_array($lead) || empty($lead['name']) || empty($lead['mobile'])) {
                continue;
            }

            $leadIdStr = (string)($lead['id'] ?? '');
            if ($leadIdStr !== '' && isset($deletedSet[$leadIdStr])) {
                continue;
            }

            $phone = sanitize_text_field((string)$lead['mobile']);
            $fullName = sanitize_text_field((string)$lead['name']);
            $job = sanitize_text_field((string)($lead['job'] ?? ''));
            $reqType = sanitize_key((string)($lead['purpose'] ?? 'purchase'));
            $reqs = is_array($lead['requests'] ?? null) ? implode(', ', $lead['requests']) : sanitize_text_field((string)($lead['requests'] ?? ''));
            $buyingProb = (int)($lead['purchaseProbability'] ?? 3);
            $followupDate = !empty($lead['followUpDate']) ? sanitize_text_field((string)$lead['followUpDate']) : null;
            $creatorId = (int)($lead['createdBy'] ?? ($lead['createdById'] ?? ($lead['owner_user_id'] ?? get_current_user_id())));
            $stage = ($lead['status'] ?? '') === 'completed' ? 'customer' : (($lead['status'] ?? '') === 'canceled' ? 'cancelled' : 'lead');

            $lastCallResult = '';
            if (!empty($lead['history']) && is_array($lead['history'])) {
                $lastNote = end($lead['history']);
                if (is_array($lastNote) && !empty($lastNote['notes'])) {
                    $lastCallResult = sanitize_textarea_field((string)$lastNote['notes']);
                }
            }

            // Check if existing by ID (if numeric) or by phone
            $existingId = 0;
            if (!empty($lead['id']) && is_numeric($lead['id'])) {
                $existingId = (int)$wpdb->get_var($wpdb->prepare("SELECT id FROM {$table} WHERE id = %d", (int)$lead['id']));
            }
            if ($existingId === 0 && !empty($phone)) {
                $existingId = (int)$wpdb->get_var($wpdb->prepare("SELECT id FROM {$table} WHERE phone = %s AND is_archived = 0 LIMIT 1", $phone));
            }

            $data = [
                'full_name' => $fullName,
                'phone' => $phone,
                'lifecycle_stage' => $stage,
                'job' => $job,
                'requirement_type' => $reqType,
                'product_or_service' => $reqs,
                'buying_probability' => $buyingProb,
                'followup_date' => $followupDate,
                'last_call_result' => $lastCallResult,
                'updated_at' => current_time('mysql'),
            ];

            if ($existingId > 0) {
                $wpdb->update($table, $data, ['id' => $existingId]);
            } else {
                $data['owner_user_id'] = $creatorId;
                $data['created_by_user_id'] = $creatorId;
                $data['created_at'] = current_time('mysql');
                $wpdb->insert($table, $data);
            }
        }
    }

    private function upsertCustomersToDb(array $customers, array $deletedIds = []): void
    {
        if (empty($customers)) return;

        $deletedSet = !empty($deletedIds) ? array_flip(array_map('strval', $deletedIds)) : [];
        global $wpdb;
        $table = $wpdb->prefix . 'avina_customers';
        $tableCheck = $wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $table));
        if ($tableCheck !== $table) return;

        foreach ($customers as $cust) {
            if (!is_array($cust) || empty($cust['name']) || empty($cust['mobile'])) {
                continue;
            }

            $custIdStr = (string)($cust['id'] ?? '');
            if ($custIdStr !== '' && isset($deletedSet[$custIdStr])) {
                continue;
            }

            $phone = sanitize_text_field((string)$cust['mobile']);
            $fullName = sanitize_text_field((string)$cust['name']);
            $email = sanitize_email((string)($cust['email'] ?? ''));
            $status = sanitize_text_field((string)($cust['status'] ?? 'active'));
            $creatorId = (int)($cust['createdBy'] ?? ($cust['createdById'] ?? get_current_user_id()));

            $existingId = 0;
            if (!empty($cust['id']) && is_numeric($cust['id'])) {
                $existingId = (int)$wpdb->get_var($wpdb->prepare("SELECT id FROM {$table} WHERE id = %d", (int)$cust['id']));
            }
            if ($existingId === 0 && !empty($phone)) {
                $existingId = (int)$wpdb->get_var($wpdb->prepare("SELECT id FROM {$table} WHERE phone = %s AND is_archived = 0 LIMIT 1", $phone));
            }

            $data = [
                'full_name' => $fullName,
                'phone' => $phone,
                'email' => $email,
                'status' => $status,
                'updated_at' => current_time('mysql'),
            ];

            if ($existingId > 0) {
                $wpdb->update($table, $data, ['id' => $existingId]);
            } else {
                $data['owner_user_id'] = $creatorId;
                $data['created_by_user_id'] = $creatorId;
                $data['created_at'] = current_time('mysql');
                $wpdb->insert($table, $data);
            }
        }
    }

    public function permissionCheck(): bool
    {
        return is_user_logged_in();
    }
}
