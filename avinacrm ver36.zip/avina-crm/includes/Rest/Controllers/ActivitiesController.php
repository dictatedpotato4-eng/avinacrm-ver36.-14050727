<?php

declare(strict_types=1);

namespace AvinaCRM\Rest\Controllers;

use AvinaCRM\Activities\ActivityService;
use AvinaCRM\Rest\ApiResponse;
use WP_Error;
use WP_REST_Request;
use WP_REST_Response;

final class ActivitiesController
{
    private ActivityService $service;

    public function __construct()
    {
        $this->service = new ActivityService();
    }

    public function list(WP_REST_Request $request): WP_REST_Response
    {
        $filters = [
            'related_type' => (string) $request->get_param('related_type'),
            'related_id' => $request->get_param('related_id'),
            'kind' => (string) $request->get_param('kind'),
            'pending_only' => $request->get_param('pending_only'),
        ];

        return ApiResponse::success($this->service->list($filters));
    }

    public function viewPermissionCheck(): bool
    {
        return \AvinaCRM\Support\Scope::hasModulePermission('tasks') || \AvinaCRM\Support\Scope::hasModulePermission('dashboard') || current_user_can('activities.activity.view');
    }

    public function create(WP_REST_Request $request)
    {
        $params = $request->get_json_params() ?? [];
        $result = $this->service->create($params, get_current_user_id());

        return $result instanceof WP_Error ? ApiResponse::fromWpError($result) : ApiResponse::success($result, 201);
    }

    public function createPermissionCheck(): bool
    {
        return \AvinaCRM\Support\Scope::hasModulePermission('tasks') || \AvinaCRM\Support\Scope::hasModulePermission('dashboard') || current_user_can('activities.activity.create');
    }

    public function complete(WP_REST_Request $request)
    {
        $result = $this->service->complete((int) $request->get_param('id'), get_current_user_id());

        return $result instanceof WP_Error ? ApiResponse::fromWpError($result) : ApiResponse::success(['ok' => true]);
    }

    public function completePermissionCheck(): bool
    {
        return \AvinaCRM\Support\Scope::hasModulePermission('tasks') || \AvinaCRM\Support\Scope::hasModulePermission('dashboard') || current_user_can('activities.activity.complete');
    }
}
