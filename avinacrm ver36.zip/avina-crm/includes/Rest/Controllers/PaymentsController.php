<?php

declare(strict_types=1);

namespace AvinaCRM\Rest\Controllers;

use AvinaCRM\Payments\PaymentService;
use AvinaCRM\Rest\ApiResponse;
use WP_Error;
use WP_REST_Request;
use WP_REST_Response;

final class PaymentsController
{
    private PaymentService $service;

    public function __construct()
    {
        $this->service = new PaymentService();
    }

    public function list(WP_REST_Request $request): WP_REST_Response
    {
        return ApiResponse::success($this->service->listForInvoice((int) $request->get_param('id')));
    }

    public function viewPermissionCheck(): bool
    {
        return current_user_can('payments.payment.view');
    }

    public function record(WP_REST_Request $request)
    {
        $params = $request->get_json_params() ?? [];
        $result = $this->service->record((int) $request->get_param('id'), $params, get_current_user_id());

        return $result instanceof WP_Error ? ApiResponse::fromWpError($result) : ApiResponse::success($result, 201);
    }

    public function createPermissionCheck(): bool
    {
        return current_user_can('payments.payment.create');
    }
}
