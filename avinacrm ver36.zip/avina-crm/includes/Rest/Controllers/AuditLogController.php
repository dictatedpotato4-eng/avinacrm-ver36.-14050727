<?php

declare(strict_types=1);

namespace AvinaCRM\Rest\Controllers;

use AvinaCRM\AuditLog\AuditLogService;
use AvinaCRM\Rest\ApiResponse;
use WP_REST_Request;
use WP_REST_Response;

final class AuditLogController
{
    private AuditLogService $service;

    public function __construct()
    {
        $this->service = new AuditLogService();
    }

    public function list(WP_REST_Request $request): WP_REST_Response
    {
        $filters = [
            'actor_user_id' => $request->get_param('actor_user_id'),
            'object_type' => (string) $request->get_param('object_type'),
            'action' => (string) $request->get_param('action'),
            'since' => (string) $request->get_param('since'),
            'until' => (string) $request->get_param('until'),
            'page' => $request->get_param('page'),
            'per_page' => $request->get_param('per_page'),
        ];

        return ApiResponse::success($this->service->list($filters));
    }

    public function permissionCheck(): bool
    {
        return current_user_can('audit.log.view');
    }
}
