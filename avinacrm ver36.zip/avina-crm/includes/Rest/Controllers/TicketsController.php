<?php

declare(strict_types=1);

namespace AvinaCRM\Rest\Controllers;

use AvinaCRM\Rest\ApiResponse;
use AvinaCRM\Tickets\TicketService;
use WP_Error;
use WP_REST_Request;
use WP_REST_Response;

final class TicketsController
{
    private TicketService $service;

    public function __construct()
    {
        $this->service = new TicketService();
    }

    public function list(WP_REST_Request $request): WP_REST_Response
    {
        $filters = ['status' => (string) $request->get_param('status')];

        return ApiResponse::success($this->service->list($filters));
    }

    public function get(WP_REST_Request $request)
    {
        $ticketId = (int) $request->get_param('id');
        $item = $this->service->find($ticketId);

        if ($item === null) {
            return ApiResponse::error('avina_crm_ticket_not_found', __('درخواست موردنظر یافت نشد.', 'avina-crm'), 404);
        }

        $this->service->markRead($ticketId, get_current_user_id());

        return ApiResponse::success($item);
    }

    public function viewPermissionCheck(): bool
    {
        return \AvinaCRM\Support\Scope::hasModulePermission('tickets') || current_user_can('tickets.ticket.view');
    }

    public function create(WP_REST_Request $request)
    {
        $params = $request->get_json_params() ?? [];
        $result = $this->service->create($params, get_current_user_id());

        return $result instanceof WP_Error ? ApiResponse::fromWpError($result) : ApiResponse::success($result, 201);
    }

    public function createPermissionCheck(): bool
    {
        return \AvinaCRM\Support\Scope::hasModulePermission('tickets') || current_user_can('tickets.ticket.create');
    }

    public function reply(WP_REST_Request $request)
    {
        $params = $request->get_json_params() ?? [];
        $result = $this->service->reply((int) $request->get_param('id'), (string) ($params['body'] ?? ''), get_current_user_id());

        return $result instanceof WP_Error ? ApiResponse::fromWpError($result) : ApiResponse::success($result, 201);
    }

    public function replyPermissionCheck(): bool
    {
        return \AvinaCRM\Support\Scope::hasModulePermission('tickets') || current_user_can('tickets.ticket.reply');
    }

    public function changeStatus(WP_REST_Request $request)
    {
        $params = $request->get_json_params() ?? [];
        $result = $this->service->changeStatus((int) $request->get_param('id'), (string) ($params['status'] ?? ''), get_current_user_id());

        return $result instanceof WP_Error ? ApiResponse::fromWpError($result) : ApiResponse::success(['ok' => true]);
    }

    public function statusPermissionCheck(): bool
    {
        return \AvinaCRM\Support\Scope::hasModulePermission('tickets') || current_user_can('tickets.ticket.manage_status') || current_user_can('tickets.ticket.view');
    }
}
