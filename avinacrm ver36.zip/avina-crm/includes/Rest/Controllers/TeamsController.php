<?php

declare(strict_types=1);

namespace AvinaCRM\Rest\Controllers;

use AvinaCRM\Rest\ApiResponse;
use AvinaCRM\Teams\TeamService;
use WP_Error;
use WP_REST_Request;
use WP_REST_Response;

final class TeamsController
{
    private TeamService $service;

    public function __construct()
    {
        $this->service = new TeamService();
    }

    public function list(WP_REST_Request $request): WP_REST_Response
    {
        return ApiResponse::success($this->service->list());
    }

    public function viewPermissionCheck(): bool
    {
        return current_user_can('teams.team.view');
    }

    public function create(WP_REST_Request $request)
    {
        $params = $request->get_json_params() ?? [];
        $result = $this->service->create((string) ($params['name'] ?? ''), (string) ($params['description'] ?? ''), get_current_user_id());

        return $result instanceof WP_Error ? ApiResponse::fromWpError($result) : ApiResponse::success($result, 201);
    }

    public function createPermissionCheck(): bool
    {
        return current_user_can('teams.team.create');
    }

    public function addMember(WP_REST_Request $request)
    {
        $params = $request->get_json_params() ?? [];
        $result = $this->service->addMember(
            (int) $request->get_param('id'),
            (int) ($params['user_id'] ?? 0),
            (string) ($params['role_in_team'] ?? 'member'),
            get_current_user_id()
        );

        return $result instanceof WP_Error ? ApiResponse::fromWpError($result) : ApiResponse::success(['ok' => true]);
    }

    public function removeMember(WP_REST_Request $request)
    {
        $result = $this->service->removeMember(
            (int) $request->get_param('id'),
            (int) $request->get_param('user_id'),
            get_current_user_id()
        );

        return $result instanceof WP_Error ? ApiResponse::fromWpError($result) : ApiResponse::success(['ok' => true]);
    }

    public function manageMembersPermissionCheck(): bool
    {
        return current_user_can('teams.team.manage_members');
    }

    public function update(WP_REST_Request $request)
    {
        $params = $request->get_json_params() ?? [];
        $result = $this->service->update((int) $request->get_param('id'), $params, get_current_user_id());

        return $result instanceof WP_Error ? ApiResponse::fromWpError($result) : ApiResponse::success(['ok' => true]);
    }

    public function updatePermissionCheck(): bool
    {
        return current_user_can('teams.team.update');
    }
}
