<?php

declare(strict_types=1);

namespace AvinaCRM\Rest;

use WP_Error;
use WP_REST_Response;

/**
 * Preserves the legacy application's {ok, data} / {ok:false, error}
 * envelope shape (Stage 1 §9), so a future port of the existing frontend
 * pages needs no change to their response-handling logic — only the base
 * URL and the auth header change (X-WP-Nonce instead of X-CSRF-Token).
 */
final class ApiResponse
{
    public static function success($data = null, int $status = 200): WP_REST_Response
    {
        return new WP_REST_Response(['ok' => true, 'data' => $data], $status);
    }

    public static function error(string $code, string $message, int $status = 400, array $context = []): WP_REST_Response
    {
        $body = [
            'ok' => false,
            'error' => ['code' => $code, 'message' => $message],
        ];

        if (!empty($context)) {
            $body['error']['context'] = $context;
        }

        return new WP_REST_Response($body, $status);
    }

    public static function fromWpError(WP_Error $error): WP_REST_Response
    {
        $status = (int) ($error->get_error_data()['status'] ?? 400);

        return self::error($error->get_error_code(), $error->get_error_message(), $status);
    }
}
