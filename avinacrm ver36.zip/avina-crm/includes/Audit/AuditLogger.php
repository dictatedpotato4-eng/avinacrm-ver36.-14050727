<?php

declare(strict_types=1);

namespace AvinaCRM\Audit;

/**
 * Writes to {prefix}avina_audit_log. Every write goes through
 * $wpdb->insert(), which parameterizes values internally (WordPress's
 * equivalent of $wpdb->prepare() for inserts) — no raw SQL string
 * concatenation anywhere in this class.
 *
 * Secret redaction: before/after state arrays are scanned for any key
 * matching a known-sensitive pattern (api_key, password, secret, token,
 * webhook, dispatch_token, credential) and that value is replaced with a
 * fixed redaction marker before being JSON-encoded and stored. This
 * mirrors the legacy AuditLogger's redaction of fields like
 * 'totp_secret' and generalizes it, since Stage 2 introduces settings
 * that can hold secrets (Stage 1 decision #2 / Stage 2 decision #2).
 */
final class AuditLogger
{
    private const REDACTED = '[REDACTED]';

    /** @var array<int, string> lowercase substrings that mark a key as sensitive */
    private const SENSITIVE_KEY_PATTERNS = [
        'password',
        'secret',
        'api_key',
        'apikey',
        'token',
        'credential',
        'private_key',
    ];

    /**
     * @param array<string, mixed>|null $before
     * @param array<string, mixed>|null $after
     */
    public function record(
        ?int $actorUserId,
        string $action,
        ?string $objectType = null,
        ?string $objectId = null,
        ?array $before = null,
        ?array $after = null
    ): void {
        global $wpdb;

        $wpdb->insert(
            $wpdb->prefix . 'avina_audit_log',
            [
                'actor_user_id' => $actorUserId,
                'action' => $action,
                'object_type' => $objectType,
                'object_id' => $objectId,
                'before_state' => $before !== null ? wp_json_encode(self::redact($before)) : null,
                'after_state' => $after !== null ? wp_json_encode(self::redact($after)) : null,
                'ip_address' => self::clientIp(),
                'user_agent' => substr((string) ($_SERVER['HTTP_USER_AGENT'] ?? ''), 0, 255),
                'created_at' => current_time('mysql'),
            ],
            ['%d', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s']
        );

        // Send email notification to admin on key CRM actions
        $monitoredActions = [
            'contacts.contact.create' => 'مخاطب جدید ثبت شد',
            'contacts.contact.convert' => 'مخاطب به مشتری تبدیل شد',
            'customers.customer.create' => 'مشتری جدید ثبت شد',
            'reception.reception.create' => 'پذیرش حضوری جدید ثبت شد',
            'deals.deal.create' => 'معامله جدید ثبت شد',
            'deals.deal.change_stage' => 'مرحله معامله تغییر کرد',
            'deals.deal.stage_changed' => 'مرحله معامله تغییر کرد',
            'invoices.invoice.create' => 'فاکتور جدید ثبت شد',
            'payments.payment.record' => 'پرداخت جدید ثبت شد',
            'tasks.task.create' => 'وظیفه جدید ثبت شد',
            'tasks.task.update' => 'وظیفه به‌روزرسانی شد',
        ];

        if (array_key_exists($action, $monitoredActions)) {
            $adminEmail = get_option('admin_email');
            if (!empty($adminEmail)) {
                $subject = 'آوینا CRM — ' . $monitoredActions[$action];
                $actorName = 'سیستم / اپراتور ناشناس';
                if ($actorUserId) {
                    $userObj = get_user_by('id', $actorUserId);
                    if ($userObj) {
                        $actorName = $userObj->display_name . ' (' . $userObj->user_login . ')';
                    }
                }
                
                $body = "سلام مدیر محترم،\n\n";
                $body .= "رویداد جدیدی در سامانه آوینا CRM ثبت شده است:\n\n";
                $body .= "نوع رویداد: " . $monitoredActions[$action] . "\n";
                $body .= "توسط کاربر: " . $actorName . "\n";
                $body .= "شناسه مورد: " . ($objectId ?? 'نامشخص') . "\n";
                $body .= "زمان ثبت: " . current_time('mysql') . "\n";
                $body .= "IP کاربر: " . self::clientIp() . "\n\n";
                
                if ($after !== null) {
                    $body .= "توضیحات و مقادیر ثبت‌شده:\n";
                    foreach (self::redact($after) as $k => $v) {
                        if (is_array($v)) {
                            $v = json_encode($v, JSON_UNESCAPED_UNICODE);
                        }
                        $body .= "- $k: $v\n";
                    }
                    $body .= "\n";
                }
                
                try {
                    @wp_mail($adminEmail, $subject, $body);
                } catch (\Throwable $e) {
                    // Ignored if server has PHP mail() function disabled
                }
            }
        }
    }

    /**
     * @param array<string, mixed> $data
     * @return array<string, mixed>
     */
    private static function redact(array $data): array
    {
        $redacted = [];

        foreach ($data as $key => $value) {
            $lowerKey = strtolower((string) $key);
            $isSensitive = false;

            foreach (self::SENSITIVE_KEY_PATTERNS as $pattern) {
                if (str_contains($lowerKey, $pattern)) {
                    $isSensitive = true;
                    break;
                }
            }

            if ($isSensitive) {
                $redacted[$key] = self::REDACTED;
            } elseif (is_array($value)) {
                $redacted[$key] = self::redact($value);
            } else {
                $redacted[$key] = $value;
            }
        }

        return $redacted;
    }

    private static function clientIp(): string
    {
        $ip = $_SERVER['REMOTE_ADDR'] ?? '';

        return substr((string) $ip, 0, 45);
    }
}
