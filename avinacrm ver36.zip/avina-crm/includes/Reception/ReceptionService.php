<?php

declare(strict_types=1);

namespace AvinaCRM\Reception;

use AvinaCRM\Audit\AuditLogger;
use WP_Error;

final class ReceptionService
{
    public const STATUSES = ['pending', 'inspecting', 'repaired', 'delivered', 'cancelled'];

    private AuditLogger $audit;

    public function __construct(?AuditLogger $audit = null)
    {
        $this->audit = $audit ?? new AuditLogger();
    }

    public function list(array $filters): array
    {
        global $wpdb;
        $table = $wpdb->prefix . 'avina_device_intakes';

        $where = ['1=1'];

        if (!empty($filters['status']) && in_array($filters['status'], self::STATUSES, true)) {
            $where[] = $wpdb->prepare('status = %s', $filters['status']);
        }

        if (!empty($filters['search'])) {
            $search = '%' . $wpdb->esc_like(sanitize_text_field($filters['search'])) . '%';
            $where[] = $wpdb->prepare('(customer_name LIKE %s OR device_model LIKE %s)', $search, $search);
        }

        $whereSql = implode(' AND ', $where);

        $rows = $wpdb->get_results(
            "SELECT * FROM {$table} WHERE {$whereSql} ORDER BY intake_date DESC, created_at DESC LIMIT 200",
            ARRAY_A
        );

        return array_map([$this, 'decorate'], $rows ?: []);
    }

    public function find(int $id): ?array
    {
        global $wpdb;
        $table = $wpdb->prefix . 'avina_device_intakes';

        $row = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table} WHERE id = %d", $id), ARRAY_A);

        if ($row === null) {
            return null;
        }

        return $this->decorate($row);
    }

    public function create(array $data, int $actorUserId)
    {
        $customerName = sanitize_text_field($data['customer_name'] ?? '');
        $deviceModel = sanitize_text_field($data['device_model'] ?? '');
        $intakeDate = sanitize_text_field($data['intake_date'] ?? current_time('Y-m-d'));
        $issue = sanitize_textarea_field($data['issue'] ?? '');

        if ($customerName === '' || $deviceModel === '' || $issue === '') {
            return new WP_Error('avina_crm_invalid_intake', __('پر کردن نام مشتری، مدل دستگاه و مشکل دستگاه الزامی است.', 'avina-crm'), ['status' => 400]);
        }

        global $wpdb;
        $table = $wpdb->prefix . 'avina_device_intakes';

        $wpdb->insert(
            $table,
            [
                'customer_name' => $customerName,
                'device_model' => $deviceModel,
                'intake_date' => $intakeDate,
                'issue' => $issue,
                'accessories' => sanitize_text_field($data['accessories'] ?? ''),
                'status' => 'pending',
                'created_by_user_id' => $actorUserId,
                'created_at' => current_time('mysql'),
            ],
            ['%s', '%s', '%s', '%s', '%s', '%s', '%d', '%s']
        );

        $id = (int) $wpdb->insert_id;

        $this->audit->record($actorUserId, 'reception.intake.create', 'intake', (string) $id, null, ['customer_name' => $customerName, 'device_model' => $deviceModel]);

        return ['id' => $id];
    }

    public function update(int $id, array $data, int $actorUserId)
    {
        global $wpdb;
        $table = $wpdb->prefix . 'avina_device_intakes';

        $existing = $this->find($id);
        if (!$existing) {
            return new WP_Error('avina_crm_intake_not_found', __('رکورد پذیرش یافت نشد.', 'avina-crm'), ['status' => 404]);
        }

        $fields = [];
        $formats = [];

        foreach (['customer_name' => '%s', 'device_model' => '%s', 'intake_date' => '%s', 'issue' => '%s', 'accessories' => '%s', 'status' => '%s'] as $key => $format) {
            if (isset($data[$key])) {
                $fields[$key] = $key === 'issue' ? sanitize_textarea_field($data[$key]) : sanitize_text_field($data[$key]);
                $formats[] = $format;
            }
        }

        if (empty($fields)) {
            return true;
        }

        $wpdb->update($table, $fields, ['id' => $id], $formats, ['%d']);

        $this->audit->record($actorUserId, 'reception.intake.update', 'intake', (string) $id, $existing, $fields);

        return true;
    }

    public function changeStatus(int $id, string $newStatus, int $actorUserId)
    {
        return $this->update($id, ['status' => $newStatus], $actorUserId);
    }

    private function decorate(array $row): array
    {
        $row['id'] = (int) $row['id'];
        $row['created_by_user_id'] = $row['created_by_user_id'] !== null ? (int) $row['created_by_user_id'] : null;
        return $row;
    }
}
