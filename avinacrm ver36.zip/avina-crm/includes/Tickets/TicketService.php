<?php

declare(strict_types=1);

namespace AvinaCRM\Tickets;

use AvinaCRM\Audit\AuditLogger;
use AvinaCRM\Notifications\NotificationService;
use AvinaCRM\Support\Scope;
use WP_Error;

final class TicketService
{
    public const PRIORITIES = ['low', 'normal', 'high', 'urgent'];
    public const STATUSES = ['open', 'in_progress', 'resolved', 'closed'];

    private AuditLogger $audit;
    private NotificationService $notifications;

    public function __construct(?AuditLogger $audit = null, ?NotificationService $notifications = null)
    {
        $this->audit = $audit ?? new AuditLogger();
        $this->notifications = $notifications ?? new NotificationService();
    }

    /**
     * A ticket is visible only to its sender, its recipient, a member of
     * its team, or a manager — object-level authorization enforced in
     * the query itself, not filtered client-side.
     */
    public function list(array $filters): array
    {
        global $wpdb;
        $table = $wpdb->prefix . 'avina_tickets';
        $userId = get_current_user_id();

        $where = ['1=1'];

        if (!current_user_can('manage_options') && !current_user_can('tickets.ticket.manage_status')) {
            $teamIds = Scope::teamIdsForUser($userId);
            $teamClause = !empty($teamIds) ? 'team_id IN (' . implode(',', array_map('intval', $teamIds)) . ')' : '1=0';
            $where[] = $wpdb->prepare('(sender_user_id = %d OR recipient_user_id = %d OR ', $userId, $userId) . $teamClause . ')';
        }

        if (!empty($filters['status']) && in_array($filters['status'], self::STATUSES, true)) {
            $where[] = $wpdb->prepare('status = %s', $filters['status']);
        }

        $whereSql = implode(' AND ', $where);

        $rows = $wpdb->get_results(
            "SELECT * FROM {$table} WHERE {$whereSql} ORDER BY FIELD(priority,'urgent','high','normal','low'), created_at DESC LIMIT 200",
            ARRAY_A
        );

        return array_map([$this, 'decorate'], $rows ?: []);
    }

    public function find(int $id): ?array
    {
        $row = $this->rawFind($id);

        if ($row === null || !$this->canView($row)) {
            return null;
        }

        $row = $this->decorate($row);
        $row['replies'] = $this->repliesFor($id);

        return $row;
    }

    /**
     * @return array{id: int}|WP_Error
     */
    public function create(array $data, int $actorUserId)
    {
        $subject = sanitize_text_field($data['subject'] ?? '');
        $body = sanitize_textarea_field($data['body'] ?? '');

        if ($subject === '' || $body === '') {
            return new WP_Error('avina_crm_invalid_ticket', __('موضوع و متن درخواست الزامی است.', 'avina-crm'), ['status' => 400]);
        }

        $recipientUserId = !empty($data['recipient_user_id']) ? (int) $data['recipient_user_id'] : null;
        if ($recipientUserId !== null && get_user_by('id', $recipientUserId) === false) {
            return new WP_Error('avina_crm_invalid_recipient', __('گیرنده انتخاب‌شده معتبر نیست.', 'avina-crm'), ['status' => 400]);
        }

        $teamId = !empty($data['team_id']) ? (int) $data['team_id'] : null;

        if ($recipientUserId === null && $teamId === null) {
            return new WP_Error('avina_crm_invalid_ticket', __('باید یک گیرنده یا تیم مشخص شود.', 'avina-crm'), ['status' => 400]);
        }

        global $wpdb;
        $table = $wpdb->prefix . 'avina_tickets';

        $wpdb->insert(
            $table,
            [
                'subject' => $subject,
                'body' => $body,
                'sender_user_id' => $actorUserId,
                'recipient_user_id' => $recipientUserId,
                'team_id' => $teamId,
                'priority' => in_array($data['priority'] ?? '', self::PRIORITIES, true) ? $data['priority'] : 'normal',
                'status' => 'open',
                'created_at' => current_time('mysql'),
                'updated_at' => current_time('mysql'),
            ],
            ['%s', '%s', '%d', '%d', '%d', '%s', '%s', '%s', '%s']
        );

        $id = (int) $wpdb->insert_id;

        if ($recipientUserId !== null) {
            $this->notifications->notifyUser($recipientUserId, 'ticket_created', sprintf(__('درخواست جدید: %s', 'avina-crm'), $subject), $body, 'ticket', $id);
        }

        $this->audit->record($actorUserId, 'tickets.ticket.create', 'ticket', (string) $id, null, ['subject' => $subject]);

        do_action('avina_crm/ticket_created', $id);

        return ['id' => $id];
    }

    /**
     * @return array{id: int}|WP_Error
     */
    public function reply(int $ticketId, string $body, int $actorUserId)
    {
        $ticket = $this->rawFind($ticketId);

        if ($ticket === null || !$this->canView($ticket)) {
            return new WP_Error('avina_crm_ticket_not_found', __('درخواست موردنظر یافت نشد.', 'avina-crm'), ['status' => 404]);
        }

        $body = sanitize_textarea_field($body);

        if ($body === '') {
            return new WP_Error('avina_crm_invalid_reply', __('متن پاسخ نمی‌تواند خالی باشد.', 'avina-crm'), ['status' => 400]);
        }

        global $wpdb;
        $table = $wpdb->prefix . 'avina_ticket_replies';

        $wpdb->insert(
            $table,
            [
                'ticket_id' => $ticketId,
                'author_user_id' => $actorUserId,
                'body' => $body,
                'created_at' => current_time('mysql'),
            ],
            ['%d', '%d', '%s', '%s']
        );

        $id = (int) $wpdb->insert_id;

        $wpdb->update($wpdb->prefix . 'avina_tickets', ['updated_at' => current_time('mysql')], ['id' => $ticketId], ['%s'], ['%d']);

        $notifyTarget = (int) $ticket['sender_user_id'] === $actorUserId ? (int) ($ticket['recipient_user_id'] ?? 0) : (int) $ticket['sender_user_id'];
        if ($notifyTarget > 0) {
            $this->notifications->notifyUser($notifyTarget, 'ticket_reply', sprintf(__('پاسخ جدید در درخواست: %s', 'avina-crm'), $ticket['subject']), $body, 'ticket', $ticketId);
        }

        $this->audit->record($actorUserId, 'tickets.ticket.reply', 'ticket', (string) $ticketId, null, ['reply_id' => $id]);

        return ['id' => $id];
    }

    /**
     * @return true|WP_Error
     */
    public function changeStatus(int $ticketId, string $status, int $actorUserId)
    {
        if (!in_array($status, self::STATUSES, true)) {
            return new WP_Error('avina_crm_invalid_status', __('وضعیت انتخاب‌شده معتبر نیست.', 'avina-crm'), ['status' => 400]);
        }

        $ticket = $this->rawFind($ticketId);

        if ($ticket === null) {
            return new WP_Error('avina_crm_ticket_not_found', __('درخواست موردنظر یافت نشد.', 'avina-crm'), ['status' => 404]);
        }

        // Status-lifecycle changes require the dedicated capability, not
        // mere visibility — a sender/team member who can see and reply to
        // a ticket cannot unilaterally close it unless separately
        // authorized, mirroring the recipient/manager-driven lifecycle a
        // real internal-ticket system needs.
        if (!current_user_can('tickets.ticket.manage_status') && (int) $ticket['recipient_user_id'] !== $actorUserId) {
            return new WP_Error('avina_crm_forbidden', __('شما اجازه تغییر وضعیت این درخواست را ندارید.', 'avina-crm'), ['status' => 403]);
        }

        global $wpdb;
        $wpdb->update(
            $wpdb->prefix . 'avina_tickets',
            ['status' => $status, 'updated_at' => current_time('mysql')],
            ['id' => $ticketId],
            ['%s', '%s'],
            ['%d']
        );

        $this->audit->record($actorUserId, 'tickets.ticket.status_change', 'ticket', (string) $ticketId, ['status' => $ticket['status']], ['status' => $status]);

        return true;
    }

    public function markRead(int $ticketId, int $actorUserId): void
    {
        global $wpdb;
        $table = $wpdb->prefix . 'avina_ticket_participant_state';

        $wpdb->query(
            $wpdb->prepare(
                "INSERT INTO {$table} (ticket_id, user_id, last_read_at) VALUES (%d, %d, NOW())
                 ON DUPLICATE KEY UPDATE last_read_at = NOW()",
                $ticketId,
                $actorUserId
            )
        );
    }

    private function canView(array $ticket): bool
    {
        if (current_user_can('manage_options') || current_user_can('tickets.ticket.manage_status')) {
            return true;
        }

        $userId = get_current_user_id();

        if ((int) $ticket['sender_user_id'] === $userId || (int) ($ticket['recipient_user_id'] ?? 0) === $userId) {
            return true;
        }

        if (!empty($ticket['team_id']) && Scope::isTeamMember($userId, (int) $ticket['team_id'])) {
            return true;
        }

        return false;
    }

    private function rawFind(int $id): ?array
    {
        global $wpdb;
        $table = $wpdb->prefix . 'avina_tickets';

        $row = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table} WHERE id = %d", $id), ARRAY_A);

        return $row ?: null;
    }

    private function repliesFor(int $ticketId): array
    {
        global $wpdb;
        $table = $wpdb->prefix . 'avina_ticket_replies';

        $rows = $wpdb->get_results(
            $wpdb->prepare("SELECT * FROM {$table} WHERE ticket_id = %d ORDER BY created_at ASC", $ticketId),
            ARRAY_A
        );

        return $rows ?: [];
    }

    private function decorate(array $row): array
    {
        $row['id'] = (int) $row['id'];
        $row['sender_user_id'] = (int) $row['sender_user_id'];
        $row['recipient_user_id'] = $row['recipient_user_id'] !== null ? (int) $row['recipient_user_id'] : null;
        $row['team_id'] = $row['team_id'] !== null ? (int) $row['team_id'] : null;

        return $row;
    }
}
