<?php

declare(strict_types=1);

namespace AvinaCRM\Frontend;

/**
 * Stage 2 foundation shell: enqueues the app-shell CSS/JS and prints the
 * mount point + a small localized config object. The JS itself (Stage 2
 * scope) only proves the shell boots and calls GET /me — it does not
 * render any business-module page, since those do not exist yet.
 */
final class AppShellRenderer
{
    public function renderAppShell(string $mode, int $targetUserId = 0): string
    {
        wp_enqueue_style('avina-crm-fonts', 'https://fonts.googleapis.com/css2?family=Vazirmatn:wght@400;500;700&family=Lalezar&family=Titr&display=swap', [], null);
        wp_enqueue_style('avina-crm-theme-light', AVINA_CRM_URL . 'assets/css/theme-light.css', [], AVINA_CRM_VERSION);
        wp_enqueue_style('avina-crm-theme-dark', AVINA_CRM_URL . 'assets/css/theme-dark.css', [], AVINA_CRM_VERSION);
        wp_enqueue_style('avina-crm-app-shell', AVINA_CRM_URL . 'assets/css/app-shell.css', ['avina-crm-theme-light'], AVINA_CRM_VERSION);

        wp_enqueue_script('tailwind-cdn', AVINA_CRM_URL . 'assets/js/tailwind.min.js', [], AVINA_CRM_VERSION, false);
        $appJsVer = AVINA_CRM_VERSION . '.' . (file_exists(AVINA_CRM_DIR . 'assets/js/app.js') ? filemtime(AVINA_CRM_DIR . 'assets/js/app.js') : time());
        wp_enqueue_script('avina-crm-app', AVINA_CRM_URL . 'assets/js/app.js', ['tailwind-cdn'], $appJsVer, true);

        // The app shell is a native ES module (matching the legacy
        // frontend's own approach, ported unchanged): add type="module"
        // to the printed <script> tag. wp_script_add_data('type', ...) is
        // not reliably honored across WP core versions for this purpose,
        // so this is done via the tag filter instead, scoped to this one
        // handle only.
        add_filter('script_loader_tag', static function (string $tag, string $handle) {
            if ($handle !== 'avina-crm-app') {
                return $tag;
            }
            $tag = preg_replace('/type\s*=\s*["\']text\/javascript["\']/', 'type="module"', $tag);
            if (!str_contains($tag, 'type="module"')) {
                $tag = str_replace('<script ', '<script type="module" ', $tag);
            }
            return $tag;
        }, 10, 2);

        $wpUser = wp_get_current_user();
        wp_localize_script('avina-crm-app', 'AvinaCrmConfig', [
            'restUrl' => esc_url_raw(rest_url(\AvinaCRM\Rest\RestRegistrar::NAMESPACE_V1)),
            'nonce' => wp_create_nonce('wp_rest'),
            'mode' => $mode,
            'targetUserId' => $targetUserId,
            'defaultTheme' => get_option('avina_crm_default_theme', 'light'),
            'appName' => get_option('avina_crm_app_name', 'آوینا CRM'),
            'geminiApiKey' => get_option('avina_crm_gemini_api_key', ''),
            'geminiApiKeyDashboard' => get_option('avina_crm_gemini_api_key_dashboard', ''),
            'geminiApiKeyFloating' => get_option('avina_crm_gemini_api_key_floating', ''),
            'geminiApiKeyTraining' => get_option('avina_crm_gemini_api_key_training', ''),
            'geminiModel' => get_option('avina_crm_gemini_model', 'gemini-3-flash-preview'),
            'geminiProxy' => get_option('avina_crm_ai_proxy', ''),
            'crmLoginUrl' => esc_url_raw(site_url('/crm-login/')),
            'loginUrl' => esc_url_raw(site_url('/crm-login/')),
            'logoutUrl' => esc_url_raw(site_url('/crm-login/')),
            'wpAdminUser' => [
                'id' => $wpUser->exists() ? $wpUser->ID : 1,
                'name' => $wpUser->exists() ? ($wpUser->display_name ?: $wpUser->user_login) : 'مدیر کل',
                'username' => $wpUser->exists() ? $wpUser->user_login : 'admin',
                'email' => $wpUser->exists() ? $wpUser->user_email : 'admin@example.com',
            ]
        ]);

        $config_script = '
        <script>
            window.tailwind = window.tailwind || {};
            window.tailwind.config = {
                darkMode: "class",
                theme: {
                    extend: {
                        colors: {
                            accent: {
                                DEFAULT: "var(--accent-color)",
                                hover: "var(--accent-color-hover)",
                            }
                        },
                        fontFamily: {
                            "vazir": ["Vazirmatn", "sans-serif"],
                            "lalezar": ["Lalezar", "cursive"],
                            "titr": ["Titr", "cursive"]
                        }
                    }
                }
            };
        </script>';

        return $config_script . '<div id="avina-crm-root" class="avina-crm-fullscreen" dir="rtl" lang="fa" data-mode="' . esc_attr($mode) . '"></div>';
    }

    public function renderAccessDenied(): string
    {
        ob_start();
        ?>
        <div class="avina-crm-fullscreen avina-crm-denied" dir="rtl" lang="fa">
            <div class="avina-crm-denied__box">
                <h1><?php echo esc_html__('دسترسی غیرمجاز', 'avina-crm'); ?></h1>
                <p><?php echo esc_html__('شما اجازه مشاهده این صفحه را ندارید. اگر فکر می‌کنید این یک اشتباه است، با مدیر سامانه تماس بگیرید.', 'avina-crm'); ?></p>
                <?php if (!is_user_logged_in()) : ?>
                    <p><a class="avina-crm-denied__login" href="<?php echo esc_url(wp_login_url(get_permalink())); ?>"><?php echo esc_html__('ورود به سامانه', 'avina-crm'); ?></a></p>
                <?php endif; ?>
            </div>
        </div>
        <style>
            .avina-crm-denied{display:flex;align-items:center;justify-content:center;min-height:60vh;background:#f7f7f8;font-family:Tahoma,Arial,sans-serif;}
            .avina-crm-denied__box{max-width:420px;text-align:center;background:#fff;padding:2.5rem 2rem;border-radius:12px;box-shadow:0 1px 4px rgba(0,0,0,.08);}
            .avina-crm-denied__box h1{font-size:1.4rem;color:#c62828;margin-bottom:.75rem;}
            .avina-crm-denied__login{display:inline-block;margin-top:1rem;padding:.5rem 1.25rem;background:#1a56db;color:#fff;border-radius:6px;text-decoration:none;}
        </style>
        <?php
        return (string) ob_get_clean();
    }
}
