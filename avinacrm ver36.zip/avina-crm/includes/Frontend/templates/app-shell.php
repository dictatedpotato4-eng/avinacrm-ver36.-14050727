<?php
/**
 * Fullscreen app-shell template. Loaded ONLY via TemplateController's
 * template_include filter, and only for a page whose content contains
 * [avina_crm_admin] or [avina_crm_user] — never registered as a
 * selectable page template in wp-admin, and never affects any other
 * page on the site. This intentionally does NOT call get_header()/
 * get_footer(), so the active theme's chrome never wraps the CRM shell,
 * per Stage 2 decision #4 ("do not modify the active WordPress theme
 * globally").
 */

if (!defined('ABSPATH')) {
    exit;
}

?><!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
<meta charset="<?php bloginfo('charset'); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="robots" content="noindex, nofollow">
<title><?php echo esc_html(get_the_title() . ' — ' . get_bloginfo('name')); ?></title>
<?php wp_head(); ?>
</head>
<body <?php body_class('avina-crm-app-shell-body'); ?>>
<?php
while (have_posts()) {
    the_post();
    the_content();
}
?>
<?php wp_footer(); ?>
</body>
</html>
