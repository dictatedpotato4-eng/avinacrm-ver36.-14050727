<?php

declare(strict_types=1);

namespace AvinaCRM\Frontend;

/**
 * Stage 1 §8 / Stage 2 decision #7, implemented exactly as approved:
 *
 *  - [avina_crm_admin] renders only if the CURRENT logged-in user has
 *    platform.admin_dashboard.view. The shortcode's mere presence on a
 *    page never grants access by itself.
 *
 *  - [avina_crm_user user_id="123"] treats the `user_id` attribute as
 *    ROUTING METADATA ONLY, never as an authorization input. The real
 *    decision always comes from get_current_user_id(): either the
 *    logged-in user owns this page (per {prefix}avina_operator_pages),
 *    or the logged-in user is an administrator using the separately
 *    authorized monitor/view-as capability. Every other case is denied
 *    server-side with the Persian RTL access-denied state — never a
 *    silent redirect, never a partial render.
 */
final class ShortcodeRegistrar
{
    private AppShellRenderer $renderer;

    public function __construct()
    {
        $this->renderer = new AppShellRenderer();
    }

    public function bootstrap(): void
    {
        add_shortcode('avina_crm_login', [$this, 'renderLoginShortcode']);
        add_shortcode('avina_crm_admin', [$this, 'renderAdminShortcode']);
        add_shortcode('avina_crm_user', [$this, 'renderUserShortcode']);
        add_shortcode('avina_crm_app', [$this, 'renderAdminShortcode']);
        add_shortcode('avina_crm_lead', [$this, 'renderLeadFormShortcode']);
        add_shortcode('avina_crm_customer', [$this, 'renderCustomerFormShortcode']);
        add_shortcode('avina_crm_reception', [$this, 'renderReceptionShortcode']);
        add_shortcode('avina_crm_recruitment', [$this, 'renderRecruitmentShortcode']);
        add_shortcode('avina_crm_invoice', [$this, 'renderInvoiceShortcode']);
        add_shortcode('avina_crm_sms', [$this, 'renderSmsShortcode']);

        add_filter('authenticate', static function ($user, $username, $password) {
            if (!empty($username) && !empty($password)) {
                $cleanUsername = \AvinaCRM\Operators\OperatorService::toEnglishDigits(trim((string) $username));
                $cleanPassword = \AvinaCRM\Operators\OperatorService::toEnglishDigits(trim((string) $password));

                if ($cleanUsername !== $username || $cleanPassword !== $password) {
                    $check = wp_authenticate_username_password(null, $cleanUsername, $cleanPassword);
                    if ($check instanceof \WP_User) {
                        return $check;
                    }
                }

                // Check by mobile meta if normal auth failed
                if (is_wp_error($user) || $user === null) {
                    $mobileUsers = get_users([
                        'meta_key' => 'avina_crm_operator_mobile',
                        'meta_value' => $cleanUsername,
                        'number' => 1
                    ]);
                    if (!empty($mobileUsers)) {
                        $checkMobile = wp_authenticate_username_password(null, $mobileUsers[0]->user_login, $cleanPassword);
                        if ($checkMobile instanceof \WP_User) {
                            return $checkMobile;
                        }
                    }
                }
            }
            return $user;
        }, 20, 3);

        add_filter('template_include', function ($template) {
            if (isset($_GET['avina_crm_user_id']) || isset($_GET['crm_user_id'])) {
                if (!is_user_logged_in()) {
                    wp_redirect(site_url('/crm-login/'));
                    exit;
                }
                $rawId = sanitize_text_field($_GET['avina_crm_user_id'] ?? $_GET['crm_user_id'] ?? '');
                $userId = (int) preg_replace('/\D/', '', $rawId);

                if ($userId <= 0) {
                    $userId = get_current_user_id();
                }

                $userObj = get_userdata($userId);
                $displayName = $userObj ? ($userObj->display_name ?: $userObj->user_login) : 'اپراتور';

                $operatorService = new \AvinaCRM\Operators\OperatorService(
                    new \AvinaCRM\Capabilities\RoleProvisioner(),
                    new \AvinaCRM\Audit\AuditLogger()
                );
                $pageId = $operatorService->createOperatorPage($userId, $displayName);
                $post = get_post($pageId);

                if ($post instanceof \WP_Post) {
                    global $post, $wp_query;
                    $wp_query->queried_object = $post;
                    $wp_query->post = $post;
                    setup_postdata($post);
                    echo $this->renderStandaloneUserPage($post);
                    exit;
                }
            }

            $post = get_post();
            if ($post instanceof \WP_Post && is_singular()) {
                if (has_shortcode($post->post_content, 'avina_crm_login')) {
                    echo $this->renderLoginShortcode();
                    exit;
                }
                if (has_shortcode($post->post_content, 'avina_crm_user')) {
                    if (!is_user_logged_in()) {
                        wp_redirect(site_url('/crm-login/'));
                        exit;
                    }
                    echo $this->renderStandaloneUserPage($post);
                    exit;
                }
            }
            return $template;
        });

        add_filter('body_class', static function (array $classes): array {
            $post = get_post();
            if ($post instanceof \WP_Post && is_singular() && (has_shortcode($post->post_content, 'avina_crm_user') || has_shortcode($post->post_content, 'avina_crm_admin') || has_shortcode($post->post_content, 'avina_crm_app'))) {
                $classes[] = 'avina-crm-active-page';
            }
            return $classes;
        });
    }

    public function renderLeadFormShortcode(): string
    {
        return $this->renderer->renderAppShell('public', 0) . '<script>window.location.hash="#/form/lead";</script>';
    }

    public function renderCustomerFormShortcode(): string
    {
        return $this->renderer->renderAppShell('public', 0) . '<script>window.location.hash="#/customers";</script>';
    }

    public function renderReceptionShortcode(): string
    {
        return $this->renderer->renderAppShell('public', 0) . '<script>window.location.hash="#/reception";</script>';
    }

    public function renderRecruitmentShortcode(): string
    {
        return $this->renderer->renderAppShell('public', 0) . '<script>window.location.hash="#/form/recruitment";</script>';
    }

    public function renderInvoiceShortcode(): string
    {
        return $this->renderer->renderAppShell('public', 0) . '<script>window.location.hash="#/invoices";</script>';
    }

    public function renderSmsShortcode(): string
    {
        return $this->renderer->renderAppShell('public', 0) . '<script>window.location.hash="#/sms-keypad";</script>';
    }

    public function renderAdminShortcode(): string
    {
        if (!is_user_logged_in()) {
            return $this->renderer->renderAccessDenied();
        }

        $isAdmin = \AvinaCRM\Support\Scope::isAdmin();
        if (!$isAdmin) {
            $userId = get_current_user_id();
            if ($userId > 0) {
                return $this->renderer->renderAppShell('operator', $userId);
            }
            return $this->renderer->renderAccessDenied();
        }

        return $this->renderer->renderAppShell('admin');
    }

    /**
     * @param array<string, mixed>|string $atts
     */
    public function renderUserShortcode($atts): string
    {
        if (!is_user_logged_in()) {
            return $this->renderer->renderAccessDenied();
        }

        $currentUserId = get_current_user_id();
        $isAdmin = \AvinaCRM\Support\Scope::isAdmin();

        $atts = shortcode_atts(['user_id' => 0], is_array($atts) ? $atts : []);
        $requestedUserId = (int) $atts['user_id'];

        if ($requestedUserId <= 0) {
            $requestedUserId = $currentUserId;
        }

        if ($isAdmin || $currentUserId === $requestedUserId || $this->isOwnPage($currentUserId)) {
            $mode = ($isAdmin && $currentUserId !== $requestedUserId) ? 'monitor' : 'operator';
            return $this->renderer->renderAppShell($mode, $requestedUserId);
        }

        return $this->renderer->renderAccessDenied();
    }

    private function isOwnPage(int $currentUserId): bool
    {
        global $wpdb;

        $postId = get_the_ID();

        if (!$postId) {
            return false;
        }

        $table = $wpdb->prefix . 'avina_operator_pages';

        $ownerId = $wpdb->get_var(
            $wpdb->prepare(
                "SELECT user_id FROM {$table} WHERE page_id = %d AND is_active = 1",
                $postId
            )
        );

        return $ownerId !== null && (int) $ownerId === $currentUserId;
    }

    private function userOwnsAPage(int $userId): bool
    {
        global $wpdb;

        $table = $wpdb->prefix . 'avina_operator_pages';

        $exists = $wpdb->get_var(
            $wpdb->prepare(
                "SELECT COUNT(*) FROM {$table} WHERE user_id = %d AND is_active = 1",
                $userId
            )
        );

        return (int) $exists > 0;
    }

    public function renderLoginShortcode(): string
    {
        if (is_user_logged_in()) {
            $admin_url = site_url('/crm-admin/');
            return '<script>window.location.href="' . esc_url($admin_url) . '";</script>';
        }

        $crm_admin_url = esc_url(site_url('/crm-admin/'));
        $login_post_url = esc_url(site_url('/wp-login.php', 'login_post'));

        ob_start();
        ?>
        <div id="avina-crm-fullscreen-login" style="position: fixed; top: 0; left: 0; right: 0; bottom: 0; width: 100vw; height: 100vh; z-index: 9999999; background: #020617; display: flex; align-items: center; justify-content: center; overflow: hidden; font-family: Tahoma, 'Vazirmatn', sans-serif; direction: rtl;" lang="fa">
            
            <!-- Ambient Background Glow Orbs -->
            <div style="position: absolute; top: -10%; right: -10%; width: 400px; height: 400px; background: radial-gradient(circle, rgba(6,182,212,0.25) 0%, rgba(6,182,212,0) 70%); filter: blur(60px); pointer-events: none;"></div>
            <div style="position: absolute; bottom: -10%; left: -10%; width: 450px; height: 450px; background: radial-gradient(circle, rgba(168,85,247,0.25) 0%, rgba(168,85,247,0) 70%); filter: blur(70px); pointer-events: none;"></div>
            <div style="position: absolute; top: 40%; left: 10%; width: 300px; height: 300px; background: radial-gradient(circle, rgba(16,185,129,0.2) 0%, rgba(16,185,129,0) 70%); filter: blur(50px); pointer-events: none;"></div>

            <!-- Floating Neon Particles (Moving Bottom to Top) -->
            <div class="avina-login-particles">
                <div class="avina-particle p1"></div>
                <div class="avina-particle p2"></div>
                <div class="avina-particle p3"></div>
                <div class="avina-particle p4"></div>
                <div class="avina-particle p5"></div>
                <div class="avina-particle p6"></div>
                <div class="avina-particle p7"></div>
                <div class="avina-particle p8"></div>
            </div>

            <!-- Glassmorphic Login Card with Neon Gradient Border -->
            <div style="position: relative; z-index: 10; width: 100%; max-width: 440px; padding: 2px; border-radius: 28px; background: linear-gradient(135deg, rgba(6,182,212,0.6), rgba(16,185,129,0.4), rgba(168,85,247,0.6)); box-shadow: 0 0 50px rgba(6,182,212,0.3); margin: 16px;">
                <div style="background: rgba(15, 23, 42, 0.92); backdrop-filter: blur(30px); -webkit-backdrop-filter: blur(30px); border-radius: 26px; padding: 40px 32px; color: #f8fafc; text-align: right; box-shadow: inset 0 0 20px rgba(255,255,255,0.03);">
                    
                    <!-- Header & Logo -->
                    <div style="text-align: center; margin-bottom: 28px;">
                        <div style="width: 64px; height: 64px; margin: 0 auto 16px; border-radius: 20px; background: linear-gradient(135deg, rgba(6,182,212,0.2), rgba(16,185,129,0.2)); border: 1px solid rgba(6,182,212,0.4); display: flex; align-items: center; justify-content: center; box-shadow: 0 0 25px rgba(6,182,212,0.3);">
                            <svg style="width: 32px; height: 32px; color: #38bdf8;" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
                            </svg>
                        </div>
                        <h1 style="font-size: 22px; font-weight: 800; color: #ffffff; margin: 0 0 6px 0; letter-spacing: -0.5px;">ورود به سامانه آوینا CRM</h1>
                        <p style="font-size: 12px; color: #94a3b8; margin: 0;">پرتال مدیریت ارتباط با مشتریان و هوش مصنوعی</p>
                    </div>

                    <!-- Login Form -->
                    <form method="post" action="<?php echo $login_post_url; ?>" style="display: flex; flex-direction: column; gap: 18px;">
                        <input type="hidden" name="redirect_to" value="<?php echo $crm_admin_url; ?>" />
                        
                        <div>
                            <label style="display: block; font-size: 12px; font-weight: 700; color: #cbd5e1; margin-bottom: 8px;">نام کاربری یا نشانی ایمیل</label>
                            <div style="position: relative;">
                                <input type="text" name="log" id="user_login" required placeholder="مثال: admin یا user@example.com" style="width: 100%; padding: 14px 16px; background: rgba(2, 6, 23, 0.7); border: 1px solid rgba(51, 65, 85, 0.8); border-radius: 14px; color: #f8fafc; font-size: 13px; outline: none; transition: all 0.3s; box-sizing: border-box;" onfocus="this.style.borderColor='#38bdf8'; this.style.boxShadow='0 0 15px rgba(56,189,248,0.3)';" onblur="this.style.borderColor='rgba(51, 65, 85, 0.8)'; this.style.boxShadow='none';" />
                            </div>
                        </div>

                        <div>
                            <label style="display: block; font-size: 12px; font-weight: 700; color: #cbd5e1; margin-bottom: 8px;">رمز عبور</label>
                            <div style="position: relative;">
                                <input type="password" name="pwd" id="user_pass" required placeholder="••••••••" style="width: 100%; padding: 14px 16px; background: rgba(2, 6, 23, 0.7); border: 1px solid rgba(51, 65, 85, 0.8); border-radius: 14px; color: #f8fafc; font-size: 13px; outline: none; transition: all 0.3s; box-sizing: border-box;" onfocus="this.style.borderColor='#38bdf8'; this.style.boxShadow='0 0 15px rgba(56,189,248,0.3)';" onblur="this.style.borderColor='rgba(51, 65, 85, 0.8)'; this.style.boxShadow='none';" />
                            </div>
                        </div>

                        <div style="display: flex; align-items: center; justify-content: space-between; font-size: 12px; margin-top: 2px;">
                            <label style="display: flex; align-items: center; gap: 8px; color: #94a3b8; cursor: pointer; user-select: none;">
                                <input type="checkbox" name="rememberme" value="forever" checked style="accent-color: #06b6d4; width: 16px; height: 16px; cursor: pointer;" />
                                مرا به خاطر بسپار
                            </label>
                        </div>

                        <button type="submit" name="wp-submit" id="wp-submit" style="width: 100%; margin-top: 10px; padding: 15px; background: linear-gradient(135deg, #06b6d4 0%, #10b981 100%); border: none; border-radius: 14px; color: #020617; font-size: 14px; font-weight: 800; cursor: pointer; transition: all 0.3s; box-shadow: 0 0 25px rgba(6,182,212,0.4);" onmouseover="this.style.transform='translateY(-2px)'; this.style.boxShadow='0 0 35px rgba(6,182,212,0.6)';" onmouseout="this.style.transform='none'; this.style.boxShadow='0 0 25px rgba(6,182,212,0.4)';">
                            ورود به سامانه آوینا CRM ➔
                        </button>
                    </form>

                    <div style="margin-top: 24px; text-align: center; font-size: 11px; color: #64748b;">
                        سامانه هوشمند آوینا CRM • طراحی شده با نیون شیشه‌ای
                    </div>
                </div>
            </div>

            <!-- Styles & Particle Keyframe Animations -->
            <style>
                .avina-login-particles {
                    position: absolute;
                    inset: 0;
                    pointer-events: none;
                    overflow: hidden;
                    z-index: 1;
                }
                .avina-particle {
                    position: absolute;
                    bottom: -150px;
                    border-radius: 50%;
                    animation: avinaFloatUpParticle 18s infinite linear;
                    pointer-events: none;
                }
                .avina-particle.p1 { left: 8%; width: 180px; height: 180px; background: radial-gradient(circle, rgba(6,182,212,0.3) 0%, rgba(6,182,212,0) 70%); filter: blur(30px); animation-duration: 22s; animation-delay: 0s; }
                .avina-particle.p2 { left: 25%; width: 90px; height: 90px; background: radial-gradient(circle, rgba(168,85,247,0.35) 0%, rgba(168,85,247,0) 70%); filter: blur(20px); animation-duration: 15s; animation-delay: 2s; }
                .avina-particle.p3 { left: 45%; width: 220px; height: 220px; background: radial-gradient(circle, rgba(16,185,129,0.3) 0%, rgba(16,185,129,0) 70%); filter: blur(40px); animation-duration: 28s; animation-delay: 4s; }
                .avina-particle.p4 { left: 65%; width: 130px; height: 130px; background: radial-gradient(circle, rgba(236,72,153,0.35) 0%, rgba(236,72,153,0) 70%); filter: blur(25px); animation-duration: 19s; animation-delay: 1s; }
                .avina-particle.p5 { left: 82%; width: 200px; height: 200px; background: radial-gradient(circle, rgba(56,189,248,0.3) 0%, rgba(56,189,248,0) 70%); filter: blur(35px); animation-duration: 25s; animation-delay: 6s; }
                .avina-particle.p6 { left: 38%; width: 70px; height: 70px; background: radial-gradient(circle, rgba(251,191,36,0.4) 0%, rgba(251,191,36,0) 70%); filter: blur(15px); animation-duration: 14s; animation-delay: 5s; }
                .avina-particle.p7 { left: 58%; width: 140px; height: 140px; background: radial-gradient(circle, rgba(99,102,241,0.35) 0%, rgba(99,102,241,0) 70%); filter: blur(25px); animation-duration: 21s; animation-delay: 3s; }
                .avina-particle.p8 { left: 92%; width: 110px; height: 110px; background: radial-gradient(circle, rgba(16,185,129,0.35) 0%, rgba(16,185,129,0) 70%); filter: blur(20px); animation-duration: 17s; animation-delay: 7s; }

                @keyframes avinaFloatUpParticle {
                    0% {
                        transform: translateY(105vh) scale(0.6) rotate(0deg);
                        opacity: 0;
                    }
                    15% {
                        opacity: 0.9;
                    }
                    85% {
                        opacity: 0.9;
                    }
                    100% {
                        transform: translateY(-20vh) scale(1.3) rotate(360deg);
                        opacity: 0;
                    }
                }
            </style>
        </div>
        <?php
        return (string) ob_get_clean();
    }

    public function renderStandaloneUserPage(\WP_Post $post): string
    {
        $userId = $this->extractUserIdFromShortcode($post->post_content);
        $contentHtml = $this->renderUserShortcode(['user_id' => $userId]);

        ob_start();
        ?>
        <!DOCTYPE html>
        <html lang="fa" dir="rtl">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title><?php echo esc_html($post->post_title); ?></title>
            <?php wp_head(); ?>
            <style>
                html, body {
                    margin: 0 !important;
                    padding: 0 !important;
                    width: 100vw !important;
                    height: 100vh !important;
                    background-color: #0f172a !important;
                    overflow: hidden !important;
                }
                #wpadminbar { display: none !important; }
            </style>
        </head>
        <body class="avina-crm-standalone-page">
            <?php echo $contentHtml; ?>
            <?php wp_footer(); ?>
        </body>
        </html>
        <?php
        return (string) ob_get_clean();
    }

    private function extractUserIdFromShortcode(string $content): int
    {
        if (preg_match('/\[avina_crm_user\s+user_id=["\']?(\d+)["\']?\]/i', $content, $m)) {
            return (int) $m[1];
        }
        return 0;
    }
}
