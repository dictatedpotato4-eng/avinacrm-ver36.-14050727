<?php
/**
 * Fires only when the plugin is deleted from the Plugins screen (never on
 * simple deactivation). WordPress requires this exact filename/location.
 *
 * This file stays PHP-7.4-safe on purpose (see avina-crm.php's own
 * docblock for the same reasoning): if a host has since downgraded PHP,
 * uninstall must still not fatal, and must still do nothing destructive.
 */

if (!defined('WP_UNINSTALL_PLUGIN')) {
    exit;
}

if (version_compare(PHP_VERSION, '8.1.0', '>=')) {
    if (!defined('AVINA_CRM_DIR')) {
        define('AVINA_CRM_DIR', plugin_dir_path(__FILE__));
    }

    require_once AVINA_CRM_DIR . 'includes/Kernel/Autoloader.php';
    \AvinaCRM\Kernel\Autoloader::register();
    \AvinaCRM\Uninstall\UninstallHandler::run();
}

// No table drops, no option deletion, no role removal happen here or in
// UninstallHandler::run() — see that class's docblock. This is
// deliberate, not an oversight: Stage 1/Stage 2 both require uninstall
// to be non-destructive by default.
